<?php
include "../conecta_banco.php";?>
<!DOCTYPE HTML>
<html lang="pt_br">
<head>
<title>relatórios</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		 <link href="../css/print_tab.css" rel="stylesheet" />
	  <link href="../css/print_div.css" rel="stylesheet" />
	   <link href="../css/print_fontes.css" rel="stylesheet" />
	 <script type="text/javascript">
	 function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 } 

 function validacao() {
 if(document.form.processo.value=="Selecione...")
{
alert("Por favor selecione o processo.");
document.form.processo.focus();
return false;
}
}
	 </script>
 </head>
	 <body>
	 <div class="cabecalho">
	  <?php include "cabecalho.php"; ?> 
	  </div>
	 <div class="titulo">
	  <h3>REQUERIMENTO DE EMPENHO</h3>
	  </div>
	 <img class="logo" src="../img/banner.jpg">
    	 <?php
		 $separa= ' - ';
?>
	 <div id="tudo">
	<h2>Listar Itens por processo</h2>
<form name="form" action="../executa/exec_itens.php" method="post" onSubmit="return validacao();">
<fieldset class="grupo">
		 <div class="campo">
		 <?php 
	$query = mysql_query("SELECT * FROM cadcompras WHERE situacao='Ativo' ORDER BY idcompra DESC");
?>
 <label for="">Selecione o processo</label>
 <select name="processo">
 <option name="">Selecione...</option>
 <?php 
 while($busca = mysql_fetch_array($query)) { 
 ?>
 <option value="<?php 
 echo $busca['processo'] 
 ?>">
 <?php 
 echo $busca['processo'].$separa.$busca['finalidade']
 ?></option>
 <?php } ?>
 </select>
		 
</div>
	</fieldset>
<div class="campo">
<input type="submit" name="Seleciona" Value="Selecionar">
<input type="reset" name="Seleciona" Value="Limpar">
<input type="button" name="cancela" value="Cancelar" onclick="window.location.href='../painel_alm.php'"/>
</div>
</form>
</div>
</body>
</html>