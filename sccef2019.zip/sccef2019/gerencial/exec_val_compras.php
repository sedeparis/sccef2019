﻿<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	if (!isset($_SESSION['logado']) || $_SESSION['logado'] !== 1){        
        header("Location: index.html");
        session_destroy();
        exit;
    } 
	//echo 'Acessado como: $logado';
	echo '</div>';
include "../conecta_banco.php";

?>
<!DOCTYPE HTML>
<html lang="pt_br">
<head>
  <link rel="icon" type="image/jpg" href="../img/icone_barra.jpg" />
<title>relatórios</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		 <link href="../css/print_tab.css" rel="stylesheet" />
	  <link href="../css/print_div.css" rel="stylesheet" />
	   <link href="../css/print_fontes.css" rel="stylesheet" />
</head>
 <body>
	 <div class="cabecalho">
	  <?php include "cabecalho.php"; ?> 
	  </div>
	 <div class="titulo">
	  <h3>Lista validade da compra</h3>
	  </div>
<?php
$datai=$_POST['datai'];
$dataf=$_POST['dataf'];
?>
<div class="tabela">
<?php
//com pdo

// cria a instrução SQL que vai selecionar os dados dos itens
$sql = mysqli_query ($mysqli, "SELECT * FROM produto 
INNER JOIN cadfornecedor ON produto.fornecedora=cadfornecedor.idforn
INNER JOIN cadcompras ON produto.idprocesso=cadcompras.idcompra
 WHERE dataval BETWEEN '$datai' AND '$dataf'");
$sqlr = mysqli_query($mysqli, $sql);
$linhar = mysqli_fetch_assoc($sqlr);
$total = mysqli_num_rows($sqlr);
?>

<?php
if ($total > 0) {
}
do {

echo "<table>
<thead>
<tr>
<td>Processo</td>
<td>Item</td>
<td>Descrição</td>
<td>Fornecedor</td>
<td>Lic</td>
<td>Validade</td>
</tr>
</thead>

<tbody>
";

while ($sql->fetch())
{
	echo " <tr>
<td>$idcompra</td>
<td>$nitem</td>
<td>$ditem</td>
<td>$idfornecedor</td>
<td>$quant_lic</td>
<td>$data</td>
</tr>";
}
echo "<tbody>
</table>
";
}
?>


</div>
<div class="button">
 <input type="button" name="ok" value="Voltar" onclick="window.location.href='../painel_alm.php'"/>
</div>
<?php include "footer.php"; ?> 
</body>
</html>

