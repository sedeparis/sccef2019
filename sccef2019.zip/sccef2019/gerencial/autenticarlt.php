<?php
$email= $_POST['email'];
$senha= md5($_POST['senha']);
include ("../conecta_banco.php");
$sql = @mysql_query("SELECT * FROM users WHERE email = '$email' 
AND senha= '$senha' 
AND situacao = 1 AND comprador = 1 ") or die (mysql_error());
$row = mysql_num_rows($sql);
if($row > 0){
	session_start();
	$_SESSION ['email']=$_POST['email'];
	$_SESSION ['senha']=md5($_POST['senha']);
	$_SESSION ['situacao']=['1'];
	echo 'Autenticando!';
	echo "<meta HTTP-EQUIV='refresh' CONTENT='1;URL=painelrlt.php'>";
} else {
	echo 'Usuário ou senha não encontrado';
	echo "<meta HTTP-EQUIV='refresh' CONTENT='1;URL=../index.php'>";
}
?>
 <!DOCTYPE HTML>
 <html lang="pt_BR">
<head>
<title>Acesso de usuario
</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	 <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/custom.css" type="text/css"/>
	 <!-- jQuery (necessario para os plugins Javascript do Bootstrap) -->
  <script src="../js/jquery.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/custom.min.js"></script>
</head>
<!-------- inicia pagina-------------->
<body>
<div class="container">
<?php include "topo.php" ?>
</div>
<div class="container">
<br />
<br />
<br />
<br />
<p class="center"><img src="../img/baile.gif"/></p>

</div>

<?php include "footer.php" ?>

</body>
</html>