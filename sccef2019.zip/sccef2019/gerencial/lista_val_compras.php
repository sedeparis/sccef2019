<?php
include "../conecta_banco.php";?>
<!DOCTYPE HTML>
<html lang="pt_br">
<head>
<title>relatórios</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/estiloform.css" type="text/css"/>
	 <link rel="stylesheet" href="../js/jquery.js"/>
	  <link rel="stylesheet" href="http://code.jquery.com/ui/1.9.0/themes/base/jquery-ui.css" />
<script src="http://code.jquery.com/jquery-1.8.2.js"></script>
<script src="http://code.jquery.com/ui/1.9.0/jquery-ui.js"></script>
	 <script type="text/javascript">
	 function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 } 

 function validacao() {
 if(document.form.datai.value=="")
{
alert("Por favor informe a data inicial.");
document.form.datai.focus();
return false;
}
if(document.form.dataf.value=="")
{
alert("Por favor informe a data final.");
document.form.dataf.focus();
return false;
}
}


<!-- chamar calendario --->
$(function() {
    $( "#calendario" ).datepicker();
});

$(function() {
    $( "#calendario" ).datepicker({
        showOn: "button",
        buttonImage: "calendario.png",
        buttonImageOnly: true
    });
});


<!-- chamar calendario data final--->
$(function() {
    $( "#calendario2" ).datepicker();
});

$(function() {
    $( "#calendario" ).datepicker({
        showOn: "button",
        buttonImage: "calendario.png",
        buttonImageOnly: true
    });
});
	 </script>
 </head>
 <body>
	 <div class="container">
	  <?php include "topo.php"; ?> 
	  </div>
	 	 <div class="container">
	  <h3>Listar Compras com Validade</h3>
	  </div>
	   <div class="container">
	 <form name="form" action="exec_val_compras.php" method="post" onSubmit="return validacao();">
<fieldset class="grupo">
		 <div class="form-group">
<label class="form-control">Entre com a data inicial</label>
<input class="form-control" type="text" name="datai" id="calendario"/>
</div>
<div class="form-group">
<label class="form-control">Entre com a data final</label>
<input class="form-control" type="text" name="dataf" id="calendario2"/>
</div>
	</fieldset>
<div class="form-group">
<input type="submit" name="Seleciona" Value="Selecionar">
<input type="reset" name="Seleciona" Value="Limpar">
<input type="button" name="cancela" value="Cancelar" onclick="window.location.href='../almoxarifado/painel_alm.php'"/>
</div>
</form>
</div>
</body>
</html>