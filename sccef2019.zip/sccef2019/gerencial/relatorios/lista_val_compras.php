<?php
include "conecta_banco.php";?>
<html>
<head>
<title>listas validade das compras</title>
	 <meta http-equiv="Content-Type" content="text/html" charset="utf-8" />
	 	 <link rel="stylesheet" href="css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="css/estilo.css" type="text/css"/>
	  <link rel="stylesheet" href="css/estiloform.css" type="text/css"/>
	 <script type="text/javascript">
	 function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }

 function validacao() {
 if(document.form.datai.value=="")
{
alert("Por favor informe a data inicial.");
document.form.datai.focus();
return false;
}

if(document.form.dataf.value=="")
{
alert("Por favor informe a data final.");
document.form.dataf.focus();
return false;
}
}
	 </script>
 </head>
	 <body>
	 <img class="logo" src="img/banner.jpg">
    	 <?php
?>
</div>
	 <div id="tudo">
	<h2>Listar Compras com Validade</h2>
<form name="form" action="executa/exec_val_compras.php" method="post" onSubmit="return validacao();">
<fieldset class="grupo">
		 <div class="campo">
<label>Entre com a data inicial</label>
<input type="text" name="datai" size="10" onkeypress="mascara(this, '##/##/####')"  maxlength="10"/>
</div>
<div class="campo">
<label>Entre com a data final</label>
<input type="text" name="dataf" size="10" onkeypress="mascara(this, '##/##/####')"  maxlength="10"/>
</div>
	</fieldset>
<div class="campo">
<input type="submit" name="Seleciona" Value="Selecionar">
<input type="reset" name="Seleciona" Value="Limpar">
<input type="button" name="cancela" value="Cancelar" onclick="window.location.href='painel.php'"/>
</div>
</form>
</div>
</body>
</html>