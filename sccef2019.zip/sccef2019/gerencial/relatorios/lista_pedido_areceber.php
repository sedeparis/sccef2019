<html>
<head>
<title>lista pedidos a receber
</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	 <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/print.css" type="text/css"/>
</head>
<body>
<div id="imprimir">
<h2>Lista pedidos a receber</h2>
<?php
include "../conecta_banco.php";?>
<HR>

<table>
<colgroup>
<col width="14%">
<col width="6%">
<col width="48%">
<col width="24%">
<col width="8%">
</colgroup>
<thead>
<tr>
<th>Processo</th>
<th>It</th>
<th>Descrição</th>
<th>Fornecedor</th>
<th>Qt Sol</th>
</tr>
</thead>
</table>
<?php
$h =" - ";
// cria a instrução SQL que vai selecionar os dados dos itens
$query =("SELECT * FROM caditem WHERE pedido>0 AND recebido = 0");
// executa a query
$dados = @mysql_query($query) or die(mysql_error());
// transforma os dados em um array
$linha = @mysql_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysql_num_rows($dados);
?>
<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($total == 0) {echo "";}
	if($total > 0) { 
		// inicia o loop que vai mostrar todos os dados
		do {
$processo=$linha['idcompra'];
$nitem=$linha['nitem'];
$ditem=$linha['ditem'];
$fornecedor=$linha['idfornecedor'];
$qtl=$linha['pedido'];
$qtu=$linha['recebido'];
?>

<table>
<colgroup>
<col width="14%">
<col width="6%">
<col width="48%">
<col width="24%">
<col width="8%">
</colgroup>
<tbody>
<tr>
<td><?php echo "$processo"?></td>
<td><?php echo "$nitem"?></td>
<td><?php echo "$ditem"?></td>
<td><?php echo "$fornecedor"?></td>
<td><?php echo "$qtl"?></td>
</tr>
</tbody>
</table>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = @mysql_fetch_assoc($dados));
	// fim do if 
	}
?>
<?php
// tira o resultado da busca da memória
@mysql_free_result($dados);
?>
<hr>
<br />
<br />
<input type="button" name="voltar" value="Voltar" onclick="window.location.href='../painel.php'"/>
</div>
</body>
</html>