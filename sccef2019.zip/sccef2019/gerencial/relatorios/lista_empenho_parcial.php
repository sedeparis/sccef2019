<?php
include "conecta_banco.php";?>
<html>
<head>
<title>lista compras com empenho parcial
</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	 <link rel="stylesheet" href="css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="css/print.css" type="text/css"/>
</head>
<body>
<div id="imprimir">

<h2> PROCESSOS DE COMPRAS COM ITENS EMPENHADOS PARCIALMENTE</h2> 
<br />
<br />
<br />
<HR>
<table>
<colgroup>
<col width="14%">
<col width="6%">
<col width="44%">
<col width="20%">
<col width="8%">
<col width="8%">
</colgroup>
<thead>
<tr>
<th>Processo</td>
<th>It</td>
<th>Descrição</td>
<th>Fornecedor</td>
<th>Qt Lic</td>
<th>Qt emp</td>
</tr>
</thead>
</table>
<?php
$h =" - ";
// cria a instrução SQL que vai selecionar os dados dos itens
$query =("SELECT * FROM caditem WHERE quant_disp >0 AND quant_disp <> quant_lic ORDER BY iditem DESC");
// executa a query
$dados = @mysql_query($query) or die(mysql_error());
// transforma os dados em um array
$linha = @mysql_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysql_num_rows($dados);
?>
<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($total == 0) {echo "";}
	if($total > 0) { 
		// inicia o loop que vai mostrar todos os dados
		do {
$processo=$linha['processo'];
$nitem=$linha['nitem'];
$ditem=$linha['ditem'];
$fornecedor=$linha['fornecedor'];
$qtl=$linha['quant_lic'];
$qtu=$linha['quant_util'];

?>
<table>
<colgroup>
<col width="14%">
<col width="6%">
<col width="44%">
<col width="20%">
<col width="8%">
<col width="8%">
</colgroup>
<tbody>
<tr>
<td><?php echo "$processo"?></td>
<td><?php echo "$nitem"?></td>
<td><?php echo "$ditem"?></td>
<td><?php echo "$fornecedor"?></td>
<td><?php echo "$qtl"?></td>
<td><?php echo "$qtu"?></td>
</tr>
</tbody>
</table>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = @mysql_fetch_assoc($dados));
	// fim do if 
	}
?>
<?php
// tira o resultado da busca da memória
@mysql_free_result($dados);
?>
<input type="button" name="voltar" value="Voltar" onclick="window.location.href='painel.php'"/>
</div>
</body>
</html>