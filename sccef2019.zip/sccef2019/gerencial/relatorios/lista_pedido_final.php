<html>
<head>
<title>lista de pedidos finalizados
</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	 <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/print.css" type="text/css"/>
</head>
<body>
<div id="imprimir">
<h2>Relação de Compras-itens totalmente recebidas(os)</h2>
<hr>
<br />
<br />
<?php
include "../conecta_banco.php";?>
<?php
$h =" - ";
// cria a instrução SQL que vai selecionar os dados dos itens
$query =("SELECT * FROM caditem WHERE sobra = 0 AND areceber = 0 AND pedido> 0 ");
// executa a query
$dados = @mysql_query($query) or die(mysql_error());
// transforma os dados em um array
$linha = @mysql_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysql_num_rows($dados);
?>
<br />
<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($total == 0) {echo "Não encontramos compras nesta situação";}
	if($total > 0) { 
		// inicia o loop que vai mostrar todos os dados
		do {
$processo=$linha['idcompra'];
$nitem=$linha['nitem'];
$ditem=$linha['ditem'];
$fornecedor=$linha['idfornecedor'];
$qtl=$linha['pedido'];
$qtu=$linha['recebido'];
?>

<table>
<colgroup>
<col width="10%">
<col width="5%">
<col width="40%">
<col width="20%">
<col width="12%">
<col width="13%">
</colgroup>
<thead>
<tr>
<th >Processo</th>
<th>Item</th>
<th>Descrição</th>
<th>Fornecedor</th>
<th>Qt Ped</th>
<th>QT Rec</th>
</tr>
</thead>
<tbody>
<tr>
<td width="10%"><?php echo "$processo"?></td>
<td width="5%"><?php echo "$nitem"?></td>
<td width="50%"><?php echo "$ditem"?></td>
<td width="25%"><?php echo " $fornecedor"?></td>
<td width="5%"><?php echo "$qtl"?></td>
<td width="5%"><?php echo "$qtu"?></td>
</tr>
</tbody>
</table>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = @mysql_fetch_assoc($dados));
	// fim do if 
	}
?>
<?php
// tira o resultado da busca da memória
@mysql_free_result($dados);
?>
<hr>
<br />
<br />
 <input type="button" name="ok" value="Voltar" onclick="window.location.href='../painel.php'"/>
</div>
</body>
</html>
