﻿ <?php
 session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	//echo 'Acessado como: $logado';
	echo '</div>';
include "../conecta_banco.php";

?>
<!DOCTYPE HTML>
<html lang="pt_br">
<head>
  <link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Lista compras por periodo</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	 <link href="../css/print_tab.css" rel="stylesheet" />
	  <link href="../css/print_div.css" rel="stylesheet" />
	   <link href="../css/print_fontes.css" rel="stylesheet" />
</head>
 <body>
	 <div class="cabecalho">
	  <?php include "cabecalho.php"; ?> 
	  </div>
	 <div class="titulo">
  	 <h3>Listagem de compras por período</h3>
	 </div>
	 <div class="textos">
<?php
$datai=$_POST['datai'];
$dataf=$_POST['dataf'];
$text= 'Durante o período de';
$a= 'a';
$textb= 'foram realizadas a compra dos seguintes itens:<br>';
echo $text.' '.$datai.' a '.$dataf.' '.$textb;
?>
</div>
<div class="tabela">
<?php

// cria a instrução SQL que vai selecionar os dados
$query = sprintf("SELECT * FROM cadcompras 

WHERE datab BETWEEN '$datai' AND '$dataf'  ");
// executa a query
$dados = mysqli_query($mysqli, $query) or die(mysqli_error($mysqli));
// transforma os dados em um array
$linha = mysqli_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysqli_num_rows($dados);
?>

<?php
if($total == 0)  { echo 'Sua pesquisa não retornou nenhum resultado!';}
	// se o número de resultados for maior que zero, mostra os dados//
	if($total > 0) { 
		// inicia o loop que vai mostrar todos os dados
		do {
		$pro=$linha['processo'];
		$fin=$linha['finalidade'];
		$num=$linha['numcompra'];
		$tip=$linha['tipo'];	
		
?>
<table>
<colgroup>
<col width="25%">
<col width="6%">
<col width="60%">
<col width="14%">
</colgroup>
<thead>
<tr>
<th>Processo</th>
<th>Compra</th>
<th>Descrição</th>
<th>tipo</th>
</tr>
</thead>

<colgroup>
<col width="25%">
<col width="6%">
<col width="60%">
<col width="14%">
</colgroup>
<tbody>
<tr>
<td><?php echo "$pro"?></td>
<td><?php echo "$num"?></td>
<td><?php echo "$fin"?></td>
<td><?php echo "$tip"?></td>
</tr>
</tbody>
</table>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = mysqli_fetch_assoc($dados));
	// fim do if 
	}
?>
<?php
// tira o resultado da busca da memória
mysqli_free_result($dados);
?>
</div>

<div class="button">
 <input type="button" name="ok" value="Voltar" onclick="window.location.href='../almoxarifado/painel_alm.php'"/>
</div>

</body>
</html>
