<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<title>Cadastro de fornecedor</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <link rel="stylesheet" type="text/css" href="../../../css/reset.css"/>
  <link rel="stylesheet" type="text/css" href="../../css/bootstrap.css" media="screen"/>
</head>
<body>
<?php include "topo.php"; ?>
<div class="container">
<?php
$nome=$_POST['nome'];
$siape=$_POST['siape'];
$email=$_POST['email'];


 $dupesq = "SELECT * FROM cdservidor WHERE nome = '$nome' OR siape = '$siape'";
$duperaw = mysqli_query($mysqli, $dupesq);

if (mysqli_num_rows($duperaw) > 0) {
   echo "Servidor já cadastrado <a href='../cd_servidor.php'>Voltar</a>";
} else {

$sql = mysqli_query($mysqli, "INSERT INTO cdservidor(nome, siape, email)
VALUES('$nome', '$siape', '$email')");
$resultado = mysqli_query($mysqli, $sql);
{echo "Cadastro efetuado com sucesso!";}
}
?>
<br /> <p class="center"><img src="../../img/salva.gif"/></p><br />
<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='30;URL=../admin.php'>";
?>
</div>
<?php include "footer.php"; ?>
</body>
</html>