<?php
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<title>Cadastro de setor</title>
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<!-- BOOTSTRAP STYLES-->
    <link href="../../css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../../css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../../css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
	 
</head>
<body>
<div class="container">

<?php
$setor=$_POST['setor'];

$sql = mysqli_query($mysqli, "INSERT INTO cdsetor (setor)
VALUES('$setor')");
$resultado = mysqli_query ($mysqli, $sql);
{echo "Cadastro efetuado com sucesso!";
}
?>
<br>
<br>
<p class="center"><img src="../../img/salva.gif"/></p>
<br>
<br>
<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='3;URL=../admin.php'>";
?>
</div>
<?php
include "footer.php";
?>
</body>
</html>