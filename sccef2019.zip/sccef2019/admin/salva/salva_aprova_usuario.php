<?php
include "../../conecta_banco.php";?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<title>Cadastro de usuario</title>
<!-- BOOTSTRAP STYLES-->
    <link href="../../css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../../css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../../css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
</head>
<body>
<div class="container">
<?php
include "../../conecta_banco.php";
$id=$_POST['id'];
$situacao=$_POST['situacao'];
$requisitante=$_POST['requisitante'];
$comprador=$_POST['comprador'];
$diretor=$_POST['diretor'];
$almoxarifado=$_POST['almoxarife'];
$admin=$_POST['admin'];

echo $id . '- ';
echo $admin . '- ';
echo $situacao . '- ';
echo $requisitante . '- ';
echo $comprador . '- ';
echo $diretor . '- ';
echo $almoxarifado;
 //atualiza
 
	$sql = mysqli_query($mysqli, "UPDATE users SET
	admin ='$admin', 
	situacao = '$situacao', 
	requisitante ='$requisitante',
	comprador = '$comprador', 
 	diretor = $diretor, 
	almoxarife = '$almoxarifado' 
	WHERE id ='$id'");
echo "Cadastro efetuado com sucesso!";
?>

<p class="center"><img src="../../img/salva.gif"/></p>
<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='2;URL=../admin.php'>";
?>
</div>
<?php
include "footer.php";
?>
</body>
</html>

