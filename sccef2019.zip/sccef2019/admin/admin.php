﻿<?php
session_start();
	$_SESSION['email'];
	$_SESSION['senha'];
	//header ('autenticara.php');
	$usr=$_SESSION['email'];
	include ("../conecta_banco.php");
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema Administrativo compras públicas.</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   
</head>
<body> <?php include "topo.php"; ?>         
    <div id="wrapper">
         <div class="navbar navbar-inverse navbar-fixed-top">
            <div class="adjust-nav">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">
                        <img src="../img/logoif.jpg" />
                    </a>
                </div>
                          <span class="logout-spn" >
                  <a href="../logout.php" style="color:#fff;">LOGOUT</a>  

                </span>
            </div>
        </div>
        <!-- /. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                                  <li class="active-link">
                        <a href="../logout.php" ><i class="fa fa-desktop "></i>Inicial<span class="badge"></span></a>
                    </li>
                                                     
                </ul>
                            </div>
        </nav>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-lg-12">
                     <h2 class="form-nome">Administrar Sistema</h2>   
                    </div>
                </div>              
                 <!-- /. ROW  -->
                  <hr />
                <div class="row">
                    <div class="col-lg-12 ">
                        <div class="alert alert-info">
                             <strong>Bem vindo <?php echo "$usr! Você está logado!";?> </strong>
                        </div>
                    </div>
                    </div>
                  <!-- /. ROW  --> 
                            <div class="row text-center pad-top">
							<h3>Administrar</h3>
                                   <!-- 1 --->
                  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="aprova_usuario.php">
						    <i class="fa fa-thumbs-o-up fa-3x"></i>
                       <h5>Aprovar <br>Usuário</h5>
                      </a>
                      </div>
                                                       </div>
				   <!-- 2 --->
				   <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="cd_orgao_padrao.php" >
 <i class="fa fa-pencil fa-3x"></i>
                      <h5>Cadastrar <br>orgão <br>padrão</h5>
                      </a>
                      </div>
                                                           </div>
				   <!-- 3 --->
                  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="altera_orgao_padrao.php" >
 <i class="fa fa-edit fa-3x"></i>
                      <h5>Alterar <br>órgão<br> padrão</h5>
                      </a>
                      </div>
                  </div>
				   <!--4 --->
                  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="cd_setor.php" >
 <i class="fa fa-pencil fa-3x"></i>
                      <h5>Incluir <br>Setor</h5>
                      </a>
                      </div>
                  </div>
				   <!-- 5 --->
				 <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                       <div class="div-square">
                           <a href="altera_setor.php" >
 <i class="fa fa-edit fa-3x"></i>
                      <h5>Alterar <br>Setor</h5>
                      </a>
                      </div>
                     </div>
					  <!--6 --->
					 <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                       <div class="div-square">
                           <a href="cd_tipo.php" >
 <i class="fa fa-pencil  fa-3x"></i>
                      <h5>Tipos <br>processos</h5>
                      </a>
                      </div>
                     </div>
              </div>
                  <!-- /. ROW  --> 
                            <div class="row text-center pad-top">
							
                  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="altera_tipo.php" >
 <i class="fa fa-edit fa-3x"></i>
                      <h5>Altera<br> tipos <br>processos</h5>
                      </a>
                      </div>
                  </div>
                  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="cd_servidor.php" >
 <i class="fa fa-user fa-3x"></i>
                      <h5>Cadastro <br> de<br> Servidor</h5>
					 </a>
                      </div>                     
                  </div>
                  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="" >
 <i class="fa fa-asterisk fa-3x"></i>
                      <h4></h4>
                      </a>
                      </div>
                  </div>
                     <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href=".php" >
 <i class="fa fa-asterisk fa-3x"></i>
                      <h5></h5>
                      </a>
                      </div>
                    
    </div>
                        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="" >
 <i class="fa fa-asterisk fa-3x"></i>
                      <h5></h5>
					                       </a>
                      </div>
                  </div>
                  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="" >
 <i class="fa fa-asterisk fa-3x"></i>
                      <h4></h4>
                      </a>
                      </div>
                  </div>
                  </div> 
                  <!-- /. ROW fim do ciclo de cadastro gerais -->   
                  <!-- /. ROW  --> 
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
        <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="js/jquery.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="js/bootstrap.min.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="js/custom.js"></script>
</div>

 <?php include "footer.php"; ?> </body>
</html>
