<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../img/icone_barra.jpg" />
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema Administrativo compras públicas.</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
	<link rel="icon" type="image/jpg" href="../img/icone_barra.jpg" />    
<script type="text/javascript">
	  function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
 function validacao() {

 if(document.form.id.value=="Selecione...")
{
alert("Por favor selecione o usuario.");
document.form.id.focus();
return false;
}

if(document.form.situacao.value=="Selecione...")
{
alert("Por favor informe a situacao.");
document.form.situacao.focus();
return false;
}


if(document.form.admin.value=="Selecione...")
{
alert("Por favor informe se o usuário é administrador.");
document.form.admin.focus();
return false;
}
}
	 </script>
<body> 
	  <div class="container"> 
	  <?php include "topo.php"; echo 'Usuário logado: '. $logado; ?> 
	  </div> 
    
	 <div class="container">
<form name="form" method="POST" action="salva/salva_aprova_usuario.php" onSubmit="return validacao();">
<fieldset class="grupo">
		  <div class="form-group">
	<?php	
	$query = mysqli_query($mysqli, "SELECT * FROM users");
?>
 <label class="form-control" for="">Selecione usuario</label>
 <select class="form-control" name="id">
 <option class="form-control" name="">Selecione...</option>
 <?php while($uas = mysqli_fetch_array($query)) { ?>
 <option class="form-control" value="<?php echo $uas['id'] ?>"><?php echo $uas['email'] ?></option>
 <?php } ?>
 </select>
 </div>
  <!---Ativa desativa usuario-->
		<div class="form-group">
 <?php	   
  $query = mysqli_query($mysqli, "SELECT * FROM cdsituacao");
?>
 <label class="form-control" for="">Ativa/desativa user</label>		     
 <select class="form-control" name="situacao">
 <option class="form-control" name="">Selecione...</option>
 <?php while($setor = mysqli_fetch_array($query)) { ?>
 <option class="form-control" value="<?php echo $setor['idsit'] ?>"><?php echo $setor['situacao'] ?></option>
 <?php } ?>
 </select>
 </div>
  </fieldset>
  <!---agrupar acesso modulo-->
   <!---acesso modulo requisitante-->
 
  <div class="form-group">
	<?php	
	$query = mysqli_query($mysqli, "SELECT * FROM condicao");
?>
 <label class="form-control" for="">Acessa como Requisitante</label>
 <select class="form-control" name="requisitante">
 <option class="form-control" name="">Selecione...</option>
 <?php while($uas = mysqli_fetch_array($query)) { ?>
 <option class="form-control" value="<?php echo $uas['idc'] ?>"><?php echo $uas['condicao'] ?></option>
 <?php } ?>
 </select>
 </div>
  <fieldset class="grupo">
 
  <!---acesso modulo comprador-->
 <div class="form-group">
	<?php	
	$query = mysqli_query($mysqli, "SELECT * FROM condicao");
?>
 <label class="form-control" for="">Acessa Compras</label>
 <select class="form-control" name="comprador">
 <option class="form-control" name="">Selecione...</option>
 <?php while($uas = mysqli_fetch_array($query)) { ?>
 <option class="form-control" value="<?php echo $uas['idc'] ?>"><?php echo $uas['condicao'] ?></option>
 <?php } ?>
 </select>
 </div>
 
  <!---acesso modulo diretor-->
<div class="form-group">
	<?php	
	$query = mysqli_query($mysqli, "SELECT * FROM condicao");
?>
 <label class="form-control" for="">Acessa Diretor</label>
 <select class="form-control" name="diretor">
 <option class="form-control" name="">Selecione...</option>
 <?php while($uas = mysqli_fetch_array($query)) { ?>
 <option class="form-control" value="<?php echo $uas['idc'] ?>"><?php echo $uas['condicao'] ?></option>
 <?php } ?>
 </select>
 </div>
 
  <!---acesso modulo almoxarife-->
<div class="form-group">
	<?php	
	$query = mysqli_query($mysqli, "SELECT * FROM condicao");
?>
 <label class="form-control" for="">Acessa Almoxarifado</label>
 <select class="form-control" name="almoxarife">
 <option class="form-control" name="">Selecione...</option>
 <?php while($uas = mysqli_fetch_array($query)) { ?>
 <option class="form-control" value="<?php echo $uas['idc'] ?>"><?php echo $uas['condicao'] ?></option>
 <?php } ?>
 </select>
 </div>
  <!---acesso modulo Admin-->
 <div class="form-group">
	<?php	
	$query = mysqli_query($mysqli, "SELECT * FROM condicao");
?>
 <label class="form-control" for="">Acessa Administrador</label>
 <select class="form-control" name="admin">
 <option class="form-control" name="">Selecione...</option>
 <?php while($uas = mysqli_fetch_array($query)) { ?>
 <option class="form-control" value="<?php echo $uas['idc'] ?>"><?php echo $uas['condicao'] ?></option>
 <?php } ?>
 </select>
 </div>
 </fieldset>
<div class="form-group">
<input type="submit" value="Liberar" />
 <input type="button" name="cancela" value="Cancelar" onclick="window.location.href='admin.php'"/>
</div>
</form>
</div>
<?php include "footer.php" ?> 
</body>
</html>