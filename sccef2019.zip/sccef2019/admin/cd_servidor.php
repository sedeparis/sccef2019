<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../img/icone_barra.jpg" />
	 <title>Cadastro de requisitante</title>
	 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	 <script type="text/javascript">
	 function validacao() {
 if(document.form.setor.value=="Selecione...")
{
alert("Por favor selecione o setor.");
document.form.setor.focus();
return false;
}

if(document.form.nome.value=="")
{
alert("Por favor insira o nome do requisitante.");
document.form.nome.focus();
return false;
}

if(document.form.siape.value=="")
{
alert("Por favor insira o siape do requisitante.");
document.form.siape.focus();
return false;
}

}
	 </script>
 </head>
	 <body> <div class="container"><?php include "topo.php"; echo 'Usuário Logado: '; echo $logado; ?> 
 </div>
	 
	 <div class="container">
	<h2 class="form-nome">Cadastro de servidor</h2>
	<form name="form" method="post" action="salva/salva_servidor.php"  onSubmit="return validacao();">
	<fieldset class="grupo">
		 <div class="form-group">
			<label class="form-control">Nome:</label>
<input type="text" class="form-control"  name="nome" size="60" title="digite o nome"/>
<label class="form-control">Siape:</label>
<input type="text" class="form-control"  name="siape" size="20" maxlength="7" title="digite o siape"/>
<label class="form-control">Email:</label>
<input type="text" class="form-control"  name="email" size="20" maxlength="7" title="digite o siape"/>
	</div>
	</fieldset>

	<fieldset class="grupo">
		 <div class="form-group">
	<input type="submit" name="enviar" value="Cadastrar servidor"/>
	<input type="reset" name="limpar" value="Limpar"/>
	<input type="button" name="cancela" value="Cancelar" onclick="window.location.href='admin.php'"/>
	</div>
</form>
</div>
<?php include "footer.php"; ?> 
 </body>
 </html>