﻿ <?php
include "../../conecta_banco.php";
include "../../conecta_banco_pdi.php";
?>
<!DOCTYPE HTML>
<html lang="pt_br">
 <head>
	 <title>Lista compras por periodo</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	 <link href="../../css/print_tab.css" rel="stylesheet" />
	  <link href="../../css/print_div.css" rel="stylesheet" />
	   <link href="../../css/print_fontes.css" rel="stylesheet" />
</head>
 <body>
	 <div class="cabecalho">
	  <?php include "cabecalho.php"; ?> 
	  </div>
	 <div class="titulo">
  	 <h3>Compras empenhadas por fornecedor</h3>
	 </div>
	 <div class="tabela">
<?php
$fornecedor=$_POST['fornecedor'];
// cria a instrução SQL que vai selecionar os dados da soma total de empenho
$result = mysql_query("SELECT SUM(valori) AS valor_soma FROM caditem WHERE quant_ult_emp<>0 AND idfornecedor='$fornecedor'");
 //executa a query
$row = mysql_fetch_assoc($result);
$sum = $row['valor_soma'];
?>

<table>
<tr>
<td><?php echo $fornecedor?>
</td>
</tr>
<tr>
<td width="60%"><span class="rel">Total empenhado R$:</span>
</td>
<td width="40%"><?php echo number_format($sum,2, ",",".");?>
</td>
</tr>
</table>
<br>

</div>

<div class="button">
 <input type="button" name="ok" value="Voltar" onclick="window.location.href='../painel_alm.php'"/>
</div>
<?php include "footer.php"; ?> 
</body>
</html>

