<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado com usuário: ';
echo	$logado;
	echo '</div>';
include "../../conecta_banco.php";
?>
<!DOCTYPE HTML>
<html lang="pt_br">
 <head>
 <link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Pagamento</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 <link href="../../css/print_tab.css" rel="stylesheet" />
	  <link href="../../css/print_div.css" rel="stylesheet" />
	   <link href="../../css/print_fontes.css" rel="stylesheet" />
 </head>
	 <body>
	 
	<div class="cabecalho">
	  <?php include "cabecalho.php"; ?> 
	  </div>
	 <div class="titulo">
	  <h3>SOLICITAÇÃO DE PAGAMENTO</h3>
	  </div>
	
 <?php
// cria a instrução SQL que vai selecionar os dados para o cabeçalho
$sql = mysqli_query($mysqli, "SELECT * FROM cdorgao WHERE orgao_principal = 'S'");
 $count = mysqli_num_rows($sql);
if ($count == 0) 
{ echo "Nenhum resultado!" ;}
while ($dados = mysqli_fetch_array($sql))
{ 
 $endereco=$dados['endereco'];
 $orgao=$dados['nome'];
 $dirad=$dados['gestor'];
 $dirge=$dados['diretor'];
$local= $dados['cidade'];
 $uf=$dados['uf'];
 $fonte=$dados['fonte'];
 $preprocesso=$dados['iniprocesso'];
 }
 ?>
 
 
<?php
$processo=$_POST['processo'];
$fornecedor=$_POST['fornecedor'];
$requisicao=$_POST['requisicao'];
$requisita=$_POST['solic'];
$nfe=$_POST['nfe'];
$datap=$_POST['data'];
$valor=$_POST['valor'];

// cria a instrução SQL que vai selecionar os dados do processo e fornecedor
$query = sprintf("SELECT * FROM cadcompras WHERE idcompra ='$processo'");
// executa a query
$dadosii = mysqli_query($mysqli, $query) ;
// transforma os dados em um array
$linhaii = mysqli_fetch_assoc($dadosii);
// calcula quantos dados retornaram
$totalii = mysqli_num_rows($dadosii);
	// se o número de resultados for maior que zero, mostra os dados//
	if($totalii > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
			$nprocesso = $linhaii['processo'];
		$finalidade = $linhaii['finalidade'];
	$tipo = $linhaii['tipo'];
	$numcompra = $linhaii['numcompra'];
	$requis = $linhaii['numreq'];
	$solic = $linhaii['nomereq'];
	
		// finaliza o loop que vai mostrar os dados
		}while($linhaii = mysqli_fetch_assoc($dadosii));
	// fim do if 
	}
	?>

<div class="textos">
<span class="subtitulo">
Processo:
</span>
<span class="rsubtitulo">
<?php echo $nprocesso?>
</span>
<br>
<span class="subtitulo">
Finalidade:
</span>
<span class="rsubtitulo">
 <?php echo $finalidade ?> 
 </span>
 <br>
<span class="subtitulo">
Compra-modalidade:
</span>
<span class="rsubtitulo">
<?php echo $numcompra." - ".$tipo ?>
</span>
<br><br><br>
<?php
// tira o resultado da busca da memória
mysqli_free_result($dadosii);
?>
 
<p class="normal">Solicitamos o pagamento da Nota nº <?php echo "$nfe"?> no valor de R$ <?php echo "$valor"?>.<br>
Os Itens foram recebidos de acordo conforme nota fiscal e estão aptos para pagamento:</p>
</div>


<?php
// cria a instrução SQL que vai selecionar os dados do processo e fornecedor
$queryb = sprintf("SELECT * FROM cadfornecedor 
INNER JOIN cdbanco ON cadfornecedor.banco=cdbanco.idbanco WHERE idforn ='$fornecedor'");
// executa a query
$dadosb = mysqli_query($mysqli, $queryb) ;
// transforma os dados em um array
$linhab = mysqli_fetch_assoc($dadosb);
// calcula quantos dados retornaram
$totalb = mysqli_num_rows($dadosb);
	// se o número de resultados for maior que zero, mostra os dados//
	if($totalb > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
			$nome = $linhab['nome'];
		$cnpj = $linhab['cnpj'];
	$banco = $linhab['banco'];
	$conta = $linhab['conta'];
	$ag = $linhab['agencia'];
	
	
		// finaliza o loop que vai mostrar os dados
		}while($linhab = mysqli_fetch_assoc($dadosb));
	// fim do if 
	}
	?>
	<div class="textos">
<span class="subtitulo">
Fornecedor:
</span>
<span class="rsubtitulo">
 <?php echo $nome ?>
 </span>
<br>
<span class="subtitulo">
Cnpj:
</span>
<span class="rsubtitulo">
 <?php echo $cnpj ?>
 </span>
<br>
<span class="subtitulo">
Banco:
</span>
<span class="rsubtitulo">
 <?php echo $banco ?>
 </span>
<br>
<span class="subtitulo">
Agência:
</span>
<span class="rsubtitulo">
 <?php echo $ag ?>
 </span>
 <span class="subtitulo">
Conta:
</span>
<span class="rsubtitulo">
 <?php echo $conta ?>
 </span>
<br>
<?php
// tira o resultado da busca da memória
mysqli_free_result($dadosb);
?>
</div>
<div class="textos">
	
	<p class="direita"><?php echo "$local-$uf" ?>, em ___/____/20___ </p>
	<br>
	<br>
	<?php
// cria a instrução SQL que vai selecionar os dados  requisitante
$queryf = sprintf("SELECT * FROM cdrequisitante WHERE idr ='$requisita'");
// executa a query
$dadosf = mysqli_query($mysqli, $queryf) ;
// transforma os dados em um array
$linhaf = mysqli_fetch_assoc($dadosf);
// calcula quantos dados retornaram
$totalf = mysqli_num_rows($dadosf);
	// se o número de resultados for maior que zero, mostra os dados//
	if($totalf > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
			$nomesolic = $linhaf['nome'];
	$siape = $linhaf['siape'];
	
	
		// finaliza o loop que vai mostrar os dados
		}while($linhaf = mysqli_fetch_assoc($dadosf));
	// fim do if 
	}
	?>
	<div class="textos">

<br />
<p>_______________________________________________</p>
<p class="center"><?php echo "$nomesolic" ?><br />
 Solicitante <br />Siape  
 <?php echo "$siape" ?>
 <br />
 </p>
	<br>
	<?php
// tira o resultado da busca da memória
mysqli_free_result($dadosf);
?>
</div>
<div class="button">
<input type="button" name="cancela" value="Voltar" onclick="window.location.href='../painel_alm.php'"/>
</div>

</body>
</html>