<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado com usuário: ';
echo	$logado;
	echo '</div>';
include "../../conecta_banco.php";
?>
 <!DOCTYPE HTML><html lang="pt-br">
 <head>
 <link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Cadastro do empenho</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	 <link rel="stylesheet" href="../../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../../css/custom.css" type="text/css"/>
	  <link rel="stylesheet" href="../../css/bootstrap.css" type="text/css"/>
	
	  <script type="text/javascript">
	  function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
	 </script>
   </head>
	 <body>
   <div class="container">
	  <?php include "topo.php"; ?> 
	  </div>
	 <div class="container">
	<h2 class="form-nome">Alterar quantidade itens para gerar solicitação de empenho</h2>
<p>ATENÇÃO!:<br /><br />
	A quantidade licitada mostrada é a quantidade máxima de itens disponíveis para empenhar. <br />
	Caso já tenha ocorrida um empenho parcial, a quantidade usada anteriormente já foi descontada e esse valor é mostrado no campo Quantidade já empenhada.<br />
	Caso não queira empenhar algum item relacionado, insira 0 na quantidade.</p><br />
	</div>
	 <div class="container">
	<?php
	$processo=$_POST['altera'];
	
 $sql = "SELECT * from caditem WHERE idcompra = '$processo' AND quant_util>0 AND (finalizado = 0)";
 $res = mysqli_query($mysqli, $sql) or die(mysqli_error($mysqli));
  if (mysqli_num_rows($res) == 0 ) {
  echo "Não há item empenhado para estorno. <a href='../painel_alm.php'>Voltar</a>";}
  else {
  if (mysqli_num_rows($res) > 0 ) {
  echo '<form method="post" action="../salva/salva_estorna_sol_empenha.php">';
  while ( $row = mysqli_fetch_assoc($res) )
	  {
   //echo ' ' . $row["iditem"]. '-'; // mostra iditem oculta
 echo 'Nº do item na licitação: ' . $row["nitem"]. '<br>'; // numero do item
  echo 'Descrição: ' . $row["ditem"]. '<br>'; // descrição do item
  echo 'Quantidade licitada: ' . $row["quant_lic"]. '  ' .$row["un"]. '<br>'; // quantidade licitada do item e a unidade
  echo 'Quantidade disponível: ' . $row["quant_disp"]. '<br>'; // quantidade disponivel para empenhar do item
  echo 'Quantidade já solicitada para ser empenhada: ' . $row["quant_util"]. '<br />'; // quantidade empenhada numa cota anterior
   echo 'Quantidade que pretende solicitar estorno <span class="colored">(Caso não queira estornar esse item, zere esse valor): </span> <input type="text" size="4" name="quant_emp_now['.$row["iditem"].']" value="'.$row["quant_util"].'"> '."\n"; // quantidade que vai ser estornada agora
  echo '<input type="hidden" size="2" name="quant_lic['.$row["iditem"].']" value="'.$row["quant_lic"].'"> '."\n"; // quantidade total licitada
  echo '<input type="hidden" size="2" name="quant_disp['.$row["iditem"].']" value="'.$row["quant_disp"].'"> '."\n"; // quanto em tenho disponivel levando em conta que eu ja possa ter empenhado alguma coisa anteriormente
  echo '<input type="hidden" size="5" name="quant_util['.$row["iditem"].']" value="'.$row["quant_util"].'"> '."\n";  // quantidade que ja empenhei
    echo '<input type="hidden" size="5" name="quant_ult_emp['.$row["iditem"].']" value="'.$row["quant_ult_emp"].'"> '."\n";  // quantidade ja empenhado
  echo '<input type="hidden" size="5" name="valor['.$row["iditem"].']" value="'.$row["valor"].'"> '."\n";  // valor do item
  echo '<input type="hidden" name="iditem[]" value="'.$row["iditem"].'"> '."\n";  // id do item
  echo "<hr>\n";
  }
  echo '<input type="submit" name="submit" value="Enviar para Empenhar">';
   echo '';
  echo '</form>';
  }
  }
?>
<input type="button" name="cancela" value="Cancelar" onclick="window.location.href='../painel_alm.php'"/>
</div>

<?php include "footer.php"?>

</body>
</html>