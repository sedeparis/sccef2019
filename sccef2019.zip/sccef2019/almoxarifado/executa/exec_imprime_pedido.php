<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado com usuário: ';
echo	$logado;
	echo '</div>';
include "../../conecta_banco.php";
?>
  <!DOCTYPE HTML>
  <html lang="pt-br">
 <head>
 <link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Imprime pedido</title>
	  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 <link href="../../css/print_tab.css" rel="stylesheet" />
	  <link href="../../css/print_div.css" rel="stylesheet" />
	   <link href="../../css/print_fontes.css" rel="stylesheet" />
 </head>
	 <body>
	  <div class="cabecalho">
	  <?php include "cabecalho.php"; ?> 
	  </div>
	 <div class="titulo">
	  <h3>PEDIDO DE FORNECIMENTO</h3>
	  </div>
	
	 <?php
	 //carrega dados do formulario anterior
$processo=$_POST['processo'];
$fornecedor=$_POST['fornecedor'];
$nempenho=$_POST['nempenho'];

// cria a instrução SQL que vai selecionar os dados para o cabeçalho
$sql = mysqli_query($mysqli, "SELECT * FROM cdorgao WHERE orgao_principal ='S'");
 $count = mysqli_num_rows( $sql);
if ($count == 0) 
{ echo "orgao nao cadastrado!" ;}
while ($dados = mysqli_fetch_array($sql))
{ echo "";
$endereco=$dados['endereco'];
 $orgao=$dados['nome'];
 $dirad=$dados['gestor'];
 $dirge=$dados['diretor'];
$local= $dados['cidade'];
 $uf=$dados['uf'];
 $fonte=$dados['fonte'];
 $preprocesso=$dados['iniprocesso'];
 }
?>
 
<?php
// cria a instrução SQL que vai selecionar os dados
$query = sprintf("SELECT * FROM cadcompras WHERE idcompra ='$processo'");
// executa a query
$dadosii = mysqli_query( $mysqli, $query) or die(mysqli_error($mysqli));
// transforma os dados em um array
$linhaii = mysqli_fetch_assoc($dadosii);
// calcula quantos dados retornaram
$totalii = mysqli_num_rows($dadosii);
?>
<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($totalii > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
$finalidade = $linhaii['finalidade'];
$numcompra =  $linhaii['numcompra'];
$tipo =  $linhaii['tipo'];
$gerencia =  $linhaii['gerencia'];
$nomereq= $linhaii['nomereq'];
$proces= $linhaii['processo'];
		?>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linhaii = mysqli_fetch_assoc($dadosii));
	// fim do if 
	}
?>
<div class="textos">

<br>
<span class="subtitulo">
Processo:
</span>
<span class="rsubtitulo">
<?php echo "$proces"?>
</span>
<br>
<span class="subtitulo">
Finalidade:
</span>
<span class="rsubtitulo">
 <?php echo $finalidade ?> 
 </span>
 <br>
<span class="subtitulo">
Compra-modalidade:
</span>
<span class="rsubtitulo">
<?php echo $numcompra." - ".$tipo ?>
</span>
<br>


<?php
// selecionar dados do fornecedor
$sqlb = mysqli_query($mysqli, "SELECT * FROM cadfornecedor WHERE idforn ='$fornecedor'");
 $countb = mysqli_num_rows($sqlb);
if ($countb == 0) 
{ echo "Nenhum resultado!<br />"; } 
 
while ($dadosb = mysqli_fetch_array($sqlb))
{ echo "<span class='subtitulo'><br />Prezado fornecedor: </span><span class='rsubtitulo'> $dadosb[nome] (CNPJ:</span> $dadosb[cnpj]).</span>";
echo " Solicitamos o fornecimento dos itens abaixo conforme empenho $nempenho.";
$fornecedorx= $dadosb['nome'];
$cnpj =$dadosb['cnpj'];
}
echo '<br>';
// cria a instrução SQL que vai selecionar os dos itens
$queryx = ("SELECT * FROM produto INNER JOIN 
entrada_produto_ee ON produto.id=entrada_produto_ee.id_produto_ee 
INNER JOIN  cdunidade ON produto.un=cdunidade.idun 
WHERE nempenho_ee ='$nempenho' AND (fornecedora ='$fornecedor') ");
// executa a query
$dadosx = mysqli_query($mysqli, $queryx) or die(mysqli_error($mysqli));
// transforma os dados em um array
$linhax = mysqli_fetch_assoc($dadosx);
// calcula quantos dados retornaram
$totalx = mysqli_num_rows($dadosx);
?>
<!-- mostra itens empenhados-->

<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($totalx > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
$num =$linhax['valor_unitario'];
$nitem = $linhax['nitem'];
$ditem= $linhax['descricao'];
$quanto= $linhax['qtde_ee'];
$un= $linhax['unidade'];
$valori = $num * $quanto;
$dite=substr("$ditem", 0, 150)."..." ;
$nume= number_format($num,2, ",","");
$valoris=number_format($valori,2, ",",".");
?>
<table>
<colgroup>
<col width="6%">
<col width="58%">
<col width="8%">
<col width="8%">
<col width="8$">
<col width="12%">

</colgroup>
<thead>
<tr>
<th width="6%">Item</th>
<th width="58%">Descrição</th>
<th width="8%">Qt</th>
<th width="8%">Un</th>
<th width="8%">R$/un</th>
<th width="12%">R$/total</th>
</tr>
</thead>
</table>
<table>
<colgroup>
<col width="6%">
<col width="58%">
<col width="8%">
<col width="8%">
<col width="8$">
<col width="12%">

</colgroup>
<tbody>
<tr>
<td width="6%"><?php echo "<p class='var'>$nitem</p>"?></td>
<td width="58%"><?php echo "<p class='var'>$dite</p>"?></td>
<td width="8%"><?php echo "<p class='var'>$quanto</p>"?></td>
<td width="8%"><?php echo "<p class='var'>$un</p>"?></td>
<td width="8%"><?php echo "<p class='var'>$nume</p>"?></td>
<td width="12%"><?php echo "<p class='var'>$valoris</p>"?></td>

</tr>
</tbody>
</table>

<?php 
		// finaliza o loop que vai mostrar os dados
		}while($linhax = mysqli_fetch_assoc($dadosx));
	// fim do if 
	}
?>

</div>
	<div class="textos">
	<p class="direita"><?php echo "$local-$uf" ?>, <?php echo date('d-m-Y') ?></p>
<br />
<br />
<br />
	
<p class="center">________________________________</p>
	<p class="center">
	<p class="center">Requisitante</p>




<input type="button" name="cancela" value="Voltar" onclick="window.location.href='../painel_alm.php'"/>
</div>
<?php
// tira o resultado da busca da memória
mysqli_free_result($dadosx);
?>
<?php
// tira o resultado da busca da memória
mysqli_free_result($dadosii);
?>
</div>

</body>
</html>


