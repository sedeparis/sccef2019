<?php 
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado com usuário: ';
echo	$logado;
	echo '</div>';
include "../../conecta_banco.php";
?>
<!DOCTYPE HTML>
 <html lang="pt-br">
 <head>
  <link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Imprime requerimento de empenho</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 <link href="../../css/print_tab.css" rel="stylesheet" />
	  <link href="../../css/print_div.css" rel="stylesheet" />
	   <link href="../../css/print_fontes.css" rel="stylesheet" />
 </head>
	 <body>
	 <div class="cabecalho">
	  <?php include "cabecalho.php"; ?> 
	  </div>
	 <div class="titulo">
<h3>SOLICITAÇÃO DE EMPENHO</h3>
  </div>
	 <?php
// cria a instrução SQL que vai selecionar os dados para o cabeçalho
$sql = mysqli_query($mysqli, "SELECT * FROM cdorgao WHERE orgao_principal = 'S'");
 $count = mysqli_num_rows($sql);
if ($count == 0) 
{ echo "Nenhum resultado!" ;}
while ($dados = mysqli_fetch_array($sql))
{ echo "";
 $endereco=$dados['endereco'];
 $orgao=$dados['nome'];
 $dirad=$dados['gestor'];
 $dirge=$dados['diretor'];
$local= $dados['cidade'];
 $uf=$dados['uf'];
 $fonte=$dados['fonte'];
 $preprocesso=$dados['iniprocesso'];
 }
 ?>
 </div>
 
 <?php
//carrega dados do formulario do cdfolhaempenho
$processo=$_POST['processo'];
$idfornecedor=$_POST['fornecedor'];
//$solic=$_POST['solic'];
//$data= $_POST['data'];




// cria a instrução SQL que vai selecionar os dados do processo e fornecedor
$query = sprintf("SELECT * FROM cadcompras WHERE processo ='$processo'");
// executa a query
$dadosii = mysqli_query($mysqli, $query) ;
// transforma os dados em um array
$linhaii = mysqli_fetch_assoc($dadosii);
// calcula quantos dados retornaram
$totalii = mysqli_num_rows($dadosii);
	// se o número de resultados for maior que zero, mostra os dados//
	if($totalii > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
		$finalidade = $linhaii['finalidade'];
	$tipo = $linhaii['tipo'];
	$numcompra = $linhaii['numcompra'];
	$gerencia = $linhaii['gerencia'];
	$requis = $linhaii['numreq'];
	$solic = $linhaii['nomereq'];
	
		// finaliza o loop que vai mostrar os dados
		}while($linhaii = mysqli_fetch_assoc($dadosii));
	// fim do if 
	}
	?>
<!---mostra dados gerais da licitacao--->
<div class="textos">
<span class="subtitulo">
Requisição Nº:
</span>
<span class="rsubtitulo">
 <?php echo "$requis"?>
 </span>
<br>
<span class="subtitulo">
Processo:
</span>
<span class="rsubtitulo">
<?php echo "$processo"?>
</span>
<br>
<span class="subtitulo">
Finalidade:
</span>
<span class="rsubtitulo">
 <?php echo $finalidade ?> 
 </span>
 <br>
<span class="subtitulo">
Compra-modalidade:
</span>
<span class="rsubtitulo">
<?php echo $numcompra." - ".$tipo ?>
</span>
<br>
<?php
// tira o resultado da busca da memória
mysqli_free_result($dadosii);
?>
<?php

// cria a instrução SQL que vai selecionar os dados do fornecedor
$queryx = sprintf("SELECT * FROM cadfornecedor WHERE idforn ='$idfornecedor'");
// executa a query
$dadosx = mysqli_query($mysqli, $queryx) ;
// transforma os dados em um array
$linhax = mysqli_fetch_assoc($dadosx);
// calcula quantos dados retornaram
$totalx = mysqli_num_rows($dadosx);
	// se o número de resultados for maior que zero, mostra os dados//
	if($totalx > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
		$nomef = $linhax['nome'];
	$cnpj = $linhax['cnpj'];
	
		// finaliza o loop que vai mostrar os dados
		}while($linhax = mysqli_fetch_assoc($dadosx));
	// fim do if 
	}
	?>
<span class="subtitulo">
Fornecedor:
</span>
<span class="rsubtitulo">
<?php echo $nomef ?>
</span>
</div>
<?php
// tira o resultado da busca da memória
mysqli_free_result($dadosx);
?>

<?php
// cria a instrução SQL que vai selecionar os dos itens
$queryb = ("SELECT  *  FROM produto 
INNER JOIN entrada_produto ON produto.id = entrada_produto.id_produto
INNER JOIN cadfornecedor ON produto.fornecedora = cadfornecedor.idforn
 WHERE idprocesso = '$processo'");
// executa a query
$dados = mysqli_query ($mysqli, $queryb);
// transforma os dados em um array
$linha = mysqli_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysqli_num_rows($dados);
?>


<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($total > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
//$id =$linha['id_produto'];
$nitem = $linha['nitem'];
$ditem= $linha['descricao'];
$quantmax = $linha['estoque_maximo'];
$un= $linha['unidade'];
$valor= $linha['valor_unitario'];
$fornecedor= $linha['nome'];
$valori =($valor*$quantmax);
 ?>
<table>
<colgroup>
<col width="05%">
<col width="35%">
<col width="10%">
<col width="10%">
<col width="10%">
<col width="15%">
<col width="15%">
</colgroup>
<thead>
<tr>
<th>Item</th>
<th>Descrição</th>
<th>Un</th>
<th>Qtd max</th>
<th>R$/un</th>
<th>R$/total</th>
<th>Fornecedor</th>
</tr>
</thead>
<tbody>
<tr>
<td><?php echo $nitem ?></td>
<td><?php echo $ditem ?></td>
<td><?php echo $un ?></td>
<td><?php echo $quantmax ?></td>
<td><?php echo number_format($valor,2, ",",".");?></td>
<td><?php echo number_format($valori,2, ",",".");?></td>
<td><?php echo $fornecedor ?></td>
</tr>
</tbody>
</table>

<?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = mysqli_fetch_assoc($dados));
	// fim do if 
	}
?>

<?php
// tira o resultado da busca da memória
mysqli_free_result($dados);
?>

<?php
// cria a instrução SQL que vai selecionar os dados  requisitante
$queryf = sprintf("SELECT * FROM cdrequisitante WHERE idr ='$solic'");
// executa a query
$dadosf = mysqli_query($mysqli, $queryf) ;
// transforma os dados em um array
$linhaf = mysqli_fetch_assoc($dadosf);
// calcula quantos dados retornaram
$totalf = mysqli_num_rows($dadosf);
	// se o número de resultados for maior que zero, mostra os dados//
	if($totalf > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
			$nomesolic = $linhaf['nome'];
	$siape = $linhaf['siape'];
	
	
		// finaliza o loop que vai mostrar os dados
		}while($linhaf = mysqli_fetch_assoc($dadosf));
	// fim do if 
	}
	?>
	<div class="textos">
<span class="subtitulo">Autorização do empenho:</span>
<p class="var">(  ) Solicito o empenho no quantitativo citado. </p>
<p class="var">(  ) Não efetuar empenho. Justificativa: </p>
<p class="direita"><?php echo "$local-$uf,&nbsp;&nbsp;&nbsp;"?>__/__/____</p>
<br />
<p>_______________________________________________</p>
<p class="center"><?php echo "$nomesolic"?><br />
 Solicitante <br />Siape  
 <?php echo "$siape"?><br />
 </p>
 
<?php
// tira o resultado da busca da memória
mysqli_free_result($dadosf);
?>
</div>
<div class="button">
<input type="button" name="cancela" value="Voltar" onclick="window.location.href='../painel_alm.php'"/>
</div>

</body>
</html>