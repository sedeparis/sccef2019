<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado com usuário: ';
echo	$logado;
	echo '</div>';
include "../../conecta_banco.php";
?>
  <!DOCTYPE HTML>
  <html lang="pt-br">
 <head>
 <link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Imprime requerimento de empenho</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 <link href="../../css/print_tab.css" rel="stylesheet" />
	  <link href="../../css/print_div.css" rel="stylesheet" />
	   <link href="../../css/print_fontes.css" rel="stylesheet" />
 </head>
	 <body>
	 <div class="cabecalho">
	  <?php include "cabecalho.php"; ?> 
	  </div>
	 <div class="titulo">
	  <h3>ESPELHO/AUTORIZAÇÃO DE EMPENHO</h3>
	  </div>
	 <?php
 //carrega dados do formulario do cdfolhaempenho
$processo=$_POST['processo'];
$fornecedor=$_POST['fornecedor'];
$data=$_POST['data'];
 //cria a instrução SQL que vai selecionar os dados para o cabeçalho
$sql = mysqli_query($mysqli, "SELECT * FROM cdorgao WHERE orgao_principal ='S'");
 $count = mysqli_num_rows($sql);
if ($count == 0) 
{ echo "Nenhum resultado!" ;}
while ($dados = mysqli_fetch_array($sql))
{ echo "";
 
$endereco=$dados['endereco'];
 $orgao=$dados['nome'];
 $dirad=$dados['gestor'];
 $dirge=$dados['diretor'];
$local= $dados['cidade'];
 $uf=$dados['uf'];
 $fonte=$dados['fonte'];
 $preprocesso=$dados['iniprocesso'];
 }
?>
 
<?php
// cria a instrução SQL que vai selecionar os dados do processo e fornecedor
$query = sprintf("SELECT * FROM cadcompras WHERE idcompra ='$processo'");
// executa a query
$dadosii = mysqli_query($mysqli, $query) or die(mysqli_error($mysqli));
// transforma os dados em um array
$linhaii = mysqli_fetch_assoc($dadosii);
// calcula quantos dados retornaram
$totalii = mysqli_num_rows($dadosii);
?>
<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($totalii > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
	$requis = $linhaii['numreq'];
	$finalidade = $linhaii['finalidade'];
	$tipo = $linhaii['tipo'];
	$numcompra = $linhaii['numcompra'];
	$uasg = $linhaii['uasg'];
	$proces = $linhaii['processo'];
		$solicita = $linhaii['nomereq'];
	
		?>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linhaii = mysqli_fetch_assoc($dadosii));
	// fim do if 
	}
?>
<!---mostra dados gerais da licitacao--->

<div class="textos">
<span class="subtitulo">
Requisição Nº:
</span>
<span class="rsubtitulo">
 <?php echo "$requis"?>
 </span>
<br>
<span class="subtitulo">
Processo:
</span>
<span class="rsubtitulo">
<?php echo "$proces"?>
</span>
<br>
<span class="subtitulo">
Finalidade:
</span>
<span class="rsubtitulo">
 <?php echo $finalidade ?> 
 </span>
 <br>
<span class="subtitulo">
Compra-modalidade:
</span>
<span class="rsubtitulo">
<?php echo $tipo." - ". $numcompra." - Uasg: ".$uasg ?>
</span>
<br>

</div>
<div class="tabela">
<?php
// cria a instrução SQL que vai selecionar os dos itens
$querya = ("SELECT * FROM produto INNER JOIN 
entrada_produto_ie ON produto.id=entrada_produto_ie.id_produto_ie 
INNER JOIN cdunidade ON produto.un=cdunidade.idun
INNER JOIN cded ON produto.ed=cded.ided
WHERE idprocesso ='$processo' AND (fornecedora ='$fornecedor')  AND (data_entrada_ie = '$data') AND qtde_ie>0");
// executa a query
$dados = mysqli_query($mysqli, $querya) or die(mysqli_error($mysqli));
// transforma os dados em um array
$linha = mysqli_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysqli_num_rows($dados);
?>
<!-- mostra itens empenhados-->

<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($total > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
$num =$linha['valor_unitario'];
$nitem = $linha['nitem'];
$ditem= $linha['descricao'];
$quanto= $linha['qtde_ie'];
$un= $linha['unidade'];
$ed= $linha['coded'];
$valori = $num * $quanto;
$dite=substr("$ditem", 0, 150)."..." ;
$nume= number_format($num,2, ",",".");
$valoris=number_format($valori,2, ",",".");
?>

<table>
<colgroup>
<col width="6%">
<col width="44%">
<col width="5%">
<col width="12%">
<col width="9%">
<col width="12%">
<col width="12%">
</colgroup>
<thead>
<tr>
<th width="6%"><p class='var1'>Item</p></th>
<th width="44%"><p class='var1'>Descrição</p></th>
<th width="5%"><p class='var1'>Qt</p></th>
<th width="12%"><p class='var1'>Un</p></th>
<th width="9%"><p class='var1'>R$/un</p></th>
<th width="12%"><p class='var1'>R$/total</p></th>
<th width="12%"><p class='var1'>E.D</p></th>
</tr>
</thead>
</table>
<table>
<colgroup>
<col width="6%">
<col width="44%">
<col width="5%">
<col width="12%">
<col width="9%">
<col width="12%">
<col width="12%">
</colgroup>
<tbody>
<tr>
<td width="6%"><?php echo "<p class='var1'>$nitem</p>"?></td>
<td width="44%"><?php echo "<p class='var1'>$dite</p>"?></td>
<td width="5%"><?php echo "<p class='var1'>$quanto</p>"?></td>
<td width="12%"><?php echo "<p class='var1'>$un</p>"?></td>
<td width="9%"><?php echo "<p class='var1'>$nume</p>"?></td>
<td width="12%"><?php echo "<p class='var1'>$valoris</p>"?></td>
<td width="12%"><?php echo "<p class='var1'>$ed</p>"?></td>
</tr>
</tbody>
</table>

<?php 
		// finaliza o loop que vai mostrar os dados
		}while($linha = mysqli_fetch_assoc($dados));
	// fim do if 
	}
?>

<?php
// tira o resultado da busca da memória
//mysqli_free_result($dados);
?>
<?php
// cria a instrução SQL que vai selecionar os dados da soma total de empenho
$sqlb = mysqli_query($mysqli, "SELECT SUM(qtde_ie * valor_unitario) AS valorb, coded
FROM entrada_produto_ie INNER JOIN produto 
ON entrada_produto_ie.id_produto_ie= produto.id 
INNER JOIN cded ON produto.ed=cded.ided
WHERE 
coded LIKE '33%' AND (idprocesso ='$processo') AND fornecedora = '$fornecedor' AND (data_entrada_ie = '$data')");

 //executa a query
$rowb = mysqli_fetch_assoc($sqlb);
$sumb = $rowb['valorb'];
?>

<table>
<tr>
<td width="45%"><P class="total">Total empenho Custeio(R$):</p>
</td>
<td width="55%"><P class="total"><?php echo number_format($sumb,2, ",",".");?>
</p>
</td>
</tr>
</table>

<?php
// cria a instrução SQL que vai selecionar os dados da soma total de empenho
$sqlc = mysqli_query($mysqli, "SELECT SUM(qtde_ie * valor_unitario) AS valorc, coded
FROM entrada_produto_ie INNER JOIN produto 
ON entrada_produto_ie.id_produto_ie= produto.id 
INNER JOIN cded ON produto.ed=cded.ided
WHERE 
coded LIKE '44%' AND (idprocesso ='$processo') AND fornecedora = '$fornecedor' AND (data_entrada_ie = '$data')");

 //executa a query
$rowc = mysqli_fetch_assoc($sqlc);
$sumc = $rowc['valorc'];
?>
<table>
<tr>
<td width="45%"><P class="total">Total empenho Investimento(R$):</p>
</td>
<td width="55%"><P class="total"><?php echo number_format($sumc,2, ",",".");?>
</p>
</td>
</tr>
</table>
</div>

<?php
// seleciona dados do fornecedor
$sqlc = mysqli_query($mysqli, "SELECT * FROM cadfornecedor 
INNER JOIN cdbanco ON cadfornecedor.banco=cdbanco.idbanco WHERE idforn ='$fornecedor'");
 $count = mysqli_num_rows($sqlc);
if ($count == 0) 
{ echo "Nenhum resultado!<br />"; } 
while ($dados = mysqli_fetch_array($sqlc))
{ echo "";
$fornecedorx = $dados['nome'];
$cnpj = $dados['cnpj'];
$banco = $dados['banco'];
$agencia = $dados['agencia'];
$conta = $dados['conta'];
}
?>
<div class="textos">
<span class="subtitulo">
Fornecedor:
</span>
<span class="rsubtitulo">
<?php echo "$fornecedorx"?>
</span>
<br>
<span class="subtitulo">
CNPJ:
</span>
<span class="rsubtitulo">
<?php echo "$cnpj"?>
</span>
<br>
<span class="subtitulo">
Banco:
 </span>
<span class="rsubtitulo">
<?php echo "$banco".'- '?>
</span>
<span class="subtitulo">
Agência: 
</span>
<span class="rsubtitulo">
<?php echo "$agencia".'- '?>
</span>
<span class="subtitulo">
Conta:
</span>
<span class="rsubtitulo">
<?php echo "$conta"?>
</span>
</div>
<div class="textos">
<p class="normal">Tendo em vista a autorização pretérita para compra na modalidade <?php echo $tipo ?>, faz-se agora 
necessária a realização do empenho. Após constatar a regularidade do processo e obediência 
aos princípios da administração pública (artigo 37, Constituição Federal de 1988), 
bem como aos princípios norteadores da licitação (Lei 8.666 de 1.993), declaro autorizado 
a realização do empenho.</p>


<?php
// cria a instrução SQL que vai selecionar os dados do solicitante
$queryc = sprintf("SELECT * FROM cdrequisitante INNER JOIN cadcompras ON cdrequisitante.idr=cadcompras.nomereq WHERE idcompra ='$processo'");
// executa a query
$dadosi = mysqli_query($mysqli, $queryc) or die(mysqli_error($mysqli));
// transforma os dados em um array
$linhai = mysqli_fetch_assoc($dadosi);
// calcula quantos dados retornaram
$totali = mysqli_num_rows($dadosi);

	// se o número de resultados for maior que zero, mostra os dados//
	if($totali > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
		$nomesolic = $linhai['nome'];
	$siape = $linhai['siape'];
	
	
		// finaliza o loop que vai mostrar os dados
		}while($linhai = mysqli_fetch_assoc($dadosi));
	// fim do if 
	}
	?>

	<p class="direita"><?php echo "$local-$uf, ___/____/20___"?>
</p>

<p class="center">_____________________________<br><?php echo "$nomesolic"?><br />
 Solicitante <br />
 <?php echo "Siape: ". "$siape"?><br />
 </p>
 

<br />

<p class="total">Autorização do empenho:</p>

<p class="normal">(  ) Autorizo o empenho no valor citado. Proceder o processo a COPOR.</p>

<p class="normal">(  ) Não autorizo o empenho. Justificativa:</p>



<p class="direita"><?php echo "$local-$uf" ?>  ___/____/20___
</p>

<br />
<br />
<p class="center">
_________________________
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
________________________
<br /></p>
<p class="center">Gestor Financeiro
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
Ordenador de Despesas
</p>



</div>
<div class="button">
<input type="button" name="cancela" value="Voltar" onclick="window.location.href='../painel_alm.php'"/>
</div>
<?php
// tira o resultado da busca da memória
mysqli_free_result($dadosi);
?>
<?php
// tira o resultado da busca da memória
mysqli_free_result($dadosii);
?>

</body>
</html>