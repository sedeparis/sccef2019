﻿<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado com usuário: ';
echo	$logado;
	echo '</div>';
include "../../conecta_banco.php";
?>
<!DOCTYPE HTML>
<html lang="pt_br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<title>relatórios</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		 <link href="../../css/print_tab.css" rel="stylesheet" />
	  <link href="../../css/print_div.css" rel="stylesheet" />
	   <link href="../../css/print_fontes.css" rel="stylesheet" />
</head>
 <body>
	 <div class="cabecalho">
	  <?php include "cabecalho.php"; ?> 
	  </div>
	 <div class="titulo">
	  <h3>Compras-itens por compras</h3>
	  </div>
<?php
$processo=$_POST['processo'];
// cria a instrução SQL que vai selecionar os dados de processo
$query = ("SELECT * FROM cadcompras WHERE processo = '$processo'");
// executa a query
$dadosa = @mysql_query($query) or die(mysql_error());
// transforma os dados em um array
$linhaa = @mysql_fetch_assoc($dadosa);
// calcula quantos dados retornaram
$totala = mysql_num_rows($dadosa);
?>
<!-- mostra itens empenhados-->

<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($totala > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
$processob=$linhaa['processo'];
$finalidade=$linhaa['finalidade'];
?>

<?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = @mysql_fetch_assoc($dados));
	// fim do if 
	}
?>
<div class="textos">
<span class="subtitulo">
Processo:
</span>
<span class="rsubtitulo">
 <?php echo "$processo"?>
 </span>
<br>
<span class="subtitulo">
Finalidade:
</span>
<span class="rsubtitulo">
 <?php echo "$finalidade"?>
 </span>
<br>
</div>

<div class="tabela">
<?php
//com pdo

// cria a instrução SQL que vai selecionar os dados dos itens
$sql = $mysqli ->prepare("SELECT  nitem, ditem, idfornecedor, quant_lic, valor FROM caditem WHERE idcompra = '$processo'");
$sql->execute();
$sql->bind_result($nitem, $ditem, $idfornecedor, $quant_lic, $valor);
echo "<table>
<thead>
<tr>
<td>Item</td>
<td>Descrição</td>
<td>Fornecedor</td>
<td>Licitado</td>
<td>Valor</td>
</tr>
</thead>

<tbody>
";

while ($sql->fetch())
{
echo "<tr>
<td>$nitem</td>
<td>$ditem</td>
<td>$idfornecedor</td>
<td>$quant_lic</td>
<td>$valor</td>
</tr>";
}
echo "<tbody>
</table>
";
	
?>
</div>
<div class="button">
<input type="button" name="voltar" value="Voltar" onclick="window.location.href='../painel_alm.php'"/>
</div>
	</div>
	<?php include "footer.php"; ?> 
	</body>
	</html>