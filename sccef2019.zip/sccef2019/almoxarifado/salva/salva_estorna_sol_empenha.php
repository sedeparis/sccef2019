 <?php 
 session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include "../../conecta_banco.php";
?>
 <!DOCTYPE HTML>
 <html lang="pt-br">
 <head>
 <link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Cadastro empenho</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	 <link rel="stylesheet" href="../../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../../css/estilo.css" type="text/css"/>
	  <link rel="stylesheet" href="../../css/bootstrap.css" type="text/css"/>
   </head>
	 <body>
	 <div class="container">
	 <p class="center"><img src="../../img/salva.gif"/></p>
	 <p class="center"><img src="../../img/moldura.gif"/></p>
<?php
if ( isset($_POST["submit"]))	{
echo '<pre>';
		print_r($_POST);
		echo '</pre>';
		foreach($_POST["iditem"] AS $iditem){
			echo 'iditem is '. $iditem . '<br />';//id do item
			echo 'quant_emp_now is ' . $_POST["quant_emp_now"][$iditem]."<br />"; //quanto vou estornar
			echo 'quant_lic is ' . $_POST["quant_lic"][$iditem]."<br />"; //quanto foi licitado
			echo 'quanti_disp is ' . $_POST["quant_disp"][$iditem]."<br />"; // quanto tem ainda disponivel
			echo 'quant_util is ' . $_POST["quant_util"][$iditem]."<br />"; // quanto foi utilizado
			echo 'quant_ult_emp is ' . $_POST["quant_ult_emp"][$iditem]."<br />";// quanto foi o ultimo empenho
			echo 'valor is ' . $_POST["valor"][$iditem]."<br />";// valor do item
			
						 	 
			$quant_emp_now= mysqli_real_escape_string($mysqli, $_POST["quant_emp_now"][$iditem]);// //quanto vou estornar
			 $quant_lic= mysqli_real_escape_string($mysqli, $_POST["quant_lic"][$iditem]); //quanto foi licitado
			 $quant_disp = mysqli_real_escape_string($mysqli, $_POST["quant_disp"][$iditem]); // quanto tem ainda disponivel
			 $quant_util= mysqli_real_escape_string($mysqli, $_POST["quant_util"][$iditem]); // quanto foi utilizado
			 $quant_ult_emp = mysqli_real_escape_string($mysqli, $_POST["quant_ult_emp"][$iditem]); //quanto foi o ultimo empenho
			 $valor= mysqli_real_escape_string($mysqli, $_POST["valor"][$iditem]); // valor do item
			 
			
			$update = "UPDATE caditem SET
			quant_disp = ('$quant_disp' - '$quant_emp_now'),
	quant_util =('$quant_util' +'$quant_emp_now'), 
	quant_ult_emp = ('$quant_ult_emp'+'$quant_emp_now'), 
	valori =('$valor'*'$quant_emp_now'), 
	solicita = '$solic', dataemp = '$data' 
	WHERE
	iditem =$iditem;";
	
	mysqli_query($mysqli, $update)or die (mysqli_error($mysqli));
	echo 'Itens lançados com sucesso para gerarem a requisicao de empenho!<br />';
	
	}
	}
	?>
	<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='1;URL=../painel_alm.php'>";
?>

	</div>
	<?php include "footer.php"; ?>
	</body>
	</html>