<?php 
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include "../../conecta_banco.php";
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<title>Cadastro empenho</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="../../css/reset.css" type="text/css"/>
<link rel="stylesheet" href="../../css/estilo.css" type="text/css"/>
<link rel="stylesheet" href="../../css/bootstrap.css" type="text/css"/>
</head>
<body>
<div class="container">
<p class="center"><img src="../../img/salva.gif"/>
<img src="../../img/moldura.gif"/></p>
<?php
if ( isset($_POST["submit"]))	{
echo '<pre>';
print_r($_POST);
echo '</pre>';
foreach($_POST["id_ie"] AS $id_ie){
echo 'id_ie is '. $id_ie . '<br />';//id_ie do item
echo 'quanto is ' . $_POST["quanto"][$id_ie]."<br />"; //quanto vou pedir
echo 'valor is ' . $_POST["valor"][$id_ie]."<br />";// valor do item
echo 'data is ' . $_POST["dataemp"][$id_ie]."<br />";// data
echo 'nempenho ' . $_POST["nempenho"][$id_ie]."<br />";// data
echo 'fornecedor is ' . $_POST["fornecedor"][$id_ie]."<br />";// fornecedor

$quanto= mysqli_real_escape_string($mysqli, $_POST["quanto"][$id_ie]);// //quanto vou pedir
$valor= mysqli_real_escape_string($mysqli, $_POST["valor"][$id_ie]); // valor do item
$data = mysqli_real_escape_string($mysqli, $_POST["dataemp"][$id_ie]); // data
$fornecedor = mysqli_real_escape_string($mysqli, $_POST["fornecedor"][$id_ie]); // data
$nempenho = mysqli_real_escape_string($mysqli, $_POST["nempenho"][$id_ie]); // data
//sai podutos do estoque de entrada
$sql = ("INSERT INTO saida_produto_ie(id_produto_ie, qtde_ie, data_saida_ie, valor_unitario_ie, nempenho_ie)
VALUES('$id_ie', '$quanto', '$data', '$valor', '$nempenho')");
$resultado = mysqli_query($mysqli, $sql);
{echo 'Itens atualizados e saidos do estoque II!<br><br>';}

//entra produto estoque intencao de empenho
$sqlb = ("INSERT INTO entrada_produto_ee (id_produto_ee, qtde_ee, valor_unitario_ee, fornecedor_ee, data_entrada_ee, nempenho_ee )
VALUES ('$id_ie', '$quanto', '$valor', '$fornecedor', '$data', '$nempenho')");
$resultadob = mysqli_query($mysqli, $sqlb);
{echo 'Itens gravados com sucesso em III !';}
}
}
?>
<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='30;URL=../painel_alm.php'>";
?>
</div>
<?php include "footer.php"; ?>

</body>
</html>