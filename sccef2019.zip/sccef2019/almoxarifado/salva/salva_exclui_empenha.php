<?php 
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: '.$logado;
	echo '</div>';
include "../../conecta_banco.php";
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<title>Cadastro empenho</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="../../css/reset.css" type="text/css"/>
<link rel="stylesheet" href="../../css/estilo.css" type="text/css"/>
<link rel="stylesheet" href="../../css/bootstrap.css" type="text/css"/>
</head>
<body>
<div class="container">
<p class="center"><img src="../../img/salva.gif"/></p>
<p class="center"><img src="../../img/moldura.gif"/></p>
<?php
if ( isset($_POST["submit"]))	{
echo '<pre>';
		print_r($_POST);
		echo '</pre>';
		foreach($_POST["id_produto"] AS $id){
			
			echo '<p class="oculta">id is '. $id . '</p><br />';
			echo '<p class="oculta">data is ' . $_POST["data"][$id].'</p><br />';
			echo '<p class="oculta">radio is ' . $_POST["radio"][$id].'</p><br />';
	
						 	 
			
			  $data = mysqli_real_escape_string($mysqli, $_POST["data"][$id]);
			 $radio = mysqli_real_escape_string($mysqli, $_POST["radio"][$id]);
			 
			
			if ($radio <> 1) {
   echo 'Quantidade será mantida<br />';

} else {
	


//deleta produtos da tabela saida_produto 
$sql = ("DELETE FROM saida_produto  
WHERE id_produto= '$id' AND data_saida='$data'");
$resultado = mysqli_query($mysqli, $sql);
{echo 'Itens atualizados e saida_produtos do estoque!<br><br>';}

//entra entrada_produto_ie estoque intencao de empenho
$sqlb = ("DELETE FROM entrada_produto_ie 
WHERE id_produto_ie= '$id' AND data_entrada_ie='$data'");
$resultadob = mysqli_query($mysqli, $sqlb);
{echo 'Itens gravados com sucesso em Entrada ie!';}

}
}
}
?>
<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='30;URL=../painel_alm.php'>";
?>
</div>
<?php include "footer.php"; ?>

</body>
</html>
	 
