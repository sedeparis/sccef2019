<?php 
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: '.$logado;
	echo '</div>';
include "../../conecta_banco.php";
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<title>Cadastro empenho</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="../../css/reset.css" type="text/css"/>
<link rel="stylesheet" href="../../css/estilo.css" type="text/css"/>
<link rel="stylesheet" href="../../css/bootstrap.css" type="text/css"/>
</head>
<body>
<div class="container">
<p class="center"><img src="../../img/salva.gif"/></p>
<p class="center"><img src="../../img/moldura.gif"/></p>
<?php
if ( isset($_POST["submit"]))	{
echo '<pre>';
print_r($_POST);
echo '</pre>';
foreach($_POST["id_produto"] AS $id_produto){
echo 'id_produto is '. $id_produto . '<br />';//id_produto do item
echo 'quanto is ' . $_POST["quanto"][$id_produto]."<br />"; //quanto vou pedir
echo 'data is ' . $_POST["data"][$id_produto]."<br />";// data


$quanto= mysqli_real_escape_string($mysqli, $_POST["quanto"][$id_produto]);// //quanto vou pedir
$data = mysqli_real_escape_string($mysqli, $_POST["data"][$id_produto]); // data



// cria a instrução SQL que vai selecionar os dados para ver se não vai negativar o estoque
$sqla = mysqli_query( $mysqli, "SELECT * FROM estoque WHERE id_produto = '$id_produto'");
 $counta = mysqli_num_rows($sqla);
if ($counta == 0) 
{ echo "Nenhum resultado!" ;}
while ($dadosa = mysqli_fetch_array($sqla))
{ echo "";
 $rqtde=$dadosa['qtde'];
 }
if($quanto > $rqtde){
	echo 'Quantidade informada é maior que a disponível';
} 
if else ($quanto <= 0){
	echo 'Quantidade informada não é valida';
} 
else {


//sai podutos do estoque de entrada
$sql = ("INSERT INTO saida_produto (id_produto, qtde, data_saida)
VALUES('$id_produto', '$quanto', '$data')");
$resultado = mysqli_query($mysqli, $sql);
{echo 'Itens atualizados e saida_produtos do estoque!<br><br>';}

//entra produto estoque intencao de empenho
$sqlb = ("INSERT INTO entrada_produto_ie (id_produto_ie, qtde_ie, data_entrada_ie )
VALUES ('$id_produto', '$quanto', '$data')");
$resultadob = mysqli_query($mysqli, $sqlb);
{echo 'Itens gravados com sucesso em ie!';}

}
}
}
?>
<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='3;URL=../painel_alm.php'>";
?>
</div>
<?php include "footer.php"; ?>

</body>
</html>