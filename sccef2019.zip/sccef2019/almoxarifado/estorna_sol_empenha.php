<<?php
session_start();
$_SESSION['email'];
$_SESSION['senha'];
//header ('autenticara.php');
$logado=$_SESSION['email'];
include ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<title>Altera requisitante de empenho</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<link rel="stylesheet" href="../css/reset.css" type="text/css"/>
<link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
<link rel="stylesheet" href="../css/estiloform.css" type="text/css"/>
<script type="text/javascript">
function moeda(z){
v = z.value;
v=v.replace(/\D/g,"") // permite digitar apenas numero
v=v.replace(/(\d{1})(\d{14})$/,"$1.$2") // coloca ponto antes dos ultimos digitos
v=v.replace(/(\d{1})(\d{11})$/,"$1.$2") // coloca ponto antes dos ultimos 11 digitos
v=v.replace(/(\d{1})(\d{8})$/,"$1.$2") // coloca ponto antes dos ultimos 8 digitos
v=v.replace(/(\d{1})(\d{5})$/,"$1.$2") // coloca ponto antes dos ultimos 5 digitos
v=v.replace(/(\d{1})(\d{1,2})$/,"$1,$2") // coloca virgula antes dos ultimos 2 digitos
z.value = v;
}
function validacao() {
if(document.form.altera.value=="Selecione...")
{
alert("Por favor selecione o item.");
document.form.altera.focus();
return false;
}
if(document.form.solicita.value=="Selecione...")
{
alert("Por favor selecione o requisitante.");
document.form.solicita.focus();
return false;
}
}
</script>
</head>
<body>
<div class="container">
<?php include "topo.php"; echo 'Usuário Logado: '; echo $logado; ?> 
</div>
<div class="container">
<h2 class="form-nome">Estornar/alterar quantidade solicitada de empenho </h2>
<form  name="form" method="POST" action="executa/exec_estorna_sol_empenho.php" onSubmit="return validacao();">
<fieldset class="grupo">
<div class="form-group">
<?php
$query = mysqli_query($mysqli, "SELECT * FROM cadcompras ORDER BY idcompra DESC");
?>
<label class="form-control" for="">Selecione a compra</label>
<select class="form-control" name="altera">
<option class="form-control" name="">Selecione...</option>
<?php 
while($busca = mysqli_fetch_array($query)) { 
?>
<option class="form-control" value="<?php 
echo $busca['processo'] 
?>">
<?php 
echo $busca['processo']. ' - '. $busca['finalidade'];
?></option>
<?php } ?>
</select>
</div>
</fieldset>
<div class="form-group">
<input class="form-control-2"  type="submit" id="submit" value="Alterar" name="Localizar"/>
<input class="form-control-2"  type="reset" id="reset" value="Limpar dados" name="limpar"/>
<input class="form-control-2"  type="button" name="cancela" value="Cancelar" onclick="window.location.href='painel_alm.php'"/>
</div>
</form>
</div>

<?php include "footer.php" ?> 

</body>
</html>