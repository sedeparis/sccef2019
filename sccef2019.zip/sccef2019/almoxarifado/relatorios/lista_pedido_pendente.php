<?php
include "../../conecta_banco.php";
include "../../conecta_banco_pdi.php"
?>
<!DOCTYPE HTML>
<html lang="pt_br">
<head>
<title>relatórios</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		 <link href="../../css/print_tab.css" rel="stylesheet" />
	  <link href="../../css/print_div.css" rel="stylesheet" />
	   <link href="../../css/print_fontes.css" rel="stylesheet" />
</head>
<body>
 
	 <div class="cabecalho">
	  <?php include "cabecalho.php"; ?> 
	  </div>
	 <div class="titulo">
	  <h3>Pedidos pendentes de entrega</h3>
	  </div>
<div class="tabela">
<?php
//com pdo

// cria a instrução SQL que vai selecionar os dados dos itens
$sql = $mysqli ->prepare("SELECT idcompra, nitem, ditem, idfornecedor, pedido, recebido FROM caditem WHERE recebido<>pedido");
$sql->execute();
$sql->bind_result($idcompra, $nitem, $ditem, $idfornecedor, $pedido, $recebido);
echo "<table>
<thead>
<tr>
<td>Processo</td>
<td>Item</td>
<td>Descrição</td>
<td>Fornecedor</td>
<td>Pedido</td>
<td>Recebido</td>
</tr>
</thead>

<tbody>
";

while ($sql->fetch())
{
	echo " <tr>
<td>$idcompra</td>
<td>$nitem</td>
<td>$ditem</td>
<td>$idfornecedor</td>
<td>$pedido</td>
<td>$recebido</td>
</tr>";
}
echo "<tbody>
</table>
";
	
?>
</div>
<div class="button">
 <input type="button" name="ok" value="Voltar" onclick="window.location.href='../painel_alm.php'"/>
</div>
</body>
</html>

