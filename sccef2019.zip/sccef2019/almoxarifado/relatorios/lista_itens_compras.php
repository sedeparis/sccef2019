<?php
include "../../conecta_banco.php";?>
<!DOCTYPE HTML>
<html lang="pt_br">
<head>
<title>relatórios</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 <link rel="stylesheet" href="../../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../../css/bootstrap.css" type="text/css"/>
	 <link rel="stylesheet" href="../../css/estiloform.css" type="text/css"/>
	 <script type="text/javascript">
	 function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 } 

 function validacao() {
 if(document.form.processo.value=="Selecione...")
{
alert("Por favor selecione o processo.");
document.form.processo.focus();
return false;
}
}
	 </script>
 </head>
 <body>
	 <div class="container">
	  <?php include "topo.php"; ?> 
	  </div>
	 <div class="container">
	  <h2>Listar Itens por processo</h2>
	  </div>
	 	 <div class="container">
	<form name="form" action="../executa/exec_itens_compras.php" method="post" onSubmit="return validacao();">
<fieldset class="grupo">
		<div class="form-group">
		
		 <?php 
	$query = mysql_query("SELECT * FROM cadcompras WHERE situacao='Ativo' ORDER BY idcompra DESC");
?>
 <label class="form-control" for="">Selecione o processo</label>
 <select class="form-control" name="processo">
 <option class="form-control" name="">Selecione...</option>
 <?php 
 while($busca = mysql_fetch_array($query)) { 
 ?>
 <option class="form-control" value="<?php 
 echo $busca['processo'] 
 ?>">
 <?php 
 echo $busca['processo'].' - '.$busca['finalidade']
 ?></option>
 <?php } ?>
 </select>
		 
</div>
	</fieldset>
	<div class="form-group">
<input type="submit" name="Seleciona" Value="Selecionar">
<input type="reset" name="Seleciona" Value="Limpar">
<input type="button" name="cancela" value="Cancelar" onclick="window.location.href='../painel_alm.php'"/>
</div>
</form>
</div>
<?php include "footer.php"; ?> 
</body>
</html>