 <!DOCTYPE HTML>
 <html lang="pt-br">
<head>
<title>Gerenciamento Administrativo
</title>
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	 <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/estiloform.css" type="text/css"/>
<link rel="icon" type="image/jpg" href="../img/icone_barra.jpg" />
<script type="text/javascript">
function validacao() { 

if(document.form.email.value=="")
{
alert("Por favor informe o nome ou email.");
document.form.email.focus();
return false;
}
if(document.form.senha.value=="")
{
alert("Por favor informe a senha.");
document.form.senha.focus();
return false;
}
}
</script>
</head>
<body> 
<div class="container">
<?php include "topo.php"; ?>
</div>
<div class="container">
<form name="form" method="Post" action="autenticara.php" onSubmit="return validacao();">
<fieldset class="grupo">
<div class="form-group">
<label class="form-control">Email ou nome de usuário:</label>
<input class="form-control" type="text" name="email" size="30" />
</div>
</fieldset>
<fieldset class="grupo">
<div class="form-group">
<label class="form-control">Senha:</label> 
<input class="form-control" type="password" name="senha" size="8"/> 
</div>
</fieldset>
<div class="form-group">
<input  type="submit" name="entrar" value="Acessar"/>
 <input type="button" name="cancela" value="Cancelar" onclick="window.location.href='../index.php'"/>
Sem Cadastro? <a href="../user/cd_usuario.php">Clique aqui<a/>
</div>
</form>
</div>

 <?php include "footer.php"; ?> 

 </body>
</html>