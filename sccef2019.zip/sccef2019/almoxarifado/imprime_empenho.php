<<?php
session_start();
$_SESSION['email'];
$_SESSION['senha'];
//header ('autenticara.php');
$logado=$_SESSION['email'];
include ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Imprimir empenho</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/custom.css" type="text/css"/>
	  <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	 <script type="text/javascript">
	  function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
 
  function validacao() {
 if(document.form.processo.value=="Selecione...")
{
alert("Por favor selecione o processo.");
document.form.processo.focus();
return false;
}

if(document.form.fornecedor.value=="Selecione...")
{
alert("Por favor selecione o fornecedor.");
document.form.fornecedor.focus();
return false;
}
}
	 </script>
 </head>
	  <body> 
	<div class="container">
<?php include "topo.php"; echo 'Usuário Logado: '; echo $logado; ?>
</div>
	 <div class="container">
<h2 class="form-nome">Imprimir Autorização de empenho</h2>
	<form name="form" method="post" action="executa/exec_imprime_empenho.php" onSubmit="return validacao();"> 
	<fieldset class="grupo">
		 <div class="form-group">
	<?php 
	$query = mysqli_query($mysqli, "SELECT * FROM cadcompras WHERE situacao = '1' AND (finalcompra=0) ORDER BY idcompra DESC");
?>
 <label class="form-control" for="">Selecione um processo</label>
 <select class="form-control" name="processo">
 <option class="form-control" name="">Selecione...</option>
 <?php while($prod = mysqli_fetch_array($query)) { ?>
 <option class="form-control" value="<?php echo $prod['idcompra'] ?>"><?php echo $prod['processo']. ' - '. $prod['finalidade'] ?></option>
 <?php } ?>
 </select>
  </div>
		<div class="form-group">
<?php 
$queryb = mysqli_query($mysqli, "SELECT Distinct fornecedora, nome, idforn FROM produto 
INNER JOIN cadfornecedor ON produto.fornecedora=cadfornecedor.idforn WHERE fornecedora <>'' ORDER BY nome asc");
?>
<label class="form-control" for="">Selecione um fornecedor</label>
<select class="form-control" name="fornecedor">
<option class="form-control" name="">Selecione...</option>
<?php while($var = mysqli_fetch_array($queryb)) { ?>
<option class="form-control" value="<?php echo $var['idforn'] ?>"><?php echo $var['nome'] ?></option>
<?php } ?>
</select>
</div>
 <div class="form-group">
			 	<?php 
	$queryb = mysqli_query($mysqli, "SELECT distinct data_entrada_ie FROM entrada_produto_ie ORDER BY ID_ie DESC");
?>
 <label class="form-control" for="">Selecione data pedido empenho</label>
 <select class="form-control" name="data">
 <option class="form-control" name="">Selecione...</option>
 <?php while($prodb = mysqli_fetch_array($queryb)) { ?>
 <option class="form-control" value="<?php echo $prodb['data_entrada_ie'] ?>"><?php echo $prodb['data_entrada_ie'] ?></option>
 <?php } ?>
 </select>
 </div>
	</fieldset>
		 <div class="form-group">
	<input type="submit" value="Gerar Solicitaçao de Empenho"/>
	 <input type="reset" value="Limpar"/>
	  <input type="button" name="cancela" value="Cancelar" onclick="window.location.href='painel_alm.php'"/>
	  </div>
</form>
</div>

 <?php include "footer.php"; ?> 

  </body>
 </html>