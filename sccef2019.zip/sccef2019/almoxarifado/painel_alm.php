﻿<?php
session_start();
$_SESSION['email'];
$_SESSION['senha'];
//header ('autenticara.php');
$logado=$_SESSION['email'];
include ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema Administrativo compras públicas.</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <!--link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' /-->

   </head>
<body>       
<script type="text/javascript" src="../js/wz_tooltip.js"></script>  
    <div id="wrapper">
         <div class="navbar navbar-inverse navbar-fixed-top">
            <div class="adjust-nav">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">
                        <img src="../img/logoif.jpg" />
                    </a>
                </div>
                <span class="logout-spn" >
                  <a href="../logout.php" style="color:#fff;">LOGOUT</a>  
                </span>
            </div>
        </div>
        <!-- /. NAV TOP  -->
      <nav class="navbar-default navbar-side" role="navigation">
<div class="sidebar-collapse">
<ul class="nav" id="main-menu">
<li class="active-link">
<a href="../admin/index.php"><i class="fa fa-desktop "></i>Admin<span class="badge"></span></a>
</li>
<li>
<a href="../requisitante/painelr.php"><i class="fa fa-user"></i>Requisitante</a>
</li>
<li>
<a href="../compras/painel.php"><i class="fa fa-shopping-cart"></i>
Compras</a>
</li>
<li>
<a href="painel_alm.php"><i class="fa fa-print"></i>Almoxarifado</a>
</li>
<li>
<a href="../controles/painelctrl.php"><i class="fa fa-print"></i>Controles</a>
</li>
<li>
<a href="../sobre.php"><i class="fa fa-edit"></i>Ajuda/sobre<span class="badge"></span></a>
</li>
</ul>
</div>
</nav>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-lg-12">
                     <h2 class="form-nome">PAINEL ALMOXARIFADO</h2>   
                    </div>
                </div>              
                 <!-- /. ROW  -->
                  <hr />
                <div class="row">
                    <div class="col-lg-12 ">
                        <div class="alert alert-info">
                             <strong>Bem vindo <?php echo "$logado! Você está logado!";?> </strong>
                        </div>
                       
                    </div>
                    </div>
                  <!-- /. ROW  --> 
                            <div class="row text-center pad-top">
							<h3>Pré-Empenho</h3>
							<p>* Rotinas obrigatórias para funcionamento do sistema</p>
                                  <!-- 01 --> 
                  <!--div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="requerimento_empenho.php" onmouseover="Tip('Gerar formulario para que o requisitante formalize pedido de empenho')" onmouseout="UnTip()" >
 <i class="fa fa-search-minus fa-3x"></i>
                      <h5>Consulta<br>requisitante</h5>
                      </a>
                      </div>
                     </div>	
<!-- 01--> 					 
				   <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="cd_empenha.php" onmouseover="Tip('Informa quantidade de itens de empenho')" onmouseout="UnTip()" > 
 <i class="fa fa-pencil fa-3x"></i>
                      <h5>*Quant<br>Empenhar</h5>
                      </a>
                      </div>

                  </div>
				  <!-- 02 --> 
                  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="estorna_cd_empenha.php" onmouseover="Tip('Alterar quantidade a empenhar ')" onmouseout="UnTip()" > 
 <i class="fa fa-edit fa-3x"></i>
                      <h5>Alterar<br>Qtd Empenho</h5>
                      </a>
                      </div>

                  </div>
				  <!-- 03 --> 
                  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="exclui_cd_empenha.php" onmouseover="Tip('Exclui quantidade a empenhar ')" onmouseout="UnTip()" > 
 <i class="fa fa-eraser fa-3x"></i>
                      <h5>Exclui<br>Qtd Empenho</h5>
                      </a>
                      </div>

                  </div>
				  <!-- 04 --> 
                  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="imprime_empenho.php" onmouseover="Tip('Impimir espelho de empenho')" onmouseout="UnTip()" > 
 <i class="fa fa-print fa-3x"></i>
                      <h5>Espelho<br>Empenho</h5>
                      </a>
                      </div>

                  </div>
                
				<!-- 05 --> 
				 <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                       <div class="div-square">
                           <a href="altera_requisitante.php" onmouseover="Tip('Alterar requisitante do empenho')" onmouseout="UnTip()" > 
 <i class="fa fa-edit  fa-3x"></i>
                      <h5>Altera <br>requisitante</h5>
                      </a>
                      </div>
                     
                     </div>
					 <!-- 06 --> 
					  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="data_sol_empenho.php" onmouseover="Tip('Lista datas solicitaçao de empenho')" onmouseout="UnTip()" > 
 <i class="fa fa-pencil fa-3x"></i>
                      <h5>Consulta data sol empenhos</h5>
                      </a>
                      </div>

                  </div>
              </div>
			  
			  <div class="row text-center pad-top">
    <!-- /01 --> 
   <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
   <div class="div-square">
 <a href='../gerencial/solicitado_nada_empenho.php'>
 <i class="fa fa-list fa-1x"></i> 
Itens sem<br>solicitar<br> empenho
</a>
</div>  
</div> 
 <!-- /02 --> 
   <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
   <div class="div-square">
   <a href='../gerencial/solicitado_parcialmente_empenho.php'>
 <i class="fa fa-list fa-1x"></i> 
 Itens parcialmente <br>solicitado empenho

 </a>
 </div>  
 </div> 
  <!-- /03 --> 
   <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
   <div class="div-square">
 <a href='../gerencial/solicitado_totalmente_empenho.php'>
<i class="fa fa-list fa-1x"></i> 
Itens totalmente<br>solicitado empenho
 </a>
                 </div>    
               </div>   
			   <!-- /04 --> 
   <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
   <div class="div-square">
 <a href='rsem_sol_empenho_processo.php'>
<i class="fa fa-list fa-1x"></i> 
Sem<br>solicitar empenho processo
 </a>
                 </div>    
                  </div>
				   <!-- /05 --> 
   <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
   <div class="div-square">
 <a href='rparc_sol_empenho_processo.php'>
<i class="fa fa-list fa-1x"></i> 
Parc<br>solicitado empenho processo
 </a>
                 </div>    
                  </div>
				 <!-- /06 --> 
   <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
   <div class="div-square">
 <a href='rtotal_sol_empenho_processo.php'>
<i class="fa fa-list fa-1x"></i> 
Total<br>solicitado empenho processo
 </a>
                 </div>    
                  </div>
				  </div>
			  
                 <!-- /. ROW  --> 
				 <!---rotinas de pós empenho--->
                <div class="row text-center pad-top">
                 <h3>Pós-Empenho</h3>
                  
				   <!-- 04 --> 
                 
                  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="informa_nempenho.php" onmouseover="Tip('Informa numero empenho das compras')" onmouseout="UnTip()" > 
 <i class="fa fa-thumbs-o-up fa-3x"></i>
                      <h5>*Inf Nº<br> empenhado</h5>
					                       </a>
                      </div>
                     
                     
                  </div>
				  <!-- 01 --> 
                  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="solicita_pedido.php" onmouseover="Tip('Informa quantidade de itens a solicitar fornecimento')" onmouseout="UnTip()" >
 <i class="fa fa-fax fa-3x"></i>
                      <h5>Quanto<br>pedir</h5>
                      </a>
                      </div>
                  </div>
				  <!-- 02 --> 
                  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="imprimir_pedido.php" onmouseover="Tip('Imprimir pedido a enviar ao fornecedor')" onmouseout="UnTip()" > 
 <i class="fa fa-print fa-3x"></i>
                      <h5>Pedido<br>Fornecedor</h5>
					 </a>
                      </div>                     
                  </div>
				  <!-- 03 --> 
                  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="recebe_item.php" onmouseover="Tip('Informa recebimento dos itens do fornecedor')" onmouseout="UnTip()" > 
 <i class="fa fa-barcode fa-3x"></i>
                      <h5>Receber<br>itens</h5>
					
                      </a>
                      </div>
                  </div>
				  <!-- 04 --> 
                     <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="pedido_pagamento.php" onmouseover="Tip('Solicitar pagamento ao fornecedor')" onmouseout="UnTip()" > 
 <i class="fa fa-money fa-3x"></i>
                      <h5>Solicitar<br>pagam</h5>
                      </a>
                      </div>
                    
    </div>
	<!-- 05 --> 
                        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="encerrar_compra.php" onmouseover="Tip('Encerra a compra de fornecedor especifico')" onmouseout="UnTip()" > 
 <i class="fa fa-check fa-3x"></i>
                      <h5>Fim compra<br>fornecedor</h5>
					                </a>
                      </div>
                     
                     
                  </div>
				  <!-- 06 --> 
                  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="encerrar_compra_total.php" onmouseover="Tip('Encerra compra de um processo inteiro')" onmouseout="UnTip()" > 
 <i class="fa fa-remove fa-3x"></i>
                      <h5>Fim compra<br>total</h5>
					  
                      </a>
                      </div>
                      </div>
                  </div> 
				   <!-- ----------------------------------  
				  ------------------------------------------ 
					---------------------------------------  
					
					
                 <!-- /. ROW  --> 
                <div class="row text-center pad-top">
                 <h3>Fornecimento</h3>
                  <!-- 01 --> 
                  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="solicita_pedido.php" onmouseover="Tip('Informa quantidade de itens a solicitar fornecimento')" onmouseout="UnTip()" >
 <i class="fa fa-fax fa-3x"></i>
                      <h5>Quanto<br>pedir</h5>
                      </a>
                      </div>
                  </div>
				  <!-- 02 --> 
                  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="imprimir_pedido.php" onmouseover="Tip('Imprimir pedido a enviar ao fornecedor')" onmouseout="UnTip()" > 
 <i class="fa fa-print fa-3x"></i>
                      <h5>Pedido<br>Fornecedor</h5>
					 </a>
                      </div>                     
                  </div>
				  <!-- 03 --> 
                  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="recebe_item.php" onmouseover="Tip('Informa recebimento dos itens do fornecedor')" onmouseout="UnTip()" > 
 <i class="fa fa-barcode fa-3x"></i>
                      <h5>Receber<br>itens</h5>
					
                      </a>
                      </div>
                  </div>
				  <!-- 04 --> 
                     <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="pedido_pagamento.php" onmouseover="Tip('Solicitar pagamento ao fornecedor')" onmouseout="UnTip()" > 
 <i class="fa fa-money fa-3x"></i>
                      <h5>Solicitar<br>pagam</h5>
                      </a>
                      </div>
                    
    </div>
	<!-- 05 --> 
                        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="encerrar_compra.php" onmouseover="Tip('Encerra a compra de fornecedor especifico')" onmouseout="UnTip()" > 
 <i class="fa fa-check fa-3x"></i>
                      <h5>Fim compra<br>fornecedor</h5>
					                </a>
                      </div>
                     
                     
                  </div>
				  <!-- 06 --> 
                  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="encerrar_compra_total.php" onmouseover="Tip('Encerra compra de um processo inteiro')" onmouseout="UnTip()" > 
 <i class="fa fa-remove fa-3x"></i>
                      <h5>Fim compra<br>total</h5>
					  
                      </a>
                      </div>
                      </div>
                  </div> 
				   <!-- ----------------------------------  
				  --
					
				                   ROW relatórios -->   
								   
								   
								   
				<div class="row text-center pad-top">
                 <h3>Relatorios</h3>
				 
				 <!-- new arranjo -->
				 
				 			 
				 <div class="row text-center pad-top">
    <!-- /01 --> 
   
				   <!-- /04 --> 
				  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
   <div class="div-square">
 <a href='../gerencial/lista_valor_fornecedor.php'>
 <i class="fa fa-list fa-1x"></i> 
 Compras empenhado <br>por fornecedor
 </a>
                 </div>    
               
                  </div>
				  
				   <!-- /05 --> 
				  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
   <div class="div-square">
 <a href='empenhados_processo.php'>
 <i class="fa fa-list fa-1x"></i> 
 Compras <br>por processo
 </a>
                 </div>    
               
                  </div>
				  
				   <!-- /06 --> 
				    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
   <div class="div-square">
 <a href='../gerencial/lista_cancelados.php'>
 <i class="fa fa-list fa-1x"></i> 
Itens Cancelados <BR> ou desertos
 </a>
                </div>    
                  </div>
				     
                  </div>
				      <!-- /.fins de listas -->
                  </div> 
				 <!--  -->
				 
				 
				 <div class="row text-center pad-top">
    <!-- /01 --> 
   <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
   <div class="div-square">
 <a href='../gerencial/lista_empenho_parcial.php'>
 <i class="fa fa-list fa-1x"></i> 
 Compras empenhadas <br>parcialmente
</a>
</div>  
</div> 
 <!-- /02 --> 
   <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
   <div class="div-square">
<a href='../gerencial/lista_sem_empenho.php'>
<i class="fa fa-list fa-1x"></i> 
Compras Sem empenho<br>
 </a>
 </div>  
 </div> 
  <!-- /03 --> 
   <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
   <div class="div-square">
 <a href='../gerencial/lista_compras_periodo.php'>
 <i class="fa fa-list fa-1x"></i> 
 Compras empenhado <br>por período
 </a>
                 </div>    
               
                  </div>
				   <!-- /04 --> 
				  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
   <div class="div-square">
 <a href='../gerencial/lista_valor_fornecedor.php'>
 <i class="fa fa-list fa-1x"></i> 
 Compras empenhado <br>por fornecedor
 </a>
                 </div>    
               
                  </div>
				   <!-- /05 --> 
				    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
   <div class="div-square">
 <a href='../gerencial/lista_cancelados.php'>
 <i class="fa fa-list fa-1x"></i> 
Itens Cancelados <BR> ou desertos
 </a>
                </div>    
                  </div>
				    <!-- /06 -->
				   <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
   <div class="div-square">
 <a href='../gerencial/lista_empenhados_nao_pedidos.php'>
 <i class="fa fa-list fa-1x"></i> 
Empenhados sem Solicitar<br> ao Fornecedor
 </a>
                </div>    
                  </div>
				      <!-- /.fins de listas -->
                  </div> 
                  <!-- /01 -->   
                  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
      <a href='../gerencial/lista_pedido_final.php' onmouseover="Tip('Compras já entregues')" onmouseout="UnTip()" > 
	  <i class="fa fa-list fa-1x"></i> Pedidos Concluidos<br></a>
  </div> 
  </div> 
  
    <!-- /02 --> 
   <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
   <div class="div-square">
 <a href='../gerencial/lista_pedido_pendente.php'>
 <i class="fa fa-list fa-1x"></i>Pedidos com pendencias<br>
 </a>
 </div>  
 </div> 
   <!-- /03 --> 
   <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
   <div class="div-square">
 <a href='../gerencial/lista_pedido_areceber.php'>
 <i class="fa fa-list fa-1x"></i> 
 Pedidos não recebidos<br>
 </a>
 </div> 
</div> 
  <!-- /04 --> 
   <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6"> 
   <div class="div-square">
 <a href='../gerencial/lista_itens_compras.php'>
 <i class="fa fa-list fa-1x"></i> 
 Itens por processo<br>
 </a>
 </div>  
 </div> 
   <!-- /05 --> 
   <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
   <div class="div-square">
 <a href='../gerencial/lista_val_compras.php'>
 <i class="fa fa-list fa-1x"></i> 
Compras com data<br> validade
 </a>
 </div>  
 </div> 
   <!-- /06 --> 
   <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
   <div class="div-square">
 <a href='../gerencial/lista_empenho_final.php'>
 <i class="fa fa-list fa-1x"></i> 
 Compras empenhadas <br>totalmente
 </a>
 </div>  
 </div> 
 </div> 
				                    <!-- /. ROW relatórios -->   

				  
                  <!-- /. ROW fim do ciclo de cadastro gerais -->   

                     </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
    <div class="footer">
            <div class="row">
                <div class="col-lg-12" >
                    <?PHP include '../versao.php' ?>  
                </div>
            </div>
        </div>
          

     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="js/jquery.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="js/bootstrap.min.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="js/custom.js"></script>
    
 
</fieldset>
</div>

 </body>
</html>
