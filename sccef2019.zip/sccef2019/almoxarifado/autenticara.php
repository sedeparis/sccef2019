<?php
include ("../conecta_banco.php");
$email= $_POST['email'];
$senha= md5($_POST['senha']);
$sql = mysqli_query($mysqli, "SELECT * FROM users WHERE email = '$email' 
AND senha= '$senha' 
AND situacao = 1 AND almoxarife = 2 ") ;
$row = mysqli_num_rows($sql);
if($row > 0){
	session_start();
	$_SESSION ['email']=$_POST['email'];
	$_SESSION ['senha']=md5($_POST['senha']);
	$_SESSION ['situacao']=['1'];
	echo 'Autenticando!';
	echo "<meta HTTP-EQUIV='refresh' CONTENT='1;URL=painel_alm.php'>";
} else {
	echo "<meta HTTP-EQUIV='refresh' CONTENT='1;URL=../index.php'>";
}
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<title>Acesso de usuario
</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<link rel="stylesheet" type="text/css" href="../css/reset.css" media="screen"/>
 <link rel="stylesheet" type="text/css"  href="../css/bootstrap.css" />

<link rel="icon" type="image/jpg" href="../img/icone_barra.jpg" />
</head>
<!-------- inicia pagina-------------->
<body> <?php include "topo.php"; ?>

<div class="container">
<br />
<br />
<br />
<br />
<p class="center"><img src="../img/baile.gif"/></p>
</div>
 <?php include "footer.php"; ?> 
 </body>
</html>