<?php
session_start();
	$_SESSION['email'];
	$_SESSION['senha'];
	header ("painel.php");
	$logado=$_SESSION['email'];
	echo $logado;
include ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
     
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />	
 <title>Compras processo</title>
     <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	 <link rel="stylesheet" href="css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="css/bootstrap.css" type="text/css"/>
	 <link rel="stylesheet" href="css/estiloform.css" type="text/css"/>
<script type="text/Javascript">
function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
</script>
   </head>  
   <body> 
   <div class="container">
   <?php include "topo.php"; echo 'Usuario Logado: '; echo $logado; ?>
   </div>
	 
    
	 <div class="container">
	<h2 class="form-nome">Itens parcialmente sem solicitar empenho por processo</h2>
      <br />
  
      <form name="form_filtroe" action="rlista_parc_sol_empenho_processo.php" method="post">
    
	  <fieldset class="grupo">
		  <div class="form-group">
       <?php	$query = mysqli_query($mysqli, "SELECT * FROM cadcompras WHERE situacao = '1' ORDER BY idcompra DESC");
?>
     <select class="form-control" name="processo">
 <option class="form-control" name="">Selecione</option>
 <?php while($tipo = mysqli_fetch_array($query)) { 
 ?>
 <option class="form-control"   value="<?php echo $tipo['idcompra'] ?>">
 <?php echo $tipo['processo']. ' - '.$tipo['finalidade']?></option>
 <?php } ?>
 </select>
 </div>
	</fieldset>
		  <div class="form-group">
      <input class="form-control-2"  type="submit" name="buscae" value="Filtrar Processo"/>
	  <input class="form-control-2"  type="reset" name="buscar" value="Limpar"/>
	  <input class="form-control-2"  type="button" name="cancela" value="Cancelar" onclick="window.location.href='painel_alm.php'"/>
	  </div>
      </form>
      <br />
      </div> 
   <?php include "footer.php" ?>
  </body>
</html>