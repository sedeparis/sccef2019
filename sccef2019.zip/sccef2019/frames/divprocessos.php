<html>
<head>
<title>Cadastro pedidos</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	  <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/estilo.css" type="text/css"/>
	 </head>
<body>
<div id="frame">
<p>Últimos lançamentos</p>
<br />
<span class="obrig">Processo&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;--&nbsp; Finalidade</span>
<?php
include ("../conecta_banco.php");
// seleciona dados do fornecedor
$sql = mysql_query("SELECT * FROM cadpedidos ORDER BY idped DESC");
 $count = mysql_num_rows($sql);
if ($count == 0) 
{ echo "tabela zerada<br />"; } 
while ($dados = mysql_fetch_array($sql))
{ echo "<br />$dados[nrequis]&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;--&nbsp; $dados[processo]&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;--&nbsp; $dados[fornecedor]&nbsp;&nbsp;&nbsp;--&nbsp;$dados[nitem]";}
?>
</div>
</body>
</html>