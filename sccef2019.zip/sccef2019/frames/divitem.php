<html>
<head>
<title>Cadastro processos</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	  <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/print_tab.css" type="text/css"/>
	 </head>
<body>
<div class="container">
<p>Últimos lançamentos</p>
<div class="tabela">
<table border="2px" width="80%">
<colgroup>
<col width="36%">
<col width="10%">
<col width="54%">
</colgroup>
<thead>
<tr>
<th>Processo</th>
<th>Item</th>
<th>Descrição</th>
</tr>
</thead>

</table>
<?php
include ("../conecta_banco.php");
// seleciona dados do fornecedor
$sql = mysqli_query($mysqli, "SELECT * FROM produto INNER JOIN cadcompras ON produto.idprocesso=cadcompras.idcompra ORDER BY id DESC LIMIT 10");
 $count = mysqli_num_rows($sql);
if ($count == 0) 
{ echo "tabela zerada<br />"; } 
while ($dados = mysqli_fetch_array($sql))
{ 
$processo=$dados['processo'];
$nitem=$dados['nitem'];
$descricao=$dados['descricao'];

?>

<table border="2px">
<colgroup>
<col width="36%">
<col width="10%">
<col width="54%">
</colgroup>
<tbody>
<tr>
<td><?php echo $processo ?></td>
<td><?php echo $nitem ?></td>
<td><?php echo $descricao  ?></td>
</tr>
</tbody>
</table>
<?php } ?>
</div>
</div>
</body>
</html>