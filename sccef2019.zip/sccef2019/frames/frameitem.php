<html>
<head>
<title>Requisitantes</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	  <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/estilo.css" type="text/css"/>
	 </head>
<body>
<div id="frame">
<p>Requisitantes cadastrados</p>
<br />
<span class="obrig">Item -- Descrição</span>
<?php
include ("../conecta_banco.php");
// seleciona dados do fornecedor
$sql = mysqli_query($mysqli, "SELECT * FROM caditem ORDER BY iditem DESC LIMIT 10");
 $count = mysqli_num_rows($sql);
if ($count == 0) 
{ echo "tabela zerada<br />"; } 
while ($dados = mysqli_fetch_array($sql))
{ echo "<br />$dados[nitem]&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;--&nbsp; $dados[ditem]";}
?>
</div>
</body>
</html>