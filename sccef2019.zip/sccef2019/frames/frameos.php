<html>
<head>
<title>Cadastro processos</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	  <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/estilo.css" type="text/css"/>
	 </head>
<body>
<div id="frame">
<p>Últimos lançamentos</p>
<br />
<span class="obrig">IdOS -- Descrição --Executante</span>
<?php
include ("../conecta_banco.php");
// seleciona dados do fornecedor
$sql = mysql_query("SELECT * FROM cdos ORDER BY idos DESC LIMIT 10");
 $count = mysql_num_rows($sql);
if ($count == 0) 
{ echo "tabela zerada<br />"; } 
while ($dados = mysql_fetch_array($sql))
{ echo "<br />$dados[idos]&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;--&nbsp; $dados[finalidade]--&nbsp; $dados[fornecedor]";}
?>
</div>
</body>
</html>