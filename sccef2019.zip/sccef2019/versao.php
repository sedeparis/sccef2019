<?php 
include 'conecta_banco.php';
$sql = mysqli_query($mysqli, "SELECT versao, css FROM versao");
while($proc = mysqli_fetch_array($sql)) {
echo '<p align="center">'. 'SCCEF Versão '. $proc['versao']. ' - '.$proc['css'].'</p>'; }

?>
<?php 
echo '<p align="center">'.'Banco de Dados: '. $banco.'</p>'; ?>