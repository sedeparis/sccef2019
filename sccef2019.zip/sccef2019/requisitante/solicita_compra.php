<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../img/icone_barra.jpg" />
	 <title>solicitação de compras</title>
	 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	 
  
   <script type="text/javascript">
	   function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
 
 function validacao() {
 if(document.form.processo.value=="Selecione...")
{
alert("Por favor selecione o processo.");
document.form.processo.focus();
return false;
}

}
 </script>
   </head>
	 <body> 
	 <div class="container"><?php include "topo.php"; echo 'Usuário Logado: '; echo $logado; ?> 
 </div>

	 <div class="container">
	<h2 class="form-nome">Solicitação de compras</h2>
	 <br />
	<form name="form" method="post" action="executa/exec_imprime_solcompras.php" onSubmit="return validacao();"> 
		<fieldset class="grupo">
		  <div class="form-group">
		<?php 
	$query = mysqli_query($mysqli, "SELECT * FROM cadcompras WHERE situacao = '1' AND (fase='1') ORDER BY idcompra DESC");
?>
 <label class="form-control" class="form-control" for="">Selecione uma compra</label>
 <select class="form-control" name="processo">
 <option class="form-control" name="">Selecione...</option>
 <?php while($proc = mysqli_fetch_array($query)) { ?>
 <option class="form-control" value="<?php echo $proc['idcompra'] ?>"><?php echo $proc['processo'].' - '.$proc['finalidade'] ?></option>
 <?php } ?>
 </select>
 </div>
		 </fieldset>
		<div class="form-group">
	<input type="submit" value="Selecionar compras"/>
	 <input type="reset" value="Limpar"/>
	  <input type="button" name="cancela" value="Cancelar" onclick="window.location.href='painelr.php'"/>
	 </div>
</form>
</div>
<?php include "footer.php"; ?>
  </body>
 </html>