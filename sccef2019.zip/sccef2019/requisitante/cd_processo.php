<<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../img/icone_barra.jpg" />
	 <title>Cadastro processos</title>
	 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>

	 <script type="text/javascript">
	 function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
 
function validacao() {


if(document.form.processo.value=="")
{
alert("Por favor preencha o numero de  processo.");
document.form.processo.focus();
return false;
}

if(document.form.nomereq.value=="Selecione...")
{
alert("Por favor selecione o nome do requisitante.");
document.form.nomereq.focus();
return false;
}

if(document.form.matserv.value=="Selecione...")
{
alert("Por favor Selecione se compra de materiais ou serviço.");
document.form.matserv.focus();
return false;
}


if(document.form.finalidade.value=="")
{
alert("Por favor preencha a finalidade.");
document.form.finalidade.focus();
return false;
}


if(document.form.requisita.value=="Selecione...")
{
alert("Por favor selecione o setor.");
document.form.requisita.focus();
return false;
}
}

</script>
 </head>
	 <body> <div class="container"><?php include "topo.php"; echo 'Usuário Logado: '; echo $logado; ?> 
 </div>
	 <?php
	$sql = mysqli_query($mysqli, "SELECT * FROM param_docs Where id=1");
	$count = mysqli_num_rows($sql);
if ($count == 0) 
{ echo "Nenhum resultado!"; } 
 else {
 if ($count == 1) 
 {echo "<br />";}
if ($count > 1)
{echo "$count resultados encontrados!<br />";}
while ($dados = mysqli_fetch_array( $sql))
{ 
$nreq=$dados['codigo'];
$b= '/';
$codreq= $nreq;

}}

?>
	 <div class="container">
	<h2 class="form-nome">Cadastro de processos</h2>
	<br />
	<br /><br />
	<form name="form" method="post" action="salva/salva_processo.php" onSubmit="return validacao();">
 <fieldset class="grupo">
		<div class="form-group">
		<label class="form-control">Requisição de compra n°:</label>
		<input type="text" class="form-control"  name="numreq" size="5" value="<?php echo "$nreq".$b.date('Y') ?>">
		 <input type="hidden" value="<?php echo "$nreq" ?>" name="codreq" />
			</div>	
			<div class="form-group">
		<label class="form-control">Data da abertura:</label>
<input class="form-control" type="text" name="datab" size="10" onkeypress="mascara(this, '##/##/####')"  maxlength="10"/>
 </div>
	<div class="form-group">
	<label class="form-control">N° do Processo: </label>
	<input type="text" class="form-control"  name="processo" id="idproc" size="13" maxlength="20" onkeypress="mascara(this, '#####.######/####-##')"/>
</div>	

 <div class="form-group">
		 <?php	   
  $query = mysqli_query($mysqli, "SELECT * FROM cdrequisitante ORDER BY nome ASC");
?>
 <label class="form-control" class="form-control" for="">Selecione o requisitante:</label>		     
 <select  class="form-control" name="nomereq">
 <option class="form-control" name="">Selecione...</option>
 <?php while($setor = mysqli_fetch_array($query)) { ?>
 <option class="form-control" value="<?php echo $setor['idr'] ?>"><?php echo $setor['nome'] ?></option>
 <?php } ?>
 </select>
 </div>
 		
<div class="form-group">
		 <?php	   
  $query = mysqli_query($mysqli, "SELECT * FROM cdfinalidade");
?>
 <label class="form-control" class="form-control" for="">Selecione se serviço  ou material:</label>		     
 <select class="form-control" name="matserv">
 <option class="form-control" name="">Selecione...</option>
 <?php while($setor = mysqli_fetch_array($query)) { ?>
 <option class="form-control" value="<?php echo $setor['id'] ?>"><?php echo $setor['final'] ?></option>
 <?php } ?>
 </select>
 </div>
 </fieldset>
 <fieldset class="grupo">
	<div class="form-group">
		<label class="form-control">Finalidade (objeto):</label>
		<input type="text" class="form-control"  name="finalidade" size="95" />
		</div>
		<div class="form-group">
		<label class="form-control">Observação:</label>
		 <input type="text" class="form-control"  name="observacao" size="95" /> 	
 </div>
	</fieldset>
 <input type="hidden" value="1" name="situacao"/>
	<input type="hidden" value="1" name="fase"/>
	
	<button type="submit" name="cadproc">Cadastrar processo</button>
	<button type="reset" name="limpar">Limpar</button>
	<input type="button" name="cancela" value="Cancelar" onclick="window.location.href='painelr.php'"/>
</form>
<div id="frame">
<iframe width="100%" height="auto" scrolling="yes" src="../frames/frameprocessos.php"> </iframe>
</div>
</div>
<?php include "footer.php"; ?>  
</body>
 </html>
