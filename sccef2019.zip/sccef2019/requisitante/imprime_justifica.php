<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../img/icone_barra.jpg" />
	 <title>pesquisa de preços</title> 
	 
	 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	 
	 
	 
	  <script type="text/javascript">
	    function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
 function moeda(z){
v = z.value;
v=v.replace(/\D/g,"") // permite digitar apenas numero
v=v.replace(/(\d{1})(\d{14})$/,"$1.$2") // coloca ponto antes dos ultimos digitos
v=v.replace(/(\d{1})(\d{11})$/,"$1.$2") // coloca ponto antes dos ultimos 11 digitos
v=v.replace(/(\d{1})(\d{8})$/,"$1.$2") // coloca ponto antes dos ultimos 8 digitos
v=v.replace(/(\d{1})(\d{5})$/,"$1.$2") // coloca ponto antes dos ultimos 5 digitos
v=v.replace(/(\d{1})(\d{1,2})$/,"$1,$2") // coloca virgula antes dos ultimos 2 digitos
z.value = v;
}

function validacao() {

if(document.form.processo.value=="Selecione...")
{
alert("Por favor selecione o processo.");
document.form.processo.focus();
return false;
}

}
</script>
 </head>
	  <body> <div class="container"><?php include "topo.php"; echo 'Usuário Logado: '; echo $logado; ?> 
 </div>
	 
   
	
	 <div class="container">
	<h2 class="form-nome">Justificativa</h2>
	<p></p>
	<p></p>
	
	<p></p>
	<p></p>
<form  name="form" method="GET" action="executa/exec_imprime_justifica.php" onSubmit="return validacao();">
	
	<fieldset class="grupo">
		 <div class="form-group">
		 <!---selecionar itens sem pesquisas --->
	<?php 
	$query = mysqli_query($mysqli, "SELECT * FROM cadcompras WHERE situacao=1 ORDER BY IDCOMPRA DESC");
?>
 <label class="form-control" class="form-control" for="">Selecione o processo</label>
 <select class="form-control" name="processo">
 <option class="form-control" name="">Selecione...</option>
 <?php 
 while($busca = mysqli_fetch_array($query)) { 
 ?>
 <option class="form-control" value="<?php 
 echo $busca['idcompra'] 
 ?>">
 <?php 
 echo $busca['processo'].' - '.$busca['finalidade'];?>
 </option>
 <?php } ?>
 </select>
</div>
</fieldset>

 <div class="form-group">
<input type="submit" id="submit" value="Imprimir" />
<input type="reset" id="reset" value="Limpar dados" />
<input type="button" name="cancela" value="Cancelar" onclick="window.location.href='painelr.php'"/>
</div>
</form>
</div>

	<?php include "/footer.php"; ?> 
	</body>
 </html>