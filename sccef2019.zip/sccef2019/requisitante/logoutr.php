<!DOCTYPE html>
 <html lang="pt-br">
 <head>
	 <title>Sair</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	 <link rel="stylesheet" href="css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="css/bootstrap.css" type="text/css"/>
   </head>
	 <body> <?php include "topo.php" ?>
	 <div class="container">
<?php
session_start ();
session_destroy();
header ("Locatiion: index.php");
echo '<p class="center">Saída do sistema com sucesso!</p>';
echo "<meta HTTP-EQUIV='refresh' CONTENT='1;URL=../index.php'>";
?>
<p class="center"><img src="../img/caes.gif">
</p>
<?php
//echo "<meta HTTP-EQUIV='refresh' CONTENT='1;URL=index.php'>";
?>
<?php include "footer.php" ?></body>
</html>