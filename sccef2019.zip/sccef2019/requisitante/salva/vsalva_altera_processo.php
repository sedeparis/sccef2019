<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<title>Gerenciamento de compras
</title>
<link rel="stylesheet" type="text/css" href="../../css/reset.css" media="screen"/>
<link rel="stylesheet" type="text/css" href="../../css/bootstrap.css" media="screen"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
</head>
<body>
<?php include "topo.php"; ?>
<div class="container">
<?php

// Cria uma variável que terá os dados do erro
$erro = false;

$altera=$_POST['altera'];
$processo=$_POST['processo'];
$datab=$_POST['datab'];
$finalidade=$_POST['finalidade'];
$observacao=$_POST['observacao'];
$tipo=$_POST['matserv'];
$nomereq=$_POST['nomereq'];



// Verifica se o POST tem algum valor
if ( !isset( $_POST ) || empty( $_POST ) ) {
	$erro = 'Nada foi postado.';
}

 
// Cria as variáveis dinamicamente
foreach ( $_POST as $chave => $valor ) {
	// Remove todas as tags HTML
	// Remove os espaços em branco do valor
	$$chave = trim( strip_tags( $valor ) );
	
	// Verifica se tem algum valor nulo
	if ( empty ( $valor ) ) {
		$erro = 'Existem campos obrigatórios em branco.';
	}
}


// Verifica se $altera realmente existe e se é um número. 
// Também verifica se não existe nenhum erro anterior
if ( ( ! isset( $altera) || ! is_numeric( $altera ) ) && !$erro ) {
	$erro = 'Falhou a condução da variavel altera. Se o problema persistir procure o suporte.';
}




// Verifica se $finalidade realmente existe e se é texto-string. 
// Também verifica se não existe nenhum erro anterior
if(strlen($processo)<=10){$erro = 'Descrição  muita curta para descrever a finalidade.';}
if ( ( ! isset( $processo) || ! is_string( $processo ) ) && !$erro ) {
	$erro = 'Descrição da processo esta vazia ou muita curta para validar.';
}


// Verifica se $finalidade realmente existe e se é texto-string. 
// Também verifica se não existe nenhum erro anterior
if(strlen($datab)<=2){$erro = 'Erro na informação da data.';}
if ( ( ! isset( $datab) || ! is_string( $datab ) ) && !$erro ) {
	$erro = 'Data esta vazia ou incorreta.';
}


// Verifica se $finalidade realmente existe e se é texto-string. 
// Também verifica se não existe nenhum erro anterior
if(strlen($finalidade)<=2){$erro = 'Descrição  muita curta para descrever a finalidade.';}
if ( ( ! isset( $finalidade) || ! is_string( $finalidade ) ) && !$erro ) {
	$erro = 'Descrição da finalidade esta vazia ou muita curta para validar.';
}



// Verifica se $tipo realmente existe e se é um número. 
// Também verifica se não existe nenhum erro anterior
if ( ( ! isset( $tipo) || ! is_numeric( $tipo ) ) && !$erro ) {
	$erro = 'Falhou a condução da variavel tipo . Se o problema persistir procure o suporte.';
}


// Verifica se $quant realmente existe e se é um número. 
// Também verifica se não existe nenhum erro anterior
if ( ( ! isset( $nomereq) || ! is_numeric( $nomereq ) ) && !$erro ) {
	$erro = 'Você não Selecionou o requisitante.';
}


// Se existir algum erro, mostra o erro
if ( $erro ) {
	echo $erro;
	echo '<br>Reinicie	e informe os dados corretamente!<br> <a href=../altera_processo.php>Voltar</a>';
} else {
	// Se a variável erro continuar com valor falso
	// Você pode fazer o que preferir aqui, por exemplo, 
	// enviar para a base de dados, ou enviar um email
	// Tanto faz. Vou apenas exibir os dados na tela.
	include 'salva_altera_processo.php';
	}

?>


</div>
<?php include "footer.php"; ?>
</body>
</html>