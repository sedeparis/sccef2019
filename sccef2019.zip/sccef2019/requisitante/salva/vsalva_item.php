<<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Cadastro de item</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 <link rel="stylesheet" href="../../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" type="text/css" href="../../css/bootstrap.css" media="screen"/>
 </head>
	 <body>
	 <?php include "topo.php"; ?>
	 <div class="container">
<?php
 
// Cria uma variável que terá os dados do erro
$erro = false;

//recebe do cd_item
$processo=$_POST['processo'];
$nitem=$_POST['nitem'];
$ditem=$_POST['ditem'];
$quant=$_POST['quant'];
$quantidade=$_POST['quantidade'];
$un=$_POST['un'];




// Verifica se o POST tem algum valor
if ( !isset( $_POST ) || empty( $_POST ) ) {
	$erro = 'Nada foi postado.';
}

 
// Cria as variáveis dinamicamente
foreach ( $_POST as $chave => $valor ) {
	// Remove todas as tags HTML
	// Remove os espaços em branco do valor
	$$chave = trim( strip_tags( $valor ) );
	
	// Verifica se tem algum valor nulo
	if ( empty ( $valor ) ) {
		$erro = 'Existem campos obrigatórios em branco.';
	}
}

// Verifica se $processo realmente existe e se é um número. 
// Também verifica se não existe nenhum erro anterior
if ( ( ! isset( $processo) || ! is_numeric( $processo ) ) && !$erro ) {
	$erro = 'Selecione um processo.';
}


// Verifica se $nitem realmente existe e se é um número. 
// Também verifica se não existe nenhum erro anterior
if(strlen($ditem)<=2){$erro = 'Descrição  muita curta para descrever um item.';}
if ( ( ! isset( $ditem) || ! is_string( $ditem ) ) && !$erro ) {
	$erro = 'Descrição esta vazia ou muita curta para descrever um item.';
}


// Verifica se $nitem realmente existe e se é um número. 
// Também verifica se não existe nenhum erro anterior
if ( ( ! isset( $nitem) || ! is_numeric( $nitem ) ) && !$erro ) {
	$erro = 'número do item deve ser um valor número.';
}


// Verifica se $quant realmente existe e se é um número. 
// Também verifica se não existe nenhum erro anterior
if ( ( ! isset( $quant) || ! is_numeric( $quant ) ) && !$erro ) {
	$erro = 'quantidade mínima tem que ser numero.';
}


// Verifica se $quant realmente existe e se é um número. 
// Também verifica se não existe nenhum erro anterior
if ( ( ! isset( $quantidade) || ! is_numeric( $quantidade ) ) && !$erro ) {
	$erro = 'quantidade máxima tem que ser numero.';
}


// Verifica se $un realmente existe e se é um número. 
// Também verifica se não existe nenhum erro anterior
if ( ( ! isset( $un) || ! is_numeric( $un ) ) && !$erro ) {
	$erro = 'Selecione uma unidade.';
}

// Se existir algum erro, mostra o erro
if ( $erro ) {
	echo $erro;
	echo '<br>Volte para a tela anterior e informe os dados corretamente!<br> <a href=../cd_item.php>Voltar</a>';
} else {
	// Se a variável erro continuar com valor falso
	// Você pode fazer o que preferir aqui, por exemplo, 
	// enviar para a base de dados, ou enviar um email
	// Tanto faz. Vou apenas exibir os dados na tela.
	include 'salva_item.php';
	}

?>

</div>

</body>
</html>