<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<title>Pesquisa preços</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <link rel="stylesheet" type="text/css" href="../../css/reset.css"/>
  <link rel="stylesheet" type="text/css" href="../../css/bootstrap.css" media="screen"/>
</head>
<body>
<?php include "topo.php"; ?>
<div class="container">
<h2>Pesquisa de preços</h2>
<?php
$iditem=$_POST['altera'];
$nomea=$_POST['nomea'];
$valor1=$_POST['valora'];
$fontea=$_POST['fontea'];
$dataa=$_POST['dataa'];
$pe1=$_POST['pea'];
 
$nomeb=$_POST['nomeb'];
$valor2=$_POST['valorb'];
$fonteb=$_POST['fonteb'];
$datab=$_POST['datab'];
$pe2=$_POST['peb'];

$nomec=$_POST['nomec'];
$valor3=$_POST['valorc'];
$fontec=$_POST['fontec'];
$datac=$_POST['datac'];
$pe3=$_POST['pec'];

$valorz = str_replace(',','.',str_replace('.','',$valor1)); 
$valory = str_replace(',','.',str_replace('.','',$valor2)); 
$valorx = str_replace(',','.',str_replace('.','',$valor3));  
?>
<?php 
$cslt= mysqli_query($mysqli, "SELECT * FROM produto WHERE id= '$iditem' ");
$ret = mysqli_num_rows($cslt);
if ($ret == 0){echo "Item não encontrado";}
While ($lista = mysqli_fetch_array ($cslt))
{
$qtd=$lista['estoque_maximo'];

 }
?>
<?php
$tot_estimadoa = ($qtd * $valorz );
$tot_estimadob = ($qtd * $valory );
$tot_estimadoc = ($qtd * $valorx );
 

$sql = mysqli_query($mysqli, "UPDATE produto SET p1='$valorz', p2='$valory', p3='$valorx', 
dp1='$dataa', dp2='$datab', dp3='$datac',
fcp1='$fontea', fcp2='$fonteb', fcp3='$fontec',
 fnp1='$nomea', fnp2 ='$nomeb', fnp3 ='$nomec', 
 pe1 ='$pe1', pe2='$pe2', pe3='$pe3',
  	tot_estimado= '$tot_estimadoa',  tot_estimado2 = '$tot_estimadob',  tot_estimado3 = '$tot_estimadoc',
 ip='S'
 WHERE id='$iditem'");
$resultado = mysqli_query($mysqli, $sql);
{echo "Pesquisa informada com sucesso!";
}
?>


<br /> <p class="center"><img src="../../img/salva.gif"/></p><br /><br />
<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='3;URL=../pesquisa_preco.php'>";
?>
</div>
<?php include "footer.php"; ?>
</body> 
</html>
