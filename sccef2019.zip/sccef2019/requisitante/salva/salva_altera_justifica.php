<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<title>Gerenciamento de compras
</title>
<link rel="stylesheet" type="text/css" href="../../../css/reset.css" media="screen"/>
<link rel="stylesheet" type="text/css" href="../../css/bootstrap.css" media="screen"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
</head>
<body>
 <?php include "topo.php"; ?>
<div class="container">
<?php
$idj=$_POST['idj'];
$t1=$_POST['t1'];
$t2=$_POST['t2'];
$t3=$_POST['t3'];
$t4=$_POST['t4'];
$t5=$_POST['t5'];
$t6=$_POST['t6'];
$t7=$_POST['t7'];
$t8=$_POST['t8'];
$t9=$_POST['t9'];
$t10=$_POST['t10'];
?>

<?php
$sql = mysqli_query($mysqli, "UPDATE cdjustificativa SET text1 ='$t1',text2 ='$t2', text3 ='$t3',text4 ='$t4',text5 ='$t5',text6 ='$t6',text7 ='$t7',
text8 ='$t8',text9 ='$t9',text10 ='$t10' WHERE idj ='$idj'");
$resultado = mysqli_query ($mysqli, $sql);
?>
 <p class="center"><img src="../../img/salva.gif"/></p>
<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='2;URL=../painelr.php'>";
?>
</div>
 <?php include "footer.php"; ?>
</body>
</html>