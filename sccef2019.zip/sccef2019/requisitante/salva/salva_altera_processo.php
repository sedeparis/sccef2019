<?php
//session_start();
//	$_SESSION ['email'];
//	$_SESSION ['senha'];
//	$logado=$_SESSION ['email'];
	//echo '<div class="container">';
	//echo 'Acessado como: $logado';
	//echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<title>Gerenciamento de compras
</title>
<link rel="stylesheet" type="text/css" href="../../css/reset.css" media="screen"/>
<link rel="stylesheet" type="text/css" href="../../css/bootstrap.css" media="screen"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
</head>
<body>
<?php include "topo.php"; ?>
<div class="container">
<?php
$altera=$_POST['altera'];
$processo=$_POST['processo'];
$finalidade=$_POST['finalidade'];
$observacao=$_POST['observacao'];
$tipo=$_POST['matserv'];
$nomereq=$_POST['nomereq'];
$datab=$_POST['datab'];

$sql = mysqli_query($mysqli, "UPDATE cadcompras SET processo='$processo', datab='$datab', finalidade='$finalidade', observacao='$observacao',  
  matserv='$tipo',  nomereq='$nomereq' WHERE idcompra ='$altera'");
$resultado = mysqli_query ($mysqli, $sql);
{echo " Processo alterado com sucesso!";
}

?>
 <p class="center"><img src="../../img/salva.gif"/></p>
<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='3;URL=../painelr.php'>";
?>
</div>
<?php // include "footer.php"; ?>
</body>
</html>