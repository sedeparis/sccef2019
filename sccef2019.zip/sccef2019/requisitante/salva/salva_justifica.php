<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<title>Salvar justificativa</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <link rel="stylesheet" type="text/css" href="../../css/reset.css"/>
  <link rel="stylesheet" type="text/css" href="../../css/bootstrap.css" media="screen"/>
</head>
<body>
<?php include "topo.php"; ?>
<div class="container">
<h2>Salvar Justificativa</h2>
<?php
$processo=$_POST['processo'];
$text1=$_POST['text1'];
$text2=$_POST['text2'];
$text3=$_POST['text3'];
$text4=$_POST['text4'];
$text5=$_POST['text5'];
$text6=$_POST['text6'];
$text7=$_POST['text7'];
$text8=$_POST['text8'];
$text9=$_POST['text9'];
$text10=$_POST['text10'];
 
  

$sql = mysqli_query($mysqli, "INSERT INTO cdjustificativa (processo, text1, text2, text3, text4, text5, text6, text7, text8, text9, text10) 
VALUES('$processo', '$text1', '$text2', '$text3', '$text4','$text5', '$text6', '$text7', '$text8', '$text9','$text10')");
$resultado = mysqli_query ($mysqli, $sql);
{echo "Cadastro efetuado com sucesso!";}
?>
<br /> <p class="center"><img src="../../img/salva.gif"/></p><br />
<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='1;URL=../executa/exec_imprime_justifica.php?processo=$processo'>";
?>
</div>
<?php include "footer.php"; ?>
</body>
</html>
