<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
echo 'Acessado como:  '.$logado;
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
 <img class="logo" src="../../img/banner.jpg">
<title>Pesquisa preços</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <link rel="stylesheet" href="../../css/bootstrap.css" type="text/css"/>
  <link href="../../css/custom.css" rel="stylesheet" />
</head>
<body>
<?php include 'topo.php';?>
<div class="container">
<h2>Pesquisa de preços</h2>
<?php


$iditem=$_POST['item'];
$qtd=$_POST['qtd'];
$nomea=$_POST['nomea'];
$valor1=$_POST['valora'];
$fontea=$_POST['fontea'];
$dataa=$_POST['dataa'];
$pe1=$_POST['pea'];
 
 
$nomeb=$_POST['nomeb'];
$valor2=$_POST['valorb'];
$fonteb=$_POST['fonteb'];
$datab=$_POST['datab'];
$pe2=$_POST['peb'];

$nomec=$_POST['nomec'];
$valor3=$_POST['valorc'];
$fontec=$_POST['fontec'];
$datac=$_POST['datac'];
$pe3=$_POST['pec'];

$valorz = str_replace(',','.',str_replace('.','',$valor1)); 
$valory = str_replace(',','.',str_replace('.','',$valor2)); 
$valorx = str_replace(',','.',str_replace('.','',$valor3));  

?>

<?php
// cria a instrução SQL que vai selecionar a quantidade do item
$query = ("SELECT * FROM caditem WHERE iditem ='$iditem' ");
// executa a query
$dados = mysqli_query ($mysqli, $sql);
// transforma os dados em um array
$linha = mysqli_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysqli_num_rows($dados);
?>
<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($total == 0) {echo "";}
	if($total > 0) { 
		// inicia o loop que vai mostrar todos os dados
		do {

$quanto= $linha['quant_lic'];

?>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = mysqli_fetch_assoc($dados));
	// fim do if 
	}
?>
<?php
// tira o resultado da busca da memória
mysqli_free_result($dados);
?>
<?php


$tot_estimadoa = ($quanto * $valorz );
$tot_estimadob = ($quanto * $valory );
$tot_estimadoc = ($quanto * $valorx );


// tirar
// $tot_estimado = str_replace(',','.',str_replace('.','',$tot_estimadoa)); 
// $tot_estimado2 = str_replace(',','.',str_replace('.','',$tot_estimadob)); 
// $tot_estimado3 = str_replace(',','.',str_replace('.','',$tot_estimadoc)); 

$sql = mysqli_query("UPDATE caditem SET p1='$valorz', dp1='$dataa', fcp1='$fontea', fnp1='$nomea', p2='$valory',
 dp2='$datab', fcp2='$fonteb', fnp2 ='$nomeb', p3='$valorx', dp3='$datac', 
 fcp3='$fontec', fnp3 ='$nomec', pe1 ='$pe1', pe2='$pe2' , pe3='$pe3',
 tot_estimado = '$tot_estimadoa',  tot_estimado2 = '$tot_estimadob',  tot_estimado3 = '$tot_estimadoc', ip='S'
 WHERE iditem='$iditem'");
$resultado = mysqli_query ($sql);
{echo "Pesquisa informada com sucesso!";
}
?>
<?php
// tira o resultado da busca da memória
mysqli_free_result($dados);
?>
<br />
<br /><br /><br />
<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='2;URL=../pesquisa_preco.php'>";
?>
</div>
<?php include 'footer.php';?>
</body> 
</html>
