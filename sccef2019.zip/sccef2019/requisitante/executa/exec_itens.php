﻿<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como:  '.$logado;
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<title>listas itens</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 <link href="../../css/print_tab.css" rel="stylesheet" />
	  <link href="../../css/print_div.css" rel="stylesheet" />
	   <link href="../../css/print_fontes.css" rel="stylesheet" />
 </head>
	 <body>
	 <div class="cabecalho">
	  <?php include "cabecalho.php"; ?> 
	  </div>
	 <div class="titulo">
	 <h3>Lista itens compra</h3>
	 </div>
<?php
$processo=$_POST['processo'];
// cria a instrução SQL que vai selecionar os dados de processo
$query = ("SELECT * FROM cadcompras WHERE processo = '$processo'");
// executa a query
$dadosa = mysqli_query ($mysqli, $query);
// transforma os dados em um array
$linhaa = mysqli_fetch_assoc($dadosa);
// calcula quantos dados retornaram
$totala = mysqli_num_rows($dadosa);
?>
<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($totala > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
$processob=$linhaa['processo'];
$finalidade=$linhaa['finalidade'];
?>
<div class="textos">
<span class="subtitulo">Processo:</span>
<span class="rsubtitulo"><?php echo $processo ?></span>
</br>
<span class="subtitulo">Finalidade:</span>
<span class="rsubtitulo"><?php echo $finalidade ?></span>
</div>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = mysqli_fetch_assoc($dadosa));
	// fim do if 
	}
?>
<HR>
<table>
<colgroup>
<col width="6%">
<col width="74%">
<col width="10%">
<col width="10%">
</colgroup>
<thead>
<tr>
<th>It</th>
<th>Descrição</th>
<th>Qt Lic</th>
<th>Un</th>
</tr>
</thead>
</table>
<?php
// cria a instrução SQL que vai selecionar os dos itens
$query = ("SELECT * FROM produto INNER JOIN cdunidade ON Produto.un=cdunidade.idun WHERE idprocesso = '$processo'");
// executa a query
$dados = mysqli_query ($mysqli, $query);
// transforma os dados em um array
$linha = mysqli_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysqli_num_rows($dados);
?>
<!-- mostra itens empenhados-->

<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($total > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
$nitem=$linha['nitem'];
$ditem=$linha['descricao'];
$qtl=$linha['estoque_maximo'];
$idun=$linha['unidade'];
?>
<table>
<colgroup>
<col width="6%">
<col width="74%">
<col width="10%">
<col width="10%">
</colgroup>
<tbody>
<tr>
<td><?php echo "$nitem"?></td>
<td><?php echo "$ditem"?></td>
<td><?php echo "$qtl"?></td>
<td><?php echo "$idun"?></td>
</tr>
</tbody>
</table>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = mysqli_fetch_assoc($dados));
	// fim do if 
	}
?>
<hr>
<br />
<br />
<input type="button" name="voltar" value="Voltar" onclick="window.location.href='../painelr.php'"/>
</div>
	</div>
	</body> 
	</html>