 <?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como:  '.$logado;
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema Administrativo compras públicas.</title>
	 <link href="../../css/print_tab.css" rel="stylesheet" />
	  <link href="../../css/print_div.css" rel="stylesheet" />
	   <link href="../../css/print_fontes.css" rel="stylesheet" />
   
	    <script>
function funcao1()
{
alert("Antes de imprimir Configure a página. Na aba Geral, Orientação Retrato, Escala 100%.");
}
</script>
		<!--- scripts de validação de formulário --->
 </head>
	 <body> 
	 <div class="cabecalho">
	  <?php include "cabecalho.php"; ?> 
	  </div>
	 <div class="titulo">
	<h3>REQUERIMENTO DE COMPRA E CONTRATAÇÃO</h3>
	 <?php
	 $processo=$_POST['processo'];
 //cria a instrução SQL que vai selecionar os dados para o cabeçalho
$sql = mysqli_query($mysqli, "SELECT * FROM cdorgao WHERE orgao_principal ='S'");
 $count = mysqli_num_rows($sql);
if ($count == 0) 
{ echo "Nenhum resultado!" ;}
while ($dados = mysqli_fetch_array($sql))
{ echo "";
 
$endereco=$dados['endereco'];
 $orgao=$dados['nome'];
 $dirad=$dados['gestor'];
 $dirge=$dados['diretor'];
$local= $dados['cidade'];
 $uf=$dados['uf'];
 $fonte=$dados['fonte'];
 $preprocesso=$dados['iniprocesso'];
 }
?>
</div>
 <?php
 //cria a instrução SQL que vai selecionar os dados para o cabeçalho
$sqlb = mysqli_query($mysqli, "SELECT * FROM produto WHERE idprocesso ='$processo'");
 $countb = mysqli_num_rows($sqlb);
if ($countb == 0) 
{ echo "Nenhum resultado!" ;}
while ($dadosb = mysqli_fetch_array($sqlb))
{ echo "";

 }
?>
<?php

// cria a instrução SQL que vai selecionar os dados do processo e fornecedor
$query = sprintf("SELECT * FROM cadcompras WHERE idcompra ='$processo'");
// executa a query
$dadosii = mysqli_query ($mysqli, $query);
// transforma os dados em um array
$linhaii = mysqli_fetch_assoc($dadosii);
// calcula quantos dados retornaram
$totalii = mysqli_num_rows($dadosii);
?>

<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($totalii > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
		$finalidade = $linhaii['finalidade'];
	$tipo = $linhaii['tipo'];
	$numcompra = $linhaii['numcompra'];
	$process = $linhaii['processo'];
	$requesita = $linhaii['nomereq'];
	$matserv = $linhaii['matserv'];
		?>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linhaii = mysqli_fetch_assoc($dadosii));
	// fim do if 
	}
?>
<div class="textos">
<span class="subtitulo">
Processo:
</span>
<span class="rsubtitulo">
<?php echo "$process"?>
</span>
<br>
<span class="subtitulo">
Finalidade:
</span>
<span class="rsubtitulo">
<?php echo "$finalidade" ?>
</span>
</div>
<div class="tabela">
<table>
<colgroup>
<col width="5%">
<col width="45%">
<col width="10%">
<col width="10%">
<col width="10%">
<col width="10%">
<col width="10%">
</colgroup>
<thead>
<tr>
<th>Item</th>
<th>Descrição</th>
<th>Un</th>
<th>Qtd min</th>
<th>Qtd max</th>
<th>R$/un</th>
<th>R$/total</th>
</tr>
</thead>
</table>

<?php
// tira o resultado da busca da memória
mysqli_free_result($dadosii);
?>
<?php
// cria a instrução SQL que vai selecionar os dos itens
$queryb = ("SELECT * FROM produto INNER JOIN cdunidade ON produto.un=cdunidade.idun WHERE idprocesso ='$processo' AND (finalizado = 0)");
// executa a query
$dados = mysqli_query ($mysqli, $queryb);
// transforma os dados em um array
$linha = mysqli_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysqli_num_rows($dados);
?>


<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($total > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
$valor =$linha['p1'];
$nitem = $linha['nitem'];
$descricao= $linha['descricao'];
$quanto= $linha['estoque_minimo'];
$quantmax= $linha['estoque_maximo'];
$un= $linha['unidade'];
$valori =($valor*$quantmax);
 ?>
<table>
<colgroup>
<col width="05%">
<col width="45%">
<col width="10%">
<col width="10%">
<col width="10%">
<col width="10%">
<col width="10%">
</colgroup>
<tbody>
<tr>
<td><?php echo "$nitem"?></td>
<td><?php echo "$descricao"?></td>
<td><?php echo "$un"?></td>
<td><?php echo "$quanto"?></td>
<td><?php echo "$quantmax"?></td>
<td><?php echo number_format($valor,2, ",",".");?></td>
<td><?php echo number_format($valori,2, ",",".");?></td>
</tr>
</tbody>
</table>

<?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = mysqli_fetch_assoc($dados));
	// fim do if 
	}
?>
<?php
// cria a instrução SQL que vai selecionar os dados da soma total preço estimado 1
$result = mysqli_query($mysqli, "SELECT SUM(tot_estimado) AS valor_soma FROM produto WHERE idprocesso ='$processo' AND (finalizado = 0)");
 //executa a query
$row = mysqli_fetch_assoc($result);
$sum = $row['valor_soma'];
?>
<table>
<tr>
<td width="60%"><P class="total">Total estimado:</p>
</td>
<td width="40%"><P class="total"><?php echo number_format($sum,2, ",",".");?>
</p>
</td>
</tr>
</table>
</div>
<?php
// cria a instrução SQL que vai selecionar os dados do processo e fornecedor
$queryc = sprintf("SELECT * FROM cdrequisitante WHERE idr ='$requesita'");
// executa a query
$dadosi = mysqli_query ($mysqli, $queryc);
// transforma os dados em um array
$linhai = mysqli_fetch_assoc($dadosi);
// calcula quantos dados retornaram
$totali = mysqli_num_rows($dadosi);

	// se o número de resultados for maior que zero, mostra os dados//
	if($totali > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
			$nomesolic = $linhai['nome'];
	$siape = $linhai['siape'];
	
	
		// finaliza o loop que vai mostrar os dados
		}while($linhaii = mysqli_fetch_assoc($dadosi));
	// fim do if 
	}
	?>
<?php
// tira o resultado da busca da memória
mysqli_free_result($dadosi);
?>
<br />
<br />
<div class="textos">

<p class="center">REQUISITANTE:</p>
<p class="direita">
<br />
Em, ____/____/______
<br />
</p>
<br />
<p class="center">___________________________<br />
<?php echo "$nomesolic"?><br />
 <b>Solicitante </b><br />
 <?php echo "$siape"?><br /></p>


<br />
<p class="center">ORDENADOR(A) DE DESPESAS</p>
<br />
<br /><br />
<p class="var">(  ) Autorizo a abertura do processo administrativo, nos termos do art. 38 da Lei nº 8.666/1993.</p>
<p class="var">(  )  Não autorizo a abertura do processo administrativo, conforme motivação anexa. Encaminhe-se ao setor requisitante para ciência e arquivamento. </p>
<br />
<br />
<p class="direita"><?php echo "$local-$uf" ?> em </b> ___/____/20___</p>

<br />
<br />
<br />
<p class="center">
_______________________________________
<br />
Ordenador de Despesas
</p>

</div>
<div class="button">
<input type="button" name="cancela" value="Voltar" onclick="window.location.href='../painelr.php'"/>
</div>
</body> 
</html>