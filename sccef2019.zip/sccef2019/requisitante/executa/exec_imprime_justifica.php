 <?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como:  '.$logado;
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema Administrativo compras públicas.</title>
	 <link href="../../css/print_tab.css" rel="stylesheet" />
	  <link href="../../css/print_div.css" rel="stylesheet" />
	   <link href="../../css/print_fontes.css" rel="stylesheet" />
   
	    
		<!--- scripts de validação de formulário --->
 </head>
	 <body> 
	 <div class="cabecalho">
	  <?php include "cabecalho.php"; ?> 
	  </div>
	 <div class="titulo">
	 <h3>JUSTIFICATIVA</h3>
	 	  </div>
	  <?php 
	  // pega valores da pagina anterior
	  $processo=$_GET['processo'];
	 
 //cria a instrução SQL que vai selecionar os dados para o cabeçalho
$sql = mysqli_query($mysqli, "SELECT * FROM cdorgao WHERE orgao_principal ='S'");
 $count = mysqli_num_rows($sql);
if ($count == 0) 
{ echo "Nenhum resultado!" ;}
while ($dados = mysqli_fetch_array($sql))
{ echo "";
 
$endereco=$dados['endereco'];
 $orgao=$dados['nome'];
 $dirad=$dados['gestor'];
 $dirge=$dados['diretor'];
$local= $dados['cidade'];
 $uf=$dados['uf'];
 $fonte=$dados['fonte'];
 $preprocesso=$dados['iniprocesso'];
 }
?>
<?php
// cria a instrução SQL que vai selecionar os dados do processo e fornecedor
$query = sprintf("SELECT * FROM cadcompras WHERE idcompra ='$processo'");
// executa a query
$dadosii = mysqli_query($mysqli, $query);
// transforma os dados em um array
$linhaii = mysqli_fetch_assoc($dadosii);
// calcula quantos dados retornaram
$totalii = mysqli_num_rows($dadosii);
?>

<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($totalii > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
		$finalidade = $linhaii['finalidade'];
		$requis = $linhaii['nomereq'];
		$proces = $linhaii['processo'];
		?>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linhaii = mysqli_fetch_assoc($dadosii));
	// fim do if 
	}
?>

<div class="textos">
<span class="subtitulo">
Processo:
</span>
<span class="rsubtitulo">
<?php echo "$proces"?>
</span>
<br>
<span class="subtitulo">
Finalidade:
</span>
<span class="rsubtitulo">
<?php echo "$finalidade" ?>
</span>
</div>
<?php
// tira o resultado da busca da memória
mysqli_free_result($dadosii);
?>

<hr>
<?php
// cria a instrução SQL que vai selecionar os dados do processo e fornecedor
$queryb = sprintf("SELECT * FROM cdjustificativa WHERE processo ='$processo'");
// executa a query
$dadosi = mysqli_query ($mysqli, $queryb);
// transforma os dados em um array
$linhai = mysqli_fetch_assoc($dadosi);
// calcula quantos dados retornaram
$totali = mysqli_num_rows($dadosi);

	// se o número de resultados for maior que zero, mostra os dados//
	if($totali > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
	$t1 = $linhai['text1'];
	$t2 = $linhai['text2'];
	$t3 = $linhai['text3'];
	$t4 = $linhai['text4'];
	$t5 = $linhai['text5'];
	$t6 = $linhai['text6'];
	$t7 = $linhai['text7'];
	$t8 = $linhai['text8'];
	$t9 = $linhai['text9'];
	$t10 = $linhai['text10'];
		// finaliza o loop que vai mostrar os dados
		}while($linhaii = mysqli_fetch_assoc($dadosi));
	// fim do if 
	}
	?>
	<div class="textos">
	<?php
echo '<p class="var">' .$t1 .'</p>';
echo '<p class="var">' .$t2.'</p>';
echo '<p class="var">' .$t3.'</p>';
echo '<p class="var">' .$t4.'</p>';
echo '<p class="var">' .$t5.'</p>';
echo '<p class="var">' .$t6.'</p>';
echo '<p class="var">' .$t7.'</p>';
echo '<p class="var">' .$t8.'</p>';
echo '<p class="var">' .$t9.'</p>';
echo '<p class="var">' .$t10.'</p>';
 ?>
</div>
<?php
// tira o resultado da busca da memória
mysqli_free_result($dadosi);
?>
<?php
// cria a instrução SQL que vai selecionar os dados do processo e fornecedor
$queryc = sprintf("SELECT * FROM cdrequisitante WHERE idr ='$requis'");
// executa a query
$dadosc = mysqli_query ($mysqli, $queryc);
// transforma os dados em um array
$linhac = mysqli_fetch_assoc($dadosc);
// calcula quantos dados retornaram
$totalc = mysqli_num_rows($dadosc);

	// se o número de resultados for maior que zero, mostra os dados//
	if($totalii > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
			$nomesolic = $linhac['nome'];
	$siape = $linhac['siape'];
	
	
		// finaliza o loop que vai mostrar os dados
		}while($linhac = mysqli_fetch_assoc($dadosc));
	// fim do if 
	}
	?>

<div class="textos">

<p class="direita"><?php echo "$local-$uf" ?> em  ___/____/20___
</p>

<br />
<br />
<br />
<p class="center">_______________________________ <br /><?php echo "$nomesolic"?><br />
 Solicitante <br />
 <?php echo "$siape"?><br />
 </p>
<br />

<br />
<?php
// tira o resultado da busca da memória
mysqli_free_result($dadosc);
?>

<br />
</div>
<div class="button">
<input type="button" name="cancela" value="Voltar" onclick="window.location.href='../painelr.php'"/>
</div>
</body>
</html>