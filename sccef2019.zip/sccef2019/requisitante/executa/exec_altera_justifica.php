<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
echo 'Acessado como:  '.$logado;
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<title>Alterar justifica
</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
 
  

</head>
<body> <?php include "topo.php"; ?>
<div class="container">
<h2>Alterar justifica</h2>
<?php
$altera=$_POST['altera'];
// cria a instrução SQL que vai selecionar os dados
$query = sprintf("SELECT * FROM cdjustificativa WHERE idj ='$altera'");
// executa a query
$dados = mysqli_query ($mysqli, $query);
// transforma os dados em um array
$linha = mysqli_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysqli_num_rows($dados);
?>

<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($total > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
		
?>
<form name="form" method="post" action="../salva/salva_altera_justifica.php" onSubmit="return validacao();">
<input type="hidden" name="idj" value="<?php print $linha['idj']?>"/>
<fieldset class="grupo">
		<div class="form-group">
<label class="form-control"><b>Paragrafo 1º:</b></label>
<textarea class="form-control" name="t1" cols="100" rows="5"> <?php print $linha['text1']?>  </textarea>
</div>
<div class="form-group">
<label class="form-control"><b>Paragrafo 2º:</b></label>
<textarea class="form-control" name="t2" cols="100" rows="5"> <?php print $linha['text2']?>  </textarea>
</div>
<div class="form-group">
<label class="form-control"><b>Paragrafo 3º:</b></label>
<textarea class="form-control" name="t3" cols="100" rows="5"> <?php print $linha['text3']?>  </textarea>
</div>
<div class="form-group">
<label class="form-control"><b>Paragrafo 4º:</b></label>
<textarea class="form-control" name="t4" cols="100" rows="5"> <?php print $linha['text4']?>  </textarea>
</div>
<div class="form-group">
<label class="form-control"><b>Paragrafo 5º:</b></label>
<textarea class="form-control" name="t5" cols="100" rows="5"> <?php print $linha['text5']?>  </textarea>
</div>
<div class="form-group">
<label class="form-control"><b>Paragrafo 6º:</b></label>
<textarea class="form-control" name="t6" cols="100" rows="5"> <?php print $linha['text6']?>  </textarea>
</div>
<div class="form-group">
<label class="form-control"><b>Paragrafo 7º:</b></label>
<textarea class="form-control" name="t7" cols="100" rows="5"> <?php print $linha['text7']?>  </textarea>
</div>
<div class="form-group">
<label class="form-control"><b>Paragrafo 8º:</b></label>
<textarea class="form-control" name="t8" cols="100" rows="5"> <?php print $linha['text8']?>  </textarea>
</div>
<div class="form-group">
<label class="form-control"><b>Paragrafo 9º:</b></label>
<textarea class="form-control" name="t9" cols="100" rows="5"> <?php print $linha['text9']?>  </textarea>
</div>
<div class="form-group">
<label class="form-control"><b>Paragrafo 10º:</b></label>
<textarea class="form-control" name="t10" cols="100" rows="5"> <?php print $linha['text10']?>  </textarea>
</div>
 </fieldset>
 <fieldset class="grupo">
		<div class="form-group">
 <input type="submit" value="Alterar" name="altitem"/> 
  <input type="button" name="cancela" value="Cancelar" onclick="window.location.href='../painelr.php'"/>
 </div>
 </fieldset>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = mysqli_fetch_assoc($dados));
	// fim do if 
	}
?>
<?php
// tira o resultado da busca da memória
mysqli_free_result($dados);
?>
</form>
</div>
</div>
 <?php include "footer.php"; ?> <body> 
</html>
