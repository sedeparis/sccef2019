<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como:  '.$logado;
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema Administrativo compras públicas.</title>
	 <link href="../../css/print_tab.css" rel="stylesheet" />
	  <link href="../../css/print_div.css" rel="stylesheet" />
	   <link href="../../css/print_fontes.css" rel="stylesheet" />
   
	    
		<!--- scripts de validação de formulário --->
 </head>
	 <body> 
	 <div class="cabecalho">
	  <?php include "cabecalho.php"; ?> 
	  </div>
	 <div class="titulo">
	 <h3>Quadro comparativo:</h3>
	  </div>
 <?php
 //carrega dados do formulario do cdfolhaempenho
$processo=$_POST['processo'];
$pesquisa=$_POST['pesquisa'];
$h= " - ";
// cria a instrução SQL que vai selecionar os dados
$query = sprintf("SELECT * FROM cadcompras WHERE idcompra ='$processo'");
// executa a query
$dadosii = mysqli_query($mysqli, $query) ;
// transforma os dados em um array
$linhaii = mysqli_fetch_assoc($dadosii);
// calcula quantos dados retornaram
$totalii = mysqli_num_rows($dadosii);
?>
<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($totalii > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
$finalidade = $linhaii['finalidade'];
$numcompra =  $linhaii['numcompra'];
$tipo =  $linhaii['tipo'];
$gerencia =  $linhaii['gerencia'];
		?>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = mysqli_fetch_assoc($dadosii));
	// fim do if 
	}
?>
<div class="textos">
<span class="subtitulo">
Processo:
</span>
<span class="rsubtitulo">
<?php echo $preprocesso."."."$processo"?>
</span>
<br>
<span class="subtitulo">
Finalidade:
</span>
<span class="rsubtitulo">
<?php echo "$finalidade" ?>
</span>
</div>
<?php
// tira o resultado da busca da memória
mysqli_free_result($dadosii);
?>

<?php
// cria a instrução SQL que vai selecionar os dados dos itens
$queryb = ("SELECT * FROM produto WHERE idprocesso ='$processo' AND IP='S'");
// executa a query
$dados = mysqli_query ($mysqli, $queryb);
// transforma os dados em um array
$linha = mysqli_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysqli_num_rows($dados);
?>
<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($total == 0) {echo "";}
	if($total > 0) { 
		// inicia o loop que vai mostrar todos os dados
		do {

$nitem= $linha['nitem'];
$ditem= $linha['descricao'];
$qtd= $linha['estoque_maximo'];
$A= $linha['p1'];
$B= $linha['p2'];
$C= $linha['p3'];
$data= $linha['dp1'];
$datb= $linha['dp2'];
$datc= $linha['dp3'];
$fonta= $linha['fcp1'];
$fontb= $linha['fcp2'];
$fontc= $linha['fcp3'];
$noma= $linha['fnp1'];
$nomb= $linha['fnp2'];
$nomc= $linha['fnp3'];

$x= $linha['pe1'];
$y= $linha['pe2'];
$z= $linha['pe3'];
//condiciona a desprezar valor zerados
$cont = 0;
if ($A != 0.00){ // ou NULL
$cont = $cont + 1;
}
if ($B != 0.00){ // ou NULL
$cont = $cont + 1;
}
if ($C != 0.00){ // ou NULL
$cont = $cont + 1;
}
$media = ($A+$B+$C)/$cont; 

//cria busca valor minimo
$m1 = $A;
$m2 = $B;
$m3 = $C;
$values = array($m1, $m2, $m3);
$values = array_filter($values, create_function('$v', 'return $v > 0.00;'));
$min = min($values);
//print_r($min);

//encontrar total pelo valor medio e minimo
$vlrmd = ($qtd*$media);
$vlrmn = ($qtd*$min);
?>
<div class="tabela">
<table>
<thead>
<tr>
<th>Itm</th>
<th>Descrição</th>
<th>Qtd</th>
<th>Valor A</th>
<th>Valor B</th>
<th>Valor C</th>
</tr>
</thead>
<tbody>
<tr>
<td><?php echo "$nitem"?></td>
<td><?php echo "$ditem"?></td>
<td><?php echo "$qtd"?></td>
<td><?php echo number_format($A,2, ",","");?></td>
<td><?php echo number_format($B,2, ",","");?></td>
<td><?php echo number_format($C,2, ",","");?></td>
</tr>
</tbody>
</table>
<table>
<colgroup>
<col width="20%">
<col width="30%">
<col width="20%">
<col width="30%">
</colgroup>
<thead>
<tr>
<th>Val médio</th>
<th>Total Val médio</th>
<th>Val mínimo</th>
<th>Total Val Mínimo</th>
</tr>
</thead>
<tbody>
<tr>
<td><?php echo number_format($media,2, ",","");?></td>
<td><?php echo number_format($vlrmd,2, ",","");?></td>
<td><?php echo number_format($min,2, ",","");?></td>
<td><?php echo number_format($vlrmn,2, ",","");?></td>
</tr>
</tbody>
</table>
<table>
<thead>
<tr>
<th>Fonte A</th>
<th>Fonte B</th>
<th>Fonte C</th>
</tr>
</thead>
<tbody>
<tr>
<td>
<span class="subt">CNPJ/Uasg/Site: </span><?php echo "$fonta"?><br>
<span class="subt">Nome: </span><?php echo "$noma"?><br>
<span class="subt">Nº pregão/cotação: </span> <?php echo "$x"?><br>
<span class="subt">Data orçam./ata: </span> <?php echo "$data"?><br>
</td>
<td>
<span class="subt">CNPJ/Uasg/Site: </span> <?php echo "$fontb"?><br>
<span class="subt">Nome: </span><?php echo "$nomb"?><br>
<span class="subt">Nº pregão/cotação: </span> <?php echo "$y"?><br>
<span class="subt">Data orçam./ata: </span> <?php echo "$datb"?><br>
</td>
<td>
<span class="subt">CNPJ/Uasg/Site: </span><?php echo "$fontc"?><br>
<span class="subt">Nome: </span><?php echo "$nomc"?><br>
<span class="subt">Nº pregão/cotação: </span> <?php echo "$z"?><br>
<span class="subt">Data orçam./ata: </span><?php echo "$datc"?><br></td>
</tr>
</tbody>
</table>
</div>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = mysqli_fetch_assoc($dados));
	// fim do if 
	}
?>
<?php
// tira o resultado da busca da memória
mysqli_free_result($dados);
?>
<div class="textos">
<br />
<br />
<br />
<br />
<p class="center">__________________________<br><?php echo "$pesquisa" ?><br />Responsável pela pesquisa<br />
<br />
<br />
<br />
</div>
<div class="button">
<input type="button" name="cancela" value="Voltar" onclick="window.location.href='../painelr.php'"/>
</div>
</body> 
</html>


