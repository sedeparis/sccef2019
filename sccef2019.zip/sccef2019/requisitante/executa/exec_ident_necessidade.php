 <?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como:  '.$logado;
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema Administrativo compras públicas.</title>
	 <link href="../../css/print_tab.css" rel="stylesheet" />
	  <link href="../../css/print_div.css" rel="stylesheet" />
	   <link href="../../css/print_fontes.css" rel="stylesheet" />
   
	    <script>
function funcao1()
{
alert("Antes de imprimir Configure a página. Na aba Geral, Orientação Retrato, Escala 100%.");
}
</script>
		<!--- scripts de validação de formulário --->
 </head>
	 <body> 
	 <div class="cabecalho">
	  <?php include "cabecalho.php"; ?> 
	  </div>
	 <div class="titulo">
	<h3>IDENTIFICAÇÃO DA NECESSIDADE DE COMPRA</h3>
		  </div>
	 <?php
 //cria a instrução SQL que vai selecionar os dados para o cabeçalho
$sqla = mysqli_query($mysqli, "SELECT * FROM cdorgao WHERE orgao_principal ='S'");
 $counta = mysqli_num_rows ($sqla);
if ($counta == 0) 
{ echo "Nenhum resultado!" ;}
while ($dadosa = mysqli_fetch_array($sqla))
{ echo "";
 
$endereco=$dadosa['endereco'];
 $orgao=$dadosa['nome'];
 $dirad=$dadosa['gestor'];
 $dirge=$dadosa['diretor'];
$local= $dadosa['cidade'];
 $uf=$dadosa['uf'];
 $fonte=$dadosa['fonte'];
 $preprocesso=$dadosa['iniprocesso'];
 }
?>

</div>
 <?php
 //carrega dados do formulario do cdfolhaempenho
$processo=$_POST['processo'];
 //cria a instrução SQL que vai selecionar os dados para o cabeçalho
$sql = mysqli_query($mysqli, "SELECT * FROM produto WHERE idprocesso ='$processo'");
 $count = mysqli_num_rows($sql);
if ($count == 0) 
{ echo "Nenhum resultado!" ;}
while ($dados = mysqli_fetch_array($sql))
{ echo "";
 }
?>

<?php
// cria a instrução SQL que vai selecionar os dados do processo e fornecedor
$query = sprintf("SELECT * FROM cadcompras WHERE idcompra ='$processo'");
// executa a query
$dadosii = mysqli_query($mysqli, $query);
// transforma os dados em um array
$linhaii = mysqli_fetch_assoc($dadosii);
// calcula quantos dados retornaram
$totalii = mysqli_num_rows($dadosii);
?>

<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($totalii > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
		$finalidade = $linhaii['finalidade'];
	$tipo = $linhaii['tipo'];
	$numcompra = $linhaii['numcompra'];
	$process = $linhaii['processo'];
	$requesita = $linhaii['nomereq'];
		?>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linhaii = mysqli_fetch_assoc($dadosii));
	// fim do if 
	}
?>
<div class="textos">
<span class="subtitulo">
Processo:
</span>
<span class="rsubtitulo">
<?php echo "$process"?>
</span>
<br>
<span class="subtitulo">
Finalidade:
</span>
<span class="rsubtitulo">
<?php echo "$finalidade" ?>
</span>
</div>
<div class="tabela">
<table>
<colgroup>
<col width="05%">
<col width="45%">
<col width="10%">
<col width="08%">
<col width="08%">
<col width="10%">
<col width="14%">
</colgroup>
<thead>
<tr>
<th>Item</th>
<th>Descrição</th>
<th>Un</th>
<th>Qtd min</th>
<th>Qtd max</th>
<th>R$/un</th>
<th>R$/total</th>
</tr>
</thead>
</table>

<?php
// tira o resultado da busca da memória
mysqli_free_result($dadosii);
?>
<?php
// cria a instrução SQL que vai selecionar os dos itens
$queryb = ("SELECT * FROM produto WHERE idprocesso ='$processo' AND (finalizado = 0)");
// executa a query
$dados = mysqli_query ($mysqli, $queryb);
// transforma os dados em um array
$linha = mysqli_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysqli_num_rows($dados);
?>


<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($total > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
$valor =$linha['p1'];
$nitem = $linha['nitem'];
$ditem= $linha['descricao'];
$quanto= $linha['estoque_minimo'];
$quantmax= $linha['estoque_maximo'];
$un= $linha['un'];
$valori =($valor*$quantmax);
 ?>
<table>
<colgroup>
<col width="05%">
<col width="45%">
<col width="10%">
<col width="8%">
<col width="8%">
<col width="10%">
<col width="14%">
</colgroup>
<tbody>
<tr>
<td><?php echo $nitem ?></td>
<td><?php echo $ditem ?></td>
<td><?php echo $un ?></td>
<td><?php echo $quanto ?></td>
<td><?php echo $quantmax ?></td>
<td><?php echo number_format($valor,2, ",",".");?></td>
<td><?php echo number_format($valori,2, ",",".");?></td>
</tr>
</tbody>
</table>

<?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = mysqli_fetch_assoc($dados));
	// fim do if 
	}
?>
<?php
// cria a instrução SQL que vai selecionar os dados da soma total preço estimado 1
$result = mysqli_query($mysqli, "SELECT SUM(tot_estimado) AS valor_soma FROM produto WHERE idprocesso ='$processo' AND (finalizado = 0)");
 //executa a query
$row = mysqli_fetch_assoc($result);
$sum = $row['valor_soma'];
?>
<table>
<tr>
<td width="60%"><P class="total">Total estimado:</p>
</td>
<td width="40%"><P class="total"><?php echo number_format($sum,2, ",",".");?>
</p>
</td>
</tr>
</table>

</div>

<?php
// cria a instrução SQL que vai selecionar os dados do processo e fornecedor
$queryc = sprintf("SELECT * FROM cdrequisitante WHERE idr ='$requesita'");
// executa a query
$dadosc = mysqli_query ($mysqli, $queryc);
// transforma os dados em um array
$linhac = mysqli_fetch_assoc($dadosc);
// calcula quantos dados retornaram
$totalc = mysqli_num_rows($dadosc);

	// se o número de resultados for maior que zero, mostra os dados//
	if($totalii > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
			$nomesolic = $linhac['nome'];
	$siape = $linhac['siape'];
	
	
		// finaliza o loop que vai mostrar os dados
		}while($linhac = mysqli_fetch_assoc($dadosc));
	// fim do if 
	}
	?>

<div class="titulo">
<br>
<h4>REQUISITANTE:</h4>
</div>
<div class="textos">
<p class="direita"><?php echo "$local-$uf" ?> em </b> ___/____/ 20___</p>
<br />
<p class="center">___________________________<br />
<?php echo "$nomesolic"?><br />
 <b>Requisitante </b><br />
 <?php echo "Siape: ". "$siape" ?>
 </p>
</div>
<div class="titulo">
<h4>CHEFIA IMEDIATA</h4>
</div>
<div class="textos">
<p class="var">(  ) Autorizo o prosseguimento da compra, realização de pesquisa de preços e encaminhamento ao ordenador de despesas para seu parecer.</p>
<p class="var">(  ) Não autorizo a abertura do processo, conforme motivação anexa. Encaminhe-se ao setor requisitante para ciência e arquivamento. </p>
<br />
<p class="direita"><?php echo "$local-$uf" ?> em </b> ___/____/ 20___
</p>
<br />
<br />
<p class="center">_______________________________________
<br />
Chefia Imediata<br />
Siape _______<br />
<br />
</p>
</div>
<br />
<div class="button">
<input type="button" name="cancela" value="Voltar" onclick="window.location.href='../painelr.php'"/>
<input type="button" name="imprime" value="Dicas de impressão"  onclick="funcao1()" value="Exibir Alert"/>
</div>
<?php
// tira o resultado da busca da memória
mysqli_free_result($dadosc);
?>
</body> 
</html>