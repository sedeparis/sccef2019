<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 <link rel="stylesheet" type="text/css" href="css/menu.css" media="screen"/>
<body>
<br />
<br />
<nav>
<ul class="menu">
<li><a href="painel.php"><p class="menug"><b>Home</b></p></a>
 <li><a href="#"><p class="menug"><b>Processos</b></p></a>
 <ul>
<li><a href="cd_processo.php"><p class="menu">Incluir</p></a></li>
<li><a href="altera_processo.php"><p class="menu">Alterar </p></a></li>
<li><a href="altera_volume_processo.php"><p class="menu">Volumes</p></a></li>
<li><a href="inativa_processo.php"><p class="menu">Inativar</p></a></li>
<li><a href="movimenta_processo.php"><p class="menu">Saída</p></a></li>
<li><a href="retorno_processo.php"><p class="menu">Retorno</p></a></li>
<li><a href="busca_local_processo.php"><p class="menu">Localizar</p></a></li>
<li><a href="gera_targeta_processo.php"><p class="menu">Gerar Targeta</p></a></li>
<li><a href="altera_idade_processo.php"><p class="menu">Alterar idade</p></a></li>
<li><a href="#"><p class="menug">Filtros por</p></a>
 <ul>
  <li><a href="filtro_processos.php"><p class="menul">Nº processo</p></a></li>
 <li><a href="filtro_processo_finalidade.php"><p class="menul">finalidade</p></a></li>
 <li><a href="filtro_processo_gerenciador.php"><p class="menul">Gerenciador</p></a></li>
 <li><a href="filtro_processo_num_compra.php"><p class="menul">Nº compra</p></a></li>
 <li><a href="filtro_processo_situacao.php"><p class="menul">Situação</p></a></li>
</ul>
</ul>
 <li><a href="#"><p class="menug"><b>Compras</b></p></a>
 <ul>
 <li><a href="cd_fornecedor.php"><p class="menu">Incluir Fornecedor</p></a></li>
<li><a href="altera_fornecedor.php"><p class="menu">Alterar Fornecedor</p></a></li>
<li><a href="cd_item.php"><p class="menu">Incluir item</p></a></li>
<li><a href="altera_item.php"><p class="menu">Altera item</p></a></li>
<li><a href="altera_fornecedor_item.php"><p class="menu">Altera forn_item</p></a></li>
<li><a href="requerimento_empenho.php"><p class="menu">Consulta Requis. empenho</p></a></li>
<li><a href="cd_empenha.php"><p class="menu">Define itens_qtd. empenhos</p></a></li>
<li><a href="imprime_empenho.php"><p class="menu">Imprimir Solic. Empenho</p></a></li>
<li><a href="confirma_empenho.php"><p class="menu">Confirma item_qtd Empenho </p></a></li>
<li><a href="lista_val_compras.php"><p class="menul">Filtra Val. Compras</p></a></li>
<li><a href="lista_empenho_final.php"><p class="menul"> Lista Compras Emp. Total </p></a></li>
<li><a href="lista_empenho_parcial.php"><p class="menul">Lista Compras Emp. Parcial </p></a></li>
<li><a href="lista_sem_empenho.php"><p class="menul">Lista Compras Sem Empenho</p></a></li>
</li>
</ul>
 <li><a href="#"><p class="menug"><b>Almoxarifado</b></p></a>
 <ul>
 <li><a href="solicita_pedido.php"><p class="menu">Solicitar itens</p></a></li>
<li><a href="recebe_item.php"><p class="menu">Receber itens</p></a></li>
<li><a href="lista_pedido_final.php"><p class="menul">Lista Pedidos Concluidos</p></a></li>
<li><a href="lista_pedido_pendente.php"><p class="menul">Lista Pedidos pendentes</p></a></li>
<li><a href="lista_pedido_areceber.php"><p class="menul">Lista Pedidos a receber </p></a></li>
 </li>
</ul>
<li><a href="#"><p class="menug"><b>Admin</b></p></a>
<ul>
<li><a href="cd_orgao.php"><p class="menu">
Orgão</p></a></li>
<li><a href="altera_orgao.php"><p class="menu">
Altera Órgão</p></a></li>
<li><a href="cd_setor.php"><p class="menu">
Setores</p></a></li>
<li><a href="cd_tipo.php"><p class="menu">
Tipos de Processos</p></a></li>
<li><a href="cd_usuario.php"><p class="menu">
Usuários</p></a></li>
</ul>
<li><a href="logout.php"><p class="menuoff">
Sair</p></a></li>
</ul>
</nav>
</body>
</html>