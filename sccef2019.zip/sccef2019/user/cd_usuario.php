<?php

include ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<title>Cadastro de usuários
</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<!-- BOOTSTRAP STYLES-->
    <link href="../css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../css/custom.css" rel="stylesheet" />

</head>
 <body> <div class="container"><?php include "topo.php"; 

 ?> 
 </div>
	 
	 <div class="container">
	 <h1>Cadastro de usuário</h1>
<form name="caduser" method="POST" action="salva_usuario.php">

	<fieldset class="grupo">
		<!---seleciona usuario-->
		  <div class="form-group">
	<?php	
	$query = mysqli_query($mysqli, "SELECT * FROM cdservidor");
?>
 <label class="form-control" for="">Selecione usuario</label>
 <select class="form-control" name="nome">
 <option class="form-control" name="">Selecione...</option>
 <?php while($uas = mysqli_fetch_array($query)) { ?>
 <option class="form-control"   value="<?php echo $uas['nome'] ?>"><?php echo $uas['nome'] ?></option>
 <?php } ?>
 </select>
 </div>
  <div class="form-group">
<label class="form-control">Crie um nome de usuario ou Email</label> 
<input class="form-control" type="text" size="25" name="email" />
 </div>
  <div class="form-group">
<label class="form-control">Crie uma Senha:</label> 
<input class="form-control"  type="password" size="10" name="senha" />
 </div>
 </fieldset>
 <fieldset class="grupo">
  <div class="form-group">
<input class="form-control-2"  type="submit" value="Cadastrar" />
<input class="form-control-2"  type="reset" value="Limpar" />

 <input class="form-control-2"  type="button" name="cancela" value="Cancelar" onclick="window.location.href='../index.php'"/>
 </div>
 </fieldset>
</form>
</div>

<?php include "footer.php" ?> 
</body>
</html>