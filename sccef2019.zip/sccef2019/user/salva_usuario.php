
<html lang="pt-BR">
<head>
<title>Cadastro de usuários
</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<!-- BOOTSTRAP STYLES-->
    <link href="../css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../css/custom.css" rel="stylesheet" />
</head>
 <body>
 <div class="container">
 <?php include "topo.php"; ?> 
 </div>
<div class="container">
<?php
include "../conecta_banco.php";
$nome=$_POST['nome'];
$email=$_POST['email'];
$senha=$_POST['senha'];

//verfica se não há cadastro igual
 $dupesq = "SELECT * FROM users WHERE email = '$email' OR nome= '$nome'";
$duperaw = mysqli_query($mysqli, $dupesq);

if (mysqli_num_rows($duperaw) > 0) {
   echo "Encontramos um usuario já cadastrado com esse nome ou user. <a href='cd_usuario.php'>Voltar</a>";
} else {

$sql = mysqli_query($mysqli, "INSERT INTO users(nome, admin,  email, senha, situacao)
VALUES('$nome', 1, '$email', MD5('$senha'), 0)");
echo "Cadastro efetuado com sucesso! 
Aguarde o adminstrador aprovar sua conta.";
}
?>
<img >
 <br>
 <br>
 <input class="form-control-2"  type="button" name="cancela" value="Voltar" onclick="window.location.href='../index.php'"/>

</div>
<?php include "footer.php" ?> 
</body>
</html>