﻿<?php
$servidor = 'localhost';
$user = 'root';
$password = '';
$banco = 'sccef';
// Conecta-se ao banco de dados MySQL
$mysqli = new mysqli($servidor, $user, $password, $banco);
// Caso algo tenha dado errado, exibe uma mensagem de erro
if (mysqli_connect_error()) trigger_error(mysqli_connect_error());
mysqli_set_charset( $mysqli, 'utf8');
?>