<?php
session_start();
	$_SESSION['email'];
	$_SESSION['senha'];
	header ("painel.php");
	$logado=$_SESSION['email'];
include ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Cadastro de fornecedor</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	 <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/estiloform.css" type="text/css"/>
	 <script language="JavaScript" type="text/javascript" src="../js/MascaraValidacao.js"></script> 
	   <script type="text/javascript">
	   function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
 
 function validacao() {
if(document.form.nome.value=="")
{
alert("Por favor digite o nome do fornecedor.");
document.form.nome.focus();
return false;
}


if(document.form.cnpj.value=="")
{
alert("Por favor insira o cnpj.");
document.form.cnpj.focus();
return false;
}


if(document.form.cod_cidades.value=="-- Escolha um estado --")
{
alert("Por favor insira a cidade.");
document.form.cod_cidades.focus();
return false;
}


if(document.form.banco.value=="Selecione...")
{
alert("Por favor insira o banco.");
document.form.banco.focus();
return false;
}

if(document.form.agencia.value=="")
{
alert("Por favor insira a agencia.");
document.form.agencia.focus();
return false;
}

if(document.form.conta.value=="")
{
alert("Por favor insira a conta.");
document.form.conta.focus();
return false;
}
}
function FormataCnpj(campo, teclapres)
			{
				var tecla = teclapres.keyCode;
				var vr = new String(campo.value);
				vr = vr.replace(".", "");
				vr = vr.replace("/", "");
				vr = vr.replace("-", "");
				tam = vr.length + 1;
				if (tecla != 14)
				{
					if (tam == 3)
						campo.value = vr.substr(0, 2) + '.';
					if (tam == 6)
						campo.value = vr.substr(0, 2) + '.' + vr.substr(2, 5) + '.';
					if (tam == 10)
						campo.value = vr.substr(0, 2) + '.' + vr.substr(2, 3) + '.' + vr.substr(6, 3) + '/';
					if (tam == 15)
						campo.value = vr.substr(0, 2) + '.' + vr.substr(2, 3) + '.' + vr.substr(6, 3) + '/' + vr.substr(9, 4) + '-' + vr.substr(13, 2);
				}
			}



function validarCNPJ(cnpj) {
 
    cnpj = cnpj.replace(/[^\d]+/g,'');
 
    if(cnpj == '') return false;
     
    if (cnpj.length != 14)
        return false;
 
    // Elimina CNPJs invalidos conhecidos
    if (cnpj == "00000000000000" || 
        cnpj == "11111111111111" || 
        cnpj == "22222222222222" || 
        cnpj == "33333333333333" || 
        cnpj == "44444444444444" || 
        cnpj == "55555555555555" || 
        cnpj == "66666666666666" || 
        cnpj == "77777777777777" || 
        cnpj == "88888888888888" || 
        cnpj == "99999999999999")
        return false;
         
    // Valida DVs
    tamanho = cnpj.length - 2
    numeros = cnpj.substring(0,tamanho);
    digitos = cnpj.substring(tamanho);
    soma = 0;
    pos = tamanho - 7;
    for (i = tamanho; i >= 1; i--) {
      soma += numeros.charAt(tamanho - i) * pos--;
      if (pos < 2)
            pos = 9;
    }
    resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
    if (resultado != digitos.charAt(0))
        return false;
         
    tamanho = tamanho + 1;
    numeros = cnpj.substring(0,tamanho);
    soma = 0;
    pos = tamanho - 7;
    for (i = tamanho; i >= 1; i--) {
      soma += numeros.charAt(tamanho - i) * pos--;
      if (pos < 2)
            pos = 9;
    }
    resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
    if (resultado != digitos.charAt(1))
          return false;
           
    return true;
    
}
 </script>
   </head>
	 <body> <div class="container"><?php include "topo.php"; echo 'Usuário Logado: '; echo $logado; ?> </div>
	 
    
	 <div class="container">
	<h2 class="form-nome">Cadastro de Fornecedor</h2>
	 <?php
	 
	 ?>
	<form name="form" method="post" action="salva/salva_fornecedor.php" onSubmit="return validacao();">
	<fieldset class="grupo">
	 <div class="form-group">
	 		<label class="form-control">Cnpj: <span class="obrig">*</span></label>
	<input class="form-control" type="text" name="cnpj" id="cnpj" onkeyup="FormataCnpj(this,event)" 
	onblur="if(!validarCNPJ(this.value)){alert('CNPJ Informado é inválido');
	this.value='';}" maxlength="18"  
	class="form-control input-md" ng-model="cadastro.cnpj" required />
		</div>
		  <div class="form-group">
			<label class="form-control">Nome:<span class="obrig">*</span></label>
<input class="form-control" type="text" name="nome" size="70"/>
	</div>
	
		 <div class="form-group">
		<label class="form-control">Endereço:</label>
		<input class="form-control" type="text" name="endereco" size="60" />
				</div>
				 <div class="form-group">
		<label class="form-control">Email:</label>
		<input class="form-control" type="text" name="email" size="30" />
		</div>
		 <div class="form-group">
		<label class="form-control">Telefone:</label>
		<input class="form-control" type="text" name="fone" size="10" maxlength="12"  onkeypress="mascara(this, '##-####-####')" />
		</div>
			</fieldset>
			<fieldset class="grupo">
				 <div class="form-group">
		<label class="form-control"   for="cod_estados">Estado:</label>
		<select class="form-control" name="cod_estados" id="cod_estados">
			<option class="form-control"   value="Selecione..."></option>
			<?php
				$sql = ("SELECT cod_estados, sigla
						FROM estados
						ORDER BY sigla");
				$res = mysqli_query($mysqli, $sql);
				while ( $row = mysqli_fetch_assoc( $res ) ) {
					echo '<option class="form-control"   value="'.$row['cod_estados'].'">'.$row['sigla'].'</option>';
				}
			?>
		</select>
</div>
		 <div class="form-group">
		<label class="form-control"   for="cod_cidades">Cidade:</label>
		
		<select class="form-control" name="cod_cidades" id="cod_cidades">
			<option class="form-control"   value="">-- Escolha um estado --</option>
		</select>

		<!--script src="http://www.google.com/jsapi"></script-->
		 <script type="text/javascript" src="../js/jsapi.js"></script>
		<script type="text/javascript">
		  google.load('jquery', '1.3');
		  
		</script>		
 <script language="JavaScript" type="text/javascript" src="../js/jquery.js"></script> 
		<script type="text/javascript">
		$(function(){
			$('#cod_estados').change(function(){
				if( $(this).val() ) {
					$('#cod_cidades').hide();
					$('.carregando').show();
					$.getJSON('cidades.ajax.php?search=',{cod_estados: $(this).val(), ajax: 'true'}, function(j){
						var options = '<option class="form-control"   value=""></option>';	
						for (var i = 0; i < j.length; i++) {
							options += '<option class="form-control"   value="' + j[i].cod_cidades + '">' + j[i].nome + '</option>';
						}	
						$('#cod_cidades').html(options).show();
						$('.carregando').hide();
					});
				} else {
					$('#cod_cidades').html('<option class="form-control"   value="">– Escolha um estado –</option>');
				}
			});
		});
		</script>
 </div>
 </fieldset>
 <fieldset class="grupo">
		<p>Os dados bancários são necessários para empenhos.<br> Caso não os tenha, digite zeros e arrume futuramente em alterar fornecedor.</p><br />
	</fieldset>
	<fieldset class="grupo">
	 <div class="form-group">
 <?php	$query = mysqli_query($mysqli, "SELECT * FROM cdbanco");
?>
 <label class="form-control" for="">Selecione o Banco:</label>
 <select class="form-control" name="banco">
 <option class="form-control" name="">Selecione...</option>
 <?php while($banco = mysqli_fetch_array($query)) { 
 ?>
 <option class="form-control"   value="<?php echo $banco['idbanco'] ?>"><?php echo $banco['codigo'].' - '.$banco['banco'] ?></option>
 <?php } ?>
 </select>
 </div>
	 <div class="form-group">
		 <label class="form-control">Agencia: <span class="obrig">*</span></label>
		<input class="form-control" type="text" name="agencia" size="10" />
		</div>
	 <div class="form-group">
		 <label class="form-control">Conta: <span class="obrig">*</span></label>
		<input class="form-control" type="text" name="conta" size="10" />
		</div>
		<div class="form-group">
		 <label class="form-control">Operador: <span class="obrig"></span></label>
		<input class="form-control" type="text" name="operador" size="3" maxlength="3"/>
		</div>
		</fieldset>
	 <div class="form-group">
<input class="form-control-2"  type="submit" name="enviar" value="Cadastrar"/>
<input class="form-control-2"  type="reset" name="limpar" value="Limpar"/>
 <input class="form-control-2"  type="button" name="cancela" value="Cancelar" onclick="window.location.href='painel.php'"/>
</div>
</form>
 </div>
 <?php include "footer.php" ?> 
 </body>
 </html>
