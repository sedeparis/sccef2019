<?php
session_start();
	$_SESSION['email'];
	$_SESSION['senha'];
	header ("painel.php");
	$logado=$_SESSION['email'];
include ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Cadastro de ED</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	 	 <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/estiloform.css" type="text/css"/>
	 <script type="text/javascript">
	 function validacao() {
 if(document.form.tipo.value=="Selecione...")
{
alert("Por favor selecione tipo de ED.");
document.form.tipo.focus();
return false;
}

if(document.form.piptres.value=="")
{
alert("Por favor insira o nome do PI ou Ptres.");
document.form.piptres.focus();
return false;
}
}
	 </script>
 </head>
	 <body> <div class="container"><?php include "topo.php"; echo 'Usuário Logado: '; echo $logado; ?> </div>
	 
	 <div class="container">
	<h2 class="form-nome">Cadastro de Elementos Pi e Ptres</h2>
	<form name="form" method="post" action="salva/salva_piptres.php"  onSubmit="return validacao();">
	<fieldset class="grupo">
		  <div class="form-group">
		 
		 <?php 
	$query = mysqli_query($mysqli, "SELECT DISTINCT tipo FROM cdptres");
?>

 <label class="form-control" for="">Selecione o tipo</label>
 <select class="form-control" name="tipo">
 <option class="form-control" name="">Selecione...</option>
 <?php 
 while($busca = mysqli_fetch_array($query)) { 
 ?>
 <option class="form-control"   value="<?php 
 echo $busca['tipo'] 
 ?>">
 <?php 
 echo $busca['tipo']
 ?></option>
 <?php } ?>
 </select>
 </div>
   <div class="form-group">
			<label class="form-control">PI ou Ptres:</label>
<input class="form-control" type="text" name="piptres" size="15" title="digite"/>
	</div>
	</fieldset>
	
	<fieldset class="grupo">
		  <div class="form-group">
	<input class="form-control-2"  type="submit" name="enviar" value="Cadastrar PI-PTRES"/>
	<input class="form-control-2"  type="submit" name="limpar" value="Limpar"/>
	<input class="form-control-2"  type="button" name="cancela" value="Cancelar" onclick="window.location.href='painel.php'"/>
	</div>
</form>
</div>
 <?php include "footer.php" ?>  </body>
 </html>