<?php
session_start();
	$_SESSION['email'];
	$_SESSION['senha'];
	header ("painel.php");
	$logado=$_SESSION['email'];
include ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Alterar Fornecedor</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	 <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/estiloform.css" type="text/css"/>
 
 </script>
 </head>
	 <body>
	 <div class="container">
	 <?php include "topo.php"; echo 'Usuário Logado: '; echo $logado; ?>
	 </div>
	 <!-------- inicia pagina-------------->
	 <div class="container">
	<h3>Alterar Fornecedor</h3>
<fieldset class="grupo">
		  <div class="form-group">
<input class="form-control-2"  type="button" name="cancela" value="Alterar dados gerais" onclick="window.location.href='altera_fornecedor.php'"/>
<input class="form-control-2"  type="button" name="cancela" value="Altera cidade fornecedor" onclick="window.location.href='altera_uf_fornecedor.php'"/>
</div>
	</fieldset>
</form>

 </div> 
 <?php include "footer.php" ?></body>
 </html>