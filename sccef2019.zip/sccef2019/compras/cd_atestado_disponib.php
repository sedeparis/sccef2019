<?php
session_start();
	$_SESSION['email'];
	$_SESSION['senha'];
	header ("painel.php");
	$logado=$_SESSION['email'];
include ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Disponibilidade orçamentária</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	 <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	  <link rel="stylesheet" href="../css/estiloform.css" type="text/css"/>
   <script type="text/javascript">
	   function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
 
 function validacao() {
 if(document.form.processo.value=="Selecione...")
{
alert("Por favor selecione o processo.");
document.form.processo.focus();
return false;
}

if(document.form.pi.value=="Selecione...")
{
alert("Por favor selecione o PI.");
document.form.pi.focus();
return false;
}

if(document.form.ptres.value=="Selecione...")
{
alert("Por favor selecione o Ptres.");
document.form.ptres.focus();
return false;
}

}
 </script>
   </head>
	 <body> <div class="container"><?php include "topo.php"; echo 'Usuário Logado: '; echo $logado; ?> </div>
	 

	 <div class="container">
	<h2 class="form-nome">Atestado de disponibilidade orçamentario</h2>
	 <br />
	
	
	<form name="form" method="post" action="executa/exec_atestado_disponib.php" onSubmit="return validacao();"> 
		<fieldset class="grupo">
		  <div class="form-group">
		<?php 
	$query = mysqli_query($mysqli, "SELECT * FROM cadcompras WHERE situacao = '1' AND (fase='1') ORDER BY idcompra DESC");
?>
 <label class="form-control" for="">Selecione uma compra</label>
 <select class="form-control" name="processo">
 <option class="form-control" name="">Selecione...</option>
 <?php while($proc = mysqli_fetch_array($query)) { ?>
 <option class="form-control"   value="<?php echo $proc['idcompra'] ?>"><?php echo $proc['processo']." - ".$proc['finalidade'] ?></option>
 <?php } ?>
 </select>
 </div>
 </fieldset>
 
<fieldset class="grupo">
		  <div class="form-group">
 <!---selecionar PI 1--->
	<?php 
	$queryb = mysqli_query($mysqli, "SELECT * FROM cdptres WHERE tipo = 'PI' AND nome <> 1");
?>
 <label class="form-control" for="">Selecione um PI da compra</label>
 <select class="form-control" name="pi">
 <option class="form-control" name="">Selecione...</option>
 <?php 
 while($busca = mysqli_fetch_array($queryb)) { 
 ?>
 <option class="form-control"   value="<?php 
 echo $busca['nome'] 
 ?>">
 <?php 
 echo $busca['nome'];?>
 </option>
 <?php } ?>
 </select>
</div>
 <div class="form-group">
 <!---selecionar PI 2--->
	<?php 
	$queryc = mysqli_query($mysqli, "SELECT * FROM cdptres WHERE tipo = 'PI' AND nome <> 1");
?>
 <label class="form-control" for="">Selecione novo PI se necessário</label>
 <select class="form-control" name="pi2">
 <option class="form-control" name="">Selecione...</option>
 <?php 
 while($busca = mysqli_fetch_array($queryc)) { 
 ?>
 <option class="form-control"   value="<?php 
 echo $busca['nome'] 
 ?>">
 <?php 
 echo $busca['nome'];?>
 </option>
 <?php } ?>
 </select>
</div>
 <div class="form-group">
 <!---selecionar PTRES --->
	<?php 
	$queryd = mysqli_query($mysqli, "SELECT * FROM cdptres WHERE tipo = 'PTRES' AND nome <> 2");
?>
 <label class="form-control" for="">Selecione o PTRES da compra</label>
 <select class="form-control" name="ptres">
 <option class="form-control" name="">Selecione...</option>
 <?php 
 while($busca = mysqli_fetch_array($queryd)) { 
 ?>
 <option class="form-control"   value="<?php 
 echo $busca['nome'] 
 ?>">
 <?php 
 echo $busca['nome'];?>
 </option>
 <?php } ?>
 </select>
</div>
</fieldset>

		 <fieldset class="grupo">
		 <div class="form-group">
		<br>
	<input class="form-control-2"  type="submit" value="Selecionar compras"/>
	 <input class="form-control-2"  type="reset" value="Limpar"/>
	  <input class="form-control-2"  type="button" name="cancela" value="Cancelar" onclick="window.location.href='painel.php'"/>
	 </div>
	  </fieldset>
</form>
</div>
 <?php include "footer.php" ?> 
 </body>
 </html>