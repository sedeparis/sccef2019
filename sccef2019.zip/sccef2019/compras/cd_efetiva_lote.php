<?php
session_start();
	$_SESSION['email'];
	$_SESSION['senha'];
	header ("painel.php");
	$logado=$_SESSION['email'];
include ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Informar Vendedor Lote</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	 <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	  <link rel="stylesheet" href="../css/estiloform.css" type="text/css"/>
   <script type="text/javascript">
	   function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
 
 
 </script>
   </head>
	 <body> <div class="container"><?php include "topo.php"; echo 'Usuário Logado: '; echo $logado; ?> </div>
	 

	 <div class="container">
	<h2 class="form-nome">Informar Fornecedor em lote</h2>
	 <br />
	<p>Use essa ferramenta para empenhar informar o valor e vencedor dos itens de uma compra.</p>
	
	<form name="form" method="post" action="executa/exec_efetiva_lote.php" onSubmit="return validacao();"> 
		<fieldset class="grupo">
		  <div class="form-group">
		<?php 
	$query = mysqli_query($mysqli, "SELECT * FROM cadcompras WHERE situacao = '1' AND (fase='1') ORDER BY idcompra DESC");
?>
 <label class="form-control" for="">Selecione uma compra</label>
 <select class="form-control" name="processo">
 <option class="form-control" name="">Selecione...</option>
 <?php while($proc = mysqli_fetch_array($query)) { ?>
 <option class="form-control"   value="<?php echo $proc['idcompra'] ?>"><?php echo $proc['processo']." - ".$proc['finalidade'] ?></option>
 <?php } ?>
 </select>
 </div>
 </fieldset>
	 <fieldset class="grupo">
		
  <div class="form-group">
		 <?php	   
  $queryb = mysqli_query($mysqli, "SELECT * FROM cadfornecedor ORDER BY idforn DESC");
?>
 <label class="form-control" for="">Selecione o fornecedor:</label>		     
 <select class="form-control" name="fornecedor">
 <option class="form-control" name="">Selecione...</option>
 <?php while($setor = mysqli_fetch_array($queryb)) { ?>
 <option class="form-control"   value="<?php echo $setor['idforn'] ?>"><?php echo $setor['nome'] ?></option>
 <?php } ?>
 </select>
 </div>
		  </fieldset>
		 <fieldset class="grupo">
		 <div class="form-group">
	<input class="form-control-2"  type="submit" value="Selecionar compras"/>
	 <input class="form-control-2"  type="reset" value="Limpar"/>
	  <input class="form-control-2"  type="button" name="cancela" value="Cancelar" onclick="window.location.href='painel.php'"/>
	 </div>
	  </fieldset>
</form>
</div>
<?php include "footer.php" ?> 
</body>
 </html>