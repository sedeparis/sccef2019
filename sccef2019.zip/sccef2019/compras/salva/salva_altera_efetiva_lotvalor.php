<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
echo 'Acessado como:  '. $logado;
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Salva valor de compra</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	 <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../../css/bootstrap.css"" type="text/css"/>
   </head>
	 <body>
	 
	<div class="container">
	<br>
<p class="center"><img src="../../img/salva.gif"/></p>
<p class="center"><img src="../../img/moldura.gif"/></p>
<br>
<?php
if ( isset($_POST["submit"]))	{
echo '<pre>';
		print_r($_POST);
		echo '</pre>';
		foreach($_POST["id"] AS $id){
			echo 'id is '. $id . '<br />';
			//echo 'estoque_maximo ' . $_POST["estoque_maximo"][$id]."<br />";
			echo 'valor is ' . $_POST["valor"][$id]."<br />";
					
					
				//$estoque_maximo = mysqli_real_escape_string($mysqli, $_POST["estoque_maximo"][$id]);
			   $valor = mysqli_real_escape_string($mysqli, $_POST["valor"][$id]);
			   $valora = str_replace(',','.',str_replace('.','',$valor));
	
	$update = "UPDATE produto SET valor_unitario = '$valora' WHERE
	id =$id;";
	mysqli_query($mysqli, $update)or die (mysqli_error($mysqli));
echo 'Tabela produtos atualizada!<br />';
	}
	
	}
	?>
	<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='3;URL=../painel.php'>";
?>
		 </div>
		<?php include "footer.php" ?>
	</body>
	</html>
	