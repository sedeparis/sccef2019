<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como:  '. $logado;
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<title>Salvar</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <link rel="stylesheet" type="text/css" href="../../css/reset.css"/>
  <link rel="stylesheet" type="text/css" href="../../css/bootstrap.css" media="screen"/>
   <link rel="stylesheet" type="text/css" href="../../css/custom.css" media="screen"/>
</head>
<body>
<div class="container">
<?php
$idt=$_POST['tipo'];
$a=$_POST['txta'];
$b=$_POST['txtb'];
$c=$_POST['txtc'];
$d=$_POST['txtd'];
$e=$_POST['txte'];
$f=$_POST['txtf'];
$g=$_POST['txtg'];
$h=$_POST['txth'];
$i=$_POST['txti'];
$j=$_POST['txtj'];

$sql = mysqli_query($mysqli, "UPDATE cadtipo SET texta ='$a', textb ='$b', textc ='$c', textd ='$d', texte ='$e', textf ='$f', textg ='$g',  texth ='$h',  texti ='$i',  textj ='$j' WHERE idtipo ='$idt'");
$resultado = mysqli_query ($mysqli, $sql);
{echo "Alteração efetuada com sucesso!";}
?>
<br>
<br>
<p class="center"><img src="../../img/salva.gif"/></p>
<br>
<br>
<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='3;URL=../painel.php'>";
?>
</div>
</body>
</html>