<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como:  '. $logado;
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Grupos</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	 <link rel="stylesheet" href="../../css/reset.css" type="text/css"/>
	 <link href="../../css/bootstrap.css" rel="stylesheet" />
	  <link href="../../css/custom.css" rel="stylesheet" />
   </head>
	 <body>
	 <div class="container"> <?php include "topo.php"; ?>
	 <p class="center"><img src="../../img/salva.gif"/></p>
	 <p class="center"><img src="../../img/moldura.gif"/></p>
	
	 
<?php
if ( isset($_POST["submit"]))	{
echo '<pre>';
		print_r($_POST);
		echo '</pre>';
		foreach($_POST["id"] AS $id){
			echo 'id is '. $id . '<br />';
			echo 'grupo is ' . $_POST["grupo"][$id]."<br />";
			echo 'radio is ' . $_POST["radio"][$id]."<br />";
			
						 	 
			
			   $grupo = mysqli_real_escape_string($mysqli, $_POST["grupo"][$id]);
			 $radio = mysqli_real_escape_string($mysqli, $_POST["radio"][$id]);
			 
			
			if ($radio <> 1) {
   echo 'Grupo não selecionado<br />';

} else {
	
	$update = "UPDATE produto SET  grupo = '$grupo' WHERE
	id =$id;";
	
	mysqli_query($mysqli, $update)or die (mysql_error($mysqli));
echo 'Grupos gravados!<br />';
	}
	}
	}
	?>
	<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='2;URL=../painel.php'>";
?>
	</div>
	</body>
	</html>