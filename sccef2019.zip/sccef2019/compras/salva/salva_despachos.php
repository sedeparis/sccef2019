<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como:  '. $logado;
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<title>Salva despachos</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
 <link rel="stylesheet" type="text/css" href="../../css/reset.css"/>
  <link rel="stylesheet" type="text/css" href="../../css/bootstrap.css" media="screen"/>
   <link rel="stylesheet" type="text/css" href="../../css/custom.css" media="screen"/>
</head>
<body>
<div class="container">
<h2>Despachos</h2>
<?php
$nid=$_POST['nid'];
$assunto=$_POST['assunto'];
$processo=$_POST['processo'];
$nome=$_POST['nome'];
$destino=$_POST['destina'];
$complemento=$_POST['complemento'];
$text=$_POST['despacho'];
$text1=$_POST['despacho1'];
$text2=$_POST['despacho2'];
$text3=$_POST['despacho3'];
$text4=$_POST['despacho4'];
$text5=$_POST['despacho5'];


$sql = mysqli_query($mysqli, "INSERT INTO cdtxtdespachos (nid, idprocesso, text,  texta, textb,  textc,  textd,  texte, idnome, iddestina, assunto, complemento) 
VALUES('$nid', '$processo', '$text', '$text1', '$text2', '$text3', '$text4', '$text5','$nome', '$destino', '$assunto', '$complemento')");
$resultado = mysqli_query($mysqli, $sql);
{echo "Cadastro efetuado com sucesso!";}
?>
<br>
<br>
<p class="center"><img src="../../img/salva.gif"/></p>
<br>
<br>
<?php

echo "<meta HTTP-EQUIV='refresh' CONTENT='3;URL=../executa/exec_imprime_despachos.php?processo=$processo&nome=$nome&nome=$destino'>";

?>
</div>
</body>
</html>
