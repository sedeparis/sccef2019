<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
echo 'Acessado como:  '. $logado;
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<title>Salvar</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
 <link rel="stylesheet" type="text/css" href="../../css/reset.css"/>
  <link rel="stylesheet" type="text/css" href="../../css/bootstrap.css" media="screen"/>
   <link rel="stylesheet" type="text/css" href="../../css/custom.css" media="screen"/>
</head>
<body>
<div class="container">
<?php
$uasg=$_POST['uasg'];
$nome=$_POST['nome'];
$endereco=$_POST['endereco'];
$cidade=$_POST['cidade'];
$uf=$_POST['uf'];

?>
<?php
$sql = mysqli_query($mysqli, "INSERT INTO cdorgao(uasg, nome, endereco, cidade, uf, orgao_principal)
VALUES('$uasg','$nome', '$endereco', '$cidade', '$uf', 'N')");
$resultado = mysqli_query($mysqli, $sql);
{echo "Cadastro efetuado com sucesso!";}
?>
<br>
<br>
<p class="center"><img src="../../img/salva.gif"/></p>
<br>
<br>
<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='3;URL=../painel.php'>";
?>
</div>
</body>
</html>