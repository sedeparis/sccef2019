<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
echo 'Acessado como:  '. $logado;
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<title>Gerenciamento de compras
</title>
<link rel="stylesheet" type="text/css" href="../css/reset.css" media="screen"/>
<link rel="stylesheet" type="text/css" href="../css/estilo.css" media="screen"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<div id="tudo">
<?php
$idforn=$_POST['idforn'];
		$nome=$_POST['nome'];
		$cnpj=$_POST['cnpj'];
		$endereco=$_POST['endereco'];
		$email=$_POST['email'];
		$banco=$_POST['banco'];
		$agencia=$_POST['agencia'];
		$conta=$_POST['conta'];
		$situacao=$_POST['situacao'];
	$dupesql = "SELECT * FROM cadfornecedor where (cnpj = '$cnpj')";

$duperaw = mysqli_query($mysqli, $dupesql);

if (mysqli_num_rows($duperaw) == 0) {
   echo "Cnpj não cadastrado.";

} else {	

$sql =("UPDATE cadfornecedor SET nome ='$nome', cnpj ='$cnpj', endereco ='$endereco',  
 email ='$email', banco ='$banco', agencia ='$agencia', conta ='$conta', situacao ='$situacao' WHERE idforn ='$idforn'");
$resultado = mysqli_query ($mysqli, $sql);
{echo "Fornecedor alterado com sucesso!";
}

$sqlb =( "UPDATE caditem SET idfornecedor ='$nome' WHERE idfornecedor ='$$nome'");
$resultadob = mysqli_query ($mysqli, $sqlb);
{echo " com sucesso!";
}
}
?>
<br>
<br>
<p class="center"><img src="../../img/salva.gif"/></p>
<br>
<br>
<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='3;URL=../painel.php'>";
?>
</div>
</body>
</html>