<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema Administrativo compras públicas.</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../../css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../../css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../../css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
	    
		<!--- scripts de validação de formulário --->
</head>
<body>
  <div class="container">
  <?php include "topo.php";?>
<?php
$id=$_POST['ided'];	
	$codigo=$_POST['coded'];
	$nome=$_POST['nome'];
		

$sql = mysqli_query($mysqli, "UPDATE cded SET coded ='$codigo', nome = '$nome' WHERE ided ='$id'");
$resultado = mysqli_query ($mysqli, $sql);
{echo "<p class='center'>Dados ED alterado com sucesso!</p>";
}
?>
<br>
<br>
<p class="center"><img src="../../img/salva.gif"/></p>
<br>
<br>
<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='3;URL=../painel.php'>";
?>
</div>
<?php include "footer.php"; ?>

</body>
</html>