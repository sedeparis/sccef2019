<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como:  '. $logado;
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<title>Cadastro de fornecedor</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <link rel="stylesheet" type="text/css" href="../../css/reset.css"/>
  <link rel="stylesheet" type="text/css" href="../../css/bootstrap.css" media="screen"/>
   <link rel="stylesheet" type="text/css" href="../../css/custom.css" media="screen"/>
</head>
<body>
<div class="container">
<?php
$nome=$_POST['nome'];
$cnpj=$_POST['cnpj'];
$endereco=$_POST['endereco'];
$cidade=$_POST['cod_cidades'];
$uf=$_POST['cod_estados'];
$email=$_POST['email'];
$fone=$_POST['fone'];
$banco=$_POST['banco'];
$agencia=$_POST['agencia'];
$conta=$_POST['conta'];
$operador=$_POST['operador'];
$contaO= $operador. ' - '. $conta
?>
<?php
 $dupesql =  "SELECT * FROM cadfornecedor where (cnpj = '$cnpj')";

$duperaw = mysqli_query($mysqli, $dupesql);

if (mysqli_num_rows($duperaw) > 0) {
   echo "Cnpj ja cadastrado.";

} else {
$sql = mysqli_query($mysqli, "INSERT INTO cadfornecedor(nome, cnpj, endereco, cidade, uf, email, fone, banco, agencia, conta, situacao)
VALUES('$nome', '$cnpj', '$endereco', '$cidade', '$uf', '$email', '$fone', '$banco', '$agencia', '$contaO', 'Ativo')");
$resultado = mysqli_query ($mysqli, $sql);
{echo "Cadastro efetuado com sucesso!";}
}
?>
<br /><p class="center"><img src="../../img/salva.gif"/></p><br />
<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='3;URL=../painel.php'>";
?>
</div>
</body>
</html>