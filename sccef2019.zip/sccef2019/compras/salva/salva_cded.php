<<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: '. $logado;
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<title>Salvar</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <link rel="stylesheet" type="text/css" href="../../css/reset.css"/>
  <link rel="stylesheet" type="text/css" href="../../css/bootstrap.css" media="screen"/>
   <link rel="stylesheet" type="text/css" href="../../css/custom.css" media="screen"/>
</head>
<body>
<div class="container">
<?php
$coded=$_POST['cod'];
$nome=$_POST['descricao'];

$sql = mysqli_query($mysqli, "INSERT INTO cded (coded, nome)
VALUES('$coded', '$nome')");
$resultado = mysqli_query ($mysqli, $sql);
{echo "<p class='center'>Cadastro efetuado com sucesso!</p>";}
?>
<br>
<br>
<p class="center"><img src="../../img/salva.gif"/></p>
<br>
<br>
<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='3;URL=../painel.php'>";
?>
</div>
</body>
</html>