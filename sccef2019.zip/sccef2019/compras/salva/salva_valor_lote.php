<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como:  '. $logado;
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Salva valor de compra</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	 <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../../css/bootstrap.css"" type="text/css"/>
   </head>
	 <body>
	 
	<div class="container">
	<br>
<p class="center"><img src="../../img/salva.gif"/></p>
<p class="center"><img src="../../img/moldura.gif"/></p>
<br>
<?php
if ( isset($_POST["submit"]))	{
echo '<pre>';
		print_r($_POST);
		echo '</pre>';
		foreach($_POST["id"] AS $id){
			echo 'id is'. $id . '<br />';
			echo 'qtde' . $_POST["qtde"][$id]."<br />";
			echo 'valor is ' . $_POST["valor"][$id]."<br />";
					
					
				$qtde = mysqli_real_escape_string($mysqli, $_POST["qtde"][$id]);
			   $valor = mysqli_real_escape_string($mysqli, $_POST["valor"][$id]);
			   $valora = str_replace(',','.',str_replace('.','',$valor));
	
	$update = "UPDATE produto SET valor_unitario = '$valora' WHERE
	id =$id;";
	mysqli_query($mysqli, $update)or die (mysqli_error($mysqli));
echo 'Tabela produtos atualizada!<br />';
//alimentar tabela entrada de produto
$sqlb = mysqli_query($mysqli, "INSERT INTO entrada_produto (id_produto, qtde, data_entrada)
VALUES ('$id','$qtde', NOW()) ");
 $resultado = mysqli_query ($mysqli, $sqlb);
{echo " dados informados com sucesso!";
}
	}
	}
	?>
	<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='3;URL=../painel.php'>";
?>
		 </div>
		<?php include "footer.php" ?>
	</body>
	</html>
	