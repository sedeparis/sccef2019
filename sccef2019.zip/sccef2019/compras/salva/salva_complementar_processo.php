<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: ' .$logado;
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema Administrativo compras públicas.</title>
	<link href="../../css/print_tab.css" rel="stylesheet" />
	  <link href="../../css/print_div.css" rel="stylesheet" />
	   <link href="../../css/print_fontes.css" rel="stylesheet" />
   
	    
		<!--- scripts de validação de formulário --->
 </head>
	 <body> 
	
	 <div class="titulo">
	 <h3>Dados Complmentares DE LICITAÇÃO</h3>
	 </div>
	 <div class="container">
	  <?php 
	  
	  //pega valores de post.
	  $processo=$_POST['processo'];
	   $tipo=$_POST['tipo'];
	   $numcompra=$_POST['numcompra'];
	   $uasg=$_POST['uasg'];
	   $pi=$_POST['pi'];
		$pi2=$_POST['pi2'];
		$ptres= $_POST['ptres'];


//condiciona a desprezar selecione pi

if ($pi != "Selecione..."){ // ou NULL
$pia = $pi ;
} else {
  $pia = "";
}
if ($pi2 != "Selecione..."){ // ou NULL
$pib = $pi2 ;
} else {
  $pib = "";
}
	 //atualiza tabela cadcompras
 $sql = mysqli_query($mysqli,"UPDATE cadcompras SET tipo='$tipo', numcompra = '$numcompra', uasg= '$uasg', pi='$pi', pi2='$pi2', ptres='$ptres'  WHERE idcompra='$processo'");
$resultado = mysqli_query ($mysqli, $sql);
{echo "Cadastros complementares efetuados com sucesso!";}
	  ?>
	  


<br>
<br>
<p class="center"><img src="../../img/salva.gif"/></p>
<br>
<br>
<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='3;URL=../painel.php'>";
?>

</div>
</body>
</html>