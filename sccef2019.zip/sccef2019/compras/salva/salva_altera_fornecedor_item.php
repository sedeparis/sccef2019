<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
echo 'Acessado como:  '. $logado;
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema Administrativo compras públicas.</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../../css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../../css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../../css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   
	    
   
	    
		<!--- scripts de validação de formulário --->
</head>
<body> <div class="container"> <?php include "topo.php"; echo 'Usuário logado: ';  echo $logado; ?> </div>
<div class="container">
<h2>Alterar fornecedor item</h2>
<?php
$altera=$_POST['altera'];
$fornecedor=$_POST['fornecedor'];
$valor=$_POST['valor'];
$valora = str_replace(',','.',str_replace('.','',$valor)); 
$erro=0;
//verificar se leu altera
if (empty ($altera))
{echo "Não consegui ler a variavel altera. Ou não foi selecionado ou informado os dados na página anterior ou voce acessou essa página pela barra de endereço do navegador, sem obedecer os links internos da aplicação.
 Favor retorne a pagina anteriror.<br><a href='../altera_fornecedor.php>Voltar</a>'>"; $erro=1;}
 //verificar se leu fornecedor
if (empty ($fornecedor))
{echo "Não consegui identificar o fornecedor. Ou não foi selecionado ou informado os dados na página anterior ou voce acessou essa página pela barra de endereço do navegador, sem obedecer os links internos da aplicação.
 Favor retorne a pagina anteriror.<br><a href='../altera_fornecedor_item.php>Voltar</a>'>"; $erro=1;}
if ($erro==0)
if ($erro==0)
	
{echo "Todos dados corretos"; }
$sql = @mysql_query("UPDATE caditem SET idfornecedor ='$fornecedor', valor='$valora' WHERE iditem ='$altera'");
$resultado = @mysql_query ($sql);
{echo "Fornecedor informado sucesso!";
}

?>
<br />
<br /><br /><br />
<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='3;URL=../painel.php'>";
?>
<br>
<br>
<p class="center"><img src="../../img/salva.gif"/></p>
<br>
<br>
</div>
</div>
<?php include "footer.php"; ?> </body>
</html>
