<?php
session_start();
	$_SESSION['email'];
	$_SESSION['senha'];
	header ("painel.php");
	$logado=$_SESSION['email'];
include ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema Administrativo compras públicas.</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
	<link rel="icon" type="image/jpg" href="../img/icone_barra.jpg" />    
		<!--- scripts de validação de formulário --->
		
		<script type="text/javascript">
		function validacao() {

if(document.form.altera.value=="Selecione...")
{
alert("Por favor selecione o processo");
document.form.altera.focus();
return false;
}
}
</script>
 </head>
	  <body>
	  <div class="container">
	  <?php  include "topo.php";
	  echo 'Acessado como: ';
echo $logado  ?>
	  </div>
	  
	  <div class="container">
	 <?php  ?>
	</div>
	 <div class="container">
	<h2 class="form-nome">Alterar Número da compra</h2>
	
<form name="form" method="POST" action="executa/exec_altera_num_compra.php" onSubmit="return validacao();"> 
	<fieldset class="grupo">
		  <div class="form-group">
	<?php 
	$query = mysqli_query($mysqli, "SELECT * FROM cadcompras WHERE finalcompra= 0 order by idcompra Desc");
?>
<br />
<br />
 <label class="form-control" for="">Selecione a compra</label>
 <select class="form-control"  class="form-control" name="altera">
 <option class="form-control" name="">Selecione...</option>
 <?php 
 while($busca = mysqli_fetch_array($query)) { 
 ?>
 <option class="form-control"   value="<?php 
 echo $busca['idcompra'] 
 ?>">
 <?php 
 echo $busca['processo'].' - '.$busca['finalidade']
 ?></option>
 <?php } ?>
 </select>
</div>
	</fieldset>
	 <div class="form-group">
<input class="form-control-2"  type="submit" id="submit" value="Selecionar" name="Localizar"/>
<input class="form-control-2"  type="submit" id="reset" value="Limpar" name="Limpar"/>
 <input class="form-control-2"  type="button" name="cancela" value="Cancelar" onclick="window.location.href='painel.php'"/>
</div>
</form>

 
  </div>
   <?php include "footer.php" ?> 
</body>
 </html>