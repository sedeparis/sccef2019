<?php
session_start();
	$_SESSION['email'];
	$_SESSION['senha'];
	header ("painel.php");
	$logado=$_SESSION['email'];
include ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Detalhamento orçamentario</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	 <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/estiloform.css" type="text/css"/>
	  <script type="text/javascript">
	    function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
 function moeda(z){
v = z.value;
v=v.replace(/\D/g,"") // permite digitar apenas numero
v=v.replace(/(\d{1})(\d{14})$/,"$1.$2") // coloca ponto antes dos ultimos digitos
v=v.replace(/(\d{1})(\d{11})$/,"$1.$2") // coloca ponto antes dos ultimos 11 digitos
v=v.replace(/(\d{1})(\d{8})$/,"$1.$2") // coloca ponto antes dos ultimos 8 digitos
v=v.replace(/(\d{1})(\d{5})$/,"$1.$2") // coloca ponto antes dos ultimos 5 digitos
v=v.replace(/(\d{1})(\d{1,2})$/,"$1,$2") // coloca virgula antes dos ultimos 2 digitos
z.value = v;
}

function validacao() {

if(document.form.item.value=="Selecione...")
{
alert("Por favor selecione o item.");
document.form.item.focus();
return false;
}

if(document.form.valora.value=="")
{
alert("Por favor informe o valor pesquisado.");
document.form.valora.focus();
return false;
}

if(document.form.dataa.value=="")
{
alert("Por favor insira a data da compra.");
document.form.dataa.focus();
return false;
}

if(document.form.fontea.value=="")
{
alert("Por favor insira a fonte da pesquisa.");
document.form.fontea.focus();
return false;
}


if(document.form.nomea.value=="")
{
alert("Por favor informe o nome do pesquisado.");
document.form.nomea.focus();
return false;
}
}
</script>
 </head>
	  <body> <div class="container"><?php include "topo.php"; echo 'Usuário Logado: '; echo $logado; ?> </div>
	 
   
	 <?php
	 
	 ?>
	 <div class="container">
	<h2 class="form-nome">Despacho Detalhamento Orçamentario</h2>
	<p></p>
	<p></p>
	
	<p></p>
	<p></p>
<form  name="form" method="POST" action="executa/exec_detalhamento_orcamentario.php" onSubmit="return validacao();">
	<?php 
	
	?>
	<fieldset class="grupo">
		  <div class="form-group">
		 <!---selecionar itens sem pesquisas --->
	<?php 
	$query = mysqli_query($mysqli, "SELECT * FROM cadcompras order by idcompra Desc");
?>
 <label class="form-control" for="">Selecione o processo</label>
 <select class="form-control" name="processo">
 <option class="form-control" name="">Selecione...</option>
 <?php 
 while($busca = mysqli_fetch_array($query)) { 
 ?>
 <option class="form-control"   value="<?php 
 echo $busca['idcompra'] 
 ?>">
 <?php 
 echo $busca['processo'].' - '.$busca['finalidade'];?>
 </option>
 <?php } ?>
 </select>
</div>
</fieldset>
	<fieldset class="grupo">
		  <div class="form-group">
		 <!---selecionar solicitante --->
	<?php 
	$queryb = mysqli_query($mysqli, "SELECT * FROM cdrequisitante");
?>
 <label class="form-control" for="">Requisitante:</label>
 <select class="form-control" name="requisita">
 <option class="form-control" name="">Selecione...</option>
 <?php 
 while($buscab = mysqli_fetch_array($queryb)) { 
 ?>
 <option class="form-control"   value="<?php 
 echo $buscab['idr'] 
 ?>">
 <?php 
 echo $buscab['nome'];?>
 </option>
 <?php } ?>
 </select>
</div>
</fieldset>
  <div class="form-group">
<input class="form-control-2"  type="submit" id="submit" value="Imprimir" name="print"/>
<input class="form-control-2"  type="reset" id="reset" value="Limpar dados" name="limpar"/>
<input class="form-control-2"  type="button" name="cancela" value="Cancelar" onclick="window.location.href='painel.php'"/>
</div>
</form>

</div> 
	 <?php include "footer.php" ?> </body>
 </html>