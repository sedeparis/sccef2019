<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema Administrativo compras públicas.</title>
	 <link href="../../css/print_tab.css" rel="stylesheet" />
	  <link href="../../css/print_div.css" rel="stylesheet" />
	   <link href="../../css/print_fontes.css" rel="stylesheet" />
   
	    
		<!--- scripts de validação de formulário --->
 </head>
	 <body> 
	 <div class="cabecalho">
	  <?php include "cabecalho.php"; ?> 
	  </div>
	  <?php 
	  $processo=$_GET['processo'];
	   $nome=$_GET['nome'];
	  ?>
	
<div class="titulo">
<h3>DESPACHO</h3>
</div>
<br />

<div class="textos">
<?php

// cria a instrução SQL que vai selecionar os dados do processo e fornecedor
$query = sprintf("SELECT * FROM cadcompras WHERE idcompra ='$processo'");
// executa a query
$dadosii = mysqli_query($mysqli, $query) or die(mysqli_error($mysqli));
// transforma os dados em um array
$linhaii = mysqli_fetch_assoc($dadosii);
// calcula quantos dados retornaram
$totalii = mysqli_num_rows($dadosii);
?>

<?php
	// se o número de resultados for maior que zero, mostra os dados  
	if($totalii > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
		$finalidade = $linhaii['finalidade'];
	$tipo = $linhaii['tipo'];
	$nproces= $linhaii['processo'];
		?>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linhaii = mysqli_fetch_assoc($dadosii));
	// fim do if 
	}
	
?>
<br />
<!---mostra dados gerais da licitacao--->



<?php
// tira o resultado da busca da memória
mysqli_free_result($dadosii);
?>

<?php
// cria a instrução SQL que vai selecionar os dados do despacho
$query = sprintf("SELECT * FROM cdtxtdespachos INNER JOIN cdservidor ON cdtxtdespachos.idnome=cdservidor.ids WHERE idprocesso ='$processo' ORDER BY idt DESC LIMIT 1");
// executa a query
$dados = mysqli_query($mysqli, $query) or die(mysqli_error($mysqli));
// transforma os dados em um array
$linha = mysqli_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysqli_num_rows($dados);
?>

<?php
	// se o número de resultados for maior que zero, mostra os dados 
	if($total > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
		$despacho = $linha['text'];
	$despacho1 = $linha['texta'];
	$despacho2 = $linha['textb'];
	$despacho3 = $linha['textc'];
	$despacho4 = $linha['textd'];
	$despacho5 = $linha['texte'];
	$asst = $linha['assunto'];
	$nome = $linha['nome'];
	$nid = $linha['nid'];
	$destino = $linha['iddestina'];
	$siape = $linha['siape'];
	$complemento = $linha['complemento'];
		?>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = mysqli_fetch_assoc($dados));
	// fim do if 
	}
	
?>
<?php
// cria a instrução SQL que vai selecionar os dados do despacho
$queryf = sprintf("SELECT * FROM cdservidor  WHERE ids ='$destino' ");
// executa a query
$dadosf = mysqli_query($mysqli, $queryf) or die(mysqli_error($mysqli));
// transforma os dados em um array
$linhaf = mysqli_fetch_assoc($dadosf);
// calcula quantos dados retornaram
$totalf = mysqli_num_rows($dadosf);
?>

<?php
	// se o número de resultados for maior que zero, mostra os dados 
	if($totalf > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
		
	$destina = $linhaf['nome'];
	
		?>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linhaf = mysqli_fetch_assoc($dadosf));
	// fim do if 
	}
	
?>
<span class="subtitulo">
Identificador: 
</span> 
 <span class="rsubtitulo">
<?php echo "$nid"?>
</span>

<span class="subtitulo">
Processo: 
</span> 
 <span class="rsubtitulo">
<?php echo "$nproces"?>
</span>
<br>
<span class="subtitulo">
Finalidade: 
</span> 
 <span class="rsubtitulo">
<?php echo "$finalidade" ?>
</span>
<br>

<span class="subtitulo">
De: 
</span> 
 <span class="rsubtitulo">
<?php echo "$nome" ?>
</span>
<br>
<span class="subtitulo">
Para: 
</span> 
 <span class="rsubtitulo">
<?php echo "$destina"?>
</span>
<br>
<span class="subtitulo"> 
</span> 
 <span class="rsubtitulo">
<?php echo "$complemento"?>
</span>
<br><br>
<span class="subtitulo">
Assunto: 
</span> 
 <span class="rsubtitulo">
<?php echo "$asst"?>
</span>
<br>
<!---mostra dados gerais da despacho--->
<p class="center">Encaminhamentos:</p>
<br>
<p class="var1">
<?php echo "$despacho" ?></p>
<p class="var1">
<?php echo "$despacho1" ?></p>
<p class="var1">
<?php echo "$despacho2" ?></p>
<p class="var1">
<?php echo "$despacho3" ?></p>
<p class="var1">
<?php echo "$despacho4" ?></p>
<p class="var1">
<?php echo "$despacho5" ?></p>

<br />
<?php
// tira o resultado da busca da memória
mysqli_free_result($dados);
?>
</div> 

<?php

// cria a instrução SQL que vai selecionar os dados do processo e fornecedor
$query = sprintf("SELECT * FROM cdrequisitante WHERE nome ='$nome'");
// executa a query
$dadosi = mysqli_query($mysqli, $query) or die(mysqli_error($mysqli));
// transforma os dados em um array
$linhai = mysqli_fetch_assoc($dadosi);
// calcula quantos dados retornaram
$totali = mysqli_num_rows($dadosi);
?>

<?php
	// se o número de resultados for maior que zero, mostra os dados  
	if($totali > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
		$quem = $linhai['nome'];
	$siape = $linhai['siape'];
	$funcao = $linhai['funcao'];
	
		?>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linhai = mysqli_fetch_assoc($dadosi));
	// fim do if 
	}
	
?>
<div class="textos">

<p class="direita"><?php echo "$local-$uf" ?> em  ___/____/20___
</p>
<br />
<br />
<!---mostra dados do despachante--->

<p class="center">_______________________________ <br /><?php echo "$nome" ?><br />
 <?php echo "Siape: ". "$siape" ?><br />
<br />
 </p>

<br />
<?php
// tira o resultado da busca da memória
mysqli_free_result($dadosi);
?>

<input type="button" name="cancela" value="Voltar" onclick="window.location.href='../painel.php'"/>
</div> 
</body>
</html>