<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema Administrativo compras públicas.</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../../css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../../css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../../css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   
	    
   
	    
		<!--- scripts de validação de formulário --->
  <script type="text/javascript">
	  function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
 
 function moeda(z){
v = z.value;
v=v.replace(/\D/g,"") // permite digitar apenas numero
v=v.replace(/(\d{1})(\d{16})$/,"$1.$2") // coloca ponto antes dos ultimos digitos
v=v.replace(/(\d{1})(\d{13})$/,"$1.$2") // coloca ponto antes dos ultimos 11 digitos
v=v.replace(/(\d{1})(\d{10})$/,"$1.$2") // coloca ponto antes dos ultimos 8 digitos
v=v.replace(/(\d{1})(\d{7})$/,"$1.$2") // coloca ponto antes dos ultimos 5 digitos
v=v.replace(/(\d{1})(\d{1,4})$/,"$1,$2") // coloca virgula antes dos ultimos 2 digitos
z.value = v;
}

 function validacao() {


if(document.form.fornecedor.value=="Selecione...")
{
alert("Por favor selecione o fornecedor.");
document.form.fornecedor.focus();
return false;
}

}
 </script>

</head>
<body> <div class="container"> <?php include "topo.php"; echo 'Usuário logado: ';  echo $logado; ?> </div>
<div class="container">
<h2>Alterar valor do item</h2>
<?php
$altera=$_POST['altera'];
echo $altera;
// cria a instrução SQL que vai selecionar os dados
$query = sprintf( "SELECT * FROM  produto 	WHERE id ='$altera'");
// executa a query
$dados = mysqli_query($mysqli, $query) ;
// transforma os dados em um array
$linha = mysqli_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysqli_num_rows($dados);
?>

<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($total > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
		$valor=$linha['valor_unitario'];
		//echo $valor;
		$valorC= str_replace('.',',',$valor);
		//echo $valorC;
?>
<form name="form" method="post" action="../salva/salva_altera_valor_item.php" onSubmit="return validacao();">
<input type="hidden" name="iditem" value="<?php print $linha['id']?>"/>

<fieldset class="grupo">
	 <div class="form-group">
<label class="form-control">Item  n°: </label>
<input readonly type="text" class="form-control"  size="2" name="nitem" value="<?php print $linha['id']. ' - ' .$linha['descricao']?>  "/> 
</div>

 <div class="form-group">
				<label class="form-control">Valor unitário do item R$ (4 casas depois da vírgula):</label>
		<input class="form-control"  type="moeda" name="valorMod" size="8" onkeyup="moeda(this)" value="<?php print $valorC?>"/>
		</div>

		</fieldset>
	<fieldset class="grupo">
		<div class="campo">
 <input type="submit" value="Alterar" name="altitem"/> 
  <input type="button" name="cancela" value="Cancelar" onclick="window.location.href='../painel.php'"/>
 </div>
 </fieldset>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = mysqli_fetch_assoc($dados));
	// fim do if 
	}
?>
<?php
// tira o resultado da busca da memória
mysqli_free_result($dados);
?>
</form>
</div>
</div>
<?php include "footer.php"; ?> </body>
</html>
