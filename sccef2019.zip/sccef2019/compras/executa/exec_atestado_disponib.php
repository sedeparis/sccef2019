<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	//echo 'Acessado como: $logado';
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
      <meta charset="utf-8" />
    <link href="../../css/print_tab.css" rel="stylesheet" />
	  <link href="../../css/print_div.css" rel="stylesheet" />
	   <link href="../../css/print_fontes.css" rel="stylesheet" />
	    <link href="../../css/print_tab.css" rel="stylesheet" />
   

		<!--- scripts de validação de formulário --->
	  <script type="text/javascript">
	  function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
	 </script>
   </head>
	 <body>  <div class="cabecalho">
	  <?php include "cabecalho.php"; ?> 
	  </div>
	 <div class="titulo">
	 <h3>ATESTADO DE DISPONIBILIDADE ORÇAMENTÁRIA</h3>
	 </div>
	 	<?php
	$processo=$_POST['processo'];
	$pi=$_POST['pi'];
$pi2=$_POST['pi2'];
$ptres= $_POST['ptres'];


//condiciona a desprezar selecione pi

if ($pi != "Selecione..."){ // ou NULL
$pia = $pi ;
} else {
  $pia = "";
}
if ($pi2 != "Selecione..."){ // ou NULL
$pib = $pi2 ;
} else {
  $pib = "";
}

$sql = mysqli_query($mysqli, "UPDATE cadcompras SET pi='$pi', pi2='$pi2', ptres='$ptres' WHERE idcompra='$processo'");
$resultado = mysqli_query ($mysqli, $sql);
{echo "";}
?>
<br>
<?php
//cria a instrução SQL que vai selecionar os dados para o cabeçalho
$sqlb = mysqli_query($mysqli, "SELECT * FROM cdorgao WHERE orgao_principal ='S'");
 $count = mysqli_num_rows($sqlb);
if ($count == 0) 
{ echo "Nenhum resultado!" ;}
while ($dados = mysqli_fetch_array($sqlb))
{ echo "";
 
$endereco=$dados['endereco'];
 $orgao=$dados['nome'];
 $dirad=$dados['gestor'];
 $dirge=$dados['diretor'];
$local= $dados['cidade'];
 $uf=$dados['uf'];
 $fonte=$dados['fonte'];
 $preprocesso=$dados['iniprocesso'];
 }
?>

<?php
// cria a instrução SQL que vai selecionar os dados do processo
$query = sprintf("SELECT * FROM cadcompras WHERE idcompra ='$processo'");
// executa a query
$dadosii = mysqli_query($mysqli, $query) or die(mysqli_error($mysqli));
// transforma os dados em um array
$linhaii = mysqli_fetch_assoc($dadosii);
// calcula quantos dados retornaram
$totalii = mysqli_num_rows($dadosii);
?>
<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($totalii > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
		$finalidade = $linhaii['finalidade'];
	$requisicao = $linhaii['numreq'];
	$nproc = $linhaii['processo'];
		?>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linhaii = mysqli_fetch_assoc($dadosii));
	// fim do if 
	}
?>
<!---mostra dados gerais da licitacao--->
<div class="textos">
<span class="subtitulo">
Requisição Nº:
</span>
<span class="rsubtitulo">
 <?php echo "$requisicao"?>
 </span>
<br>
<span class="subtitulo">
Processo:
</span>
<span class="rsubtitulo">
<?php echo "$nproc"?>
</span>
<br>
<span class="subtitulo">
Finalidade:
</span>
<span class="rsubtitulo">
 <?php echo "$finalidade" ?> 
 </span>
<?php
// tira o resultado da busca da memória
mysqli_free_result($dadosii);
?>
<?php
// cria a instrução SQL que vai selecionar os dados da soma total preço estimado 1
$result = mysqli_query($mysqli, "SELECT SUM(tot_estimado) AS valor_soma FROM produto WHERE idprocesso ='$processo' AND (finalizado = 0)");
 //executa a query
$row = mysqli_fetch_assoc($result);
$sum = $row['valor_soma'];
?>
<?php
// cria a instrução SQL que vai selecionar os dados da soma total preço estimado 1
$resultb = mysqli_query($mysqli, "SELECT SUM(tot_estimado2) AS valor_soma FROM produto WHERE idprocesso ='$processo' AND (finalizado = 0)");
 //executa a query
$row = mysqli_fetch_assoc($resultb);
$sum2 = $row['valor_soma'];
?>
<?php
// cria a instrução SQL que vai selecionar os dados da soma total preço estimado 1
$resultc = mysqli_query($mysqli, "SELECT SUM(tot_estimado3) AS valor_soma FROM produto WHERE idprocesso ='$processo' AND (finalizado = 0)");
 //executa a query
$row = mysqli_fetch_assoc($resultc);
$sum3 = $row['valor_soma'];
?>
<?php
$x= $sum;
$y= $sum2;
$z= $sum3;
//condiciona a desprezar valor zerados
$cont = 0;
if ($x != 0.00){ // ou NULL
$cont = $cont + 1;
}
if ($y != 0.00){ // ou NULL
$cont = $cont + 1;
}
if ($z != 0.00){ // ou NULL
$cont = $cont + 1;
}
$media = ($x+$y+$z)/$cont; 
?>
<p class="normal">
Valor da compra (estimado) R$:<span class="rel">
<?php echo number_format($media,2, ",",".");?></span></p>
<p class="normal">Considerando o exposto e a necessidade de prover meios para que o Instituto Federal de Mato Grosso do Sul – IFMS 
cumpra sua missão institucional, aprovo a justificativa de compra.</p>

<p class="normal">A despesa decorrente terá adequação orçamentária e financeira com a Lei Orçamentária Anual,
 e compatibilidade com o Plano Plurianual e com as Leis de Diretrizes Orçamentárias, 
 sendo a aquisição efetuada com recursos alocados a esta Unidade Gestora. 
</p>
<p class="normal">Dados orçamentários:</p>
</div>
<div class="tabela">
<table>
<colgroup>
<col width="25%">
</colgroup>
</table>
<?php
// cria a instrução SQL que vai selecionar os dados do processo
$queryb = sprintf("SELECT * FROM produto INNER JOIN cded ON produto.id=cded.ided WHERE idprocesso ='$processo' and ed<>'Selecione'");
// executa a query
$dadosz = mysqli_query($mysqli, $queryb) or die(mysqli_error($mysqli));
// transforma os dados em um array
$linhaz = mysqli_fetch_assoc($dadosz);
// calcula quantos dados retornaram
$totalz = mysqli_num_rows($dadosz);
?>
<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($totalz > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
		$eds = $linhaz['coded'];
		?>
<table>
<colgroup>
<col width="25%">
</colgroup>
<tbody>
<tr>
<td><?php echo  "ED:"." ". "$eds"?></td>
</tr>
</tbody>
</table>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linhaz = @mysql_fetch_assoc($dadosz));
	// fim do if 
	}
	?>
<table class="ed">
<colgroup>
<col width="40%">
</colgroup>
<tbody>
<tr>
<td class="d"><?php echo "Fonte:"." ". "$fonte" ?></td>
</tr>
</tbody>
</table>
<table class="ed">
<colgroup>
<col width="40%">
<col width="40%">
</colgroup>
<tbody>
<tr>
<td class="d"><?php echo "PI:"." ". "$pia" ?></td>
<td class="d"><?php echo "PI:"." "."$pib" ?></td>
</tr>
</tbody>
</table>
<table class="ed">
<colgroup>
<col width="40%">
</colgroup>
<tbody>
<tr>
<td class="d"><?php echo "PTRES:"." "."$ptres" ?></td>
</tr>
</tbody>
</table>
</div>
<div class="textos">
<p class="normal">
Esta licitação será regida pela Lei nº 8.666, de 21 de junho de 1993, e congêneres.</p>
<br />
<p class="direita"><?php echo "$local-$uf" ?> em  ___/____/20___
</p>
<br /><br /><br />
<p class="center">_______________________________ <br />
 Gestor Financeiro <br />
 </p>
</div>
<div class="button">
<input type="button" name="cancela" value="Voltar" onclick="window.location.href='../painel.php'"/>
</div> 
</body>
</html>
