<<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema Administrativo compras públicas.</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../../css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../../css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../../css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   
	    
		<!--- scripts de validação de formulário --->
		
		<script type="text/javascript">
	   function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
 
 function validacao() {

if(document.form.uasg.value=="")
{
alert("Por favor informe o número de uasg.");
document.form.uasg.focus();
return false;
}

if(document.form.nome.value=="")
{
alert("Por favor informe o nome do órgão.");
document.form.nome.focus();
return false;
}
if(document.form.endereco.value=="")
{
alert("Por favor informe o endereco.");
document.form.endereco.focus();
return false;
}

if(document.form.cidade.value=="")
{
alert("Por favor informe a cidade.");
document.form.cidade.focus();
return false;
}

if(document.form.uf.value=="")
{
alert("Por favor informe o estado.");
document.form.uf.focus();
return false;
}
}

 </script>
</head>
<body> <div class="container"> <?php include "topo.php"; echo 'Usuário logado: ';  echo $logado; ?> </div>
    <div class="container">
	  
	  </div>
	 
	  <div class="container">
<h2>Alterar órgão</h2>
<?php
$altera=$_POST['altera'];
// cria a instrução SQL que vai selecionar os dados
$query = sprintf("SELECT * FROM cdorgao WHERE idorgao ='$altera'");
// executa a query
$dados = mysqli_query($mysqli, $query) or die(mysqli_error($mysqli));
// transforma os dados em um array
$linha = mysqli_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysqli_num_rows($dados);
?>

<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($total > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
		$idorgao=$linha['idorgao'];
		$uasg=$linha['uasg'];
		$nome=$linha['nome'];
		$endereco=$linha['endereco'];
		$cidade=$linha['cidade'];
		$uf=$linha['uf'];
		$email=$linha['email'];
		$fone=$linha['fone'];
		
		
?>
<form name="form_altera" method="post" action="../salva/salva_altera_orgao.php">
<fieldset class="grupo">
		 <div class="form-group">
<input class="form-control" type="hidden" name="idorgao" value="<?php print $linha['idorgao']?>"/>
<label class="form-control">Uasg:</label> 
<input type="text" class="form-control" class="form-control"  size="8" name="uasg" value="<?php print "$uasg"?>"/> 
</div>
<div class="form-group">
<label class="form-control">Nome:</label>
<input type="text" class="form-control" class="form-control"  size="60" name="nome" value="<?php print "$nome" ?>"/> 
</div>
	</fieldset>
<fieldset class="grupo">
		 <div class="form-group">
<label class="form-control">Endereço:</label>
<input type="text" class="form-control" class="form-control" size="60" name="endereco" value="<?php print "$endereco" ?>"/> 
</div>
<div class="form-group">
 <label class="form-control">Cidade:</label>
<input type="text" class="form-control" class="form-control" size="35" name="cidade" value="<?php echo "$cidade" ?>"/> 
</div>
<div class="form-group">
 <label class="form-control">UF:</label>
<input type="text" class="form-control" class="form-control" size="2" name="uf" value="<?php print "$uf" ?>"/> 
</div>
<div class="form-group">
 <label class="form-control">Email:</label> 
<input type="text" class="form-control" class="form-control" size="15" name="email" value="<?php print "$email" ?>"/>
</div>
<div class="form-group">
<label class="form-control">Fone:</label>
<input type="text" class="form-control" class="form-control" size="10" name="fone" value="<?php print "$fone" ?>"/>
</div>
</fieldset>
		 <div class="form-group">
 <input type="submit" value="Alterar órgao" name="alteraorgao"/> 
   <input type="reset" name="Limpar" value="Limpar" />
 <input type="button" name="cancela" value="Cancelar" onclick="window.location.href='../painel.php'"/>
 </div>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = mysqli_fetch_assoc($dados));
	// fim do if 
	}
?>
<?php
// tira o resultado da busca da memória
mysqli_free_result($dados);
?>
</form>
</div>
 <?php include "footer.php"; ?> 
 </body>
</html>
