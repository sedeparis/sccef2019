<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema Administrativo compras públicas.</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../../css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../../css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../../css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   
	    
   
	    
		<!--- scripts de validação de formulário --->
  <script type="text/javascript">
	   function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
 </script>
</head>
<body> <div class="container"> <?php include "topo.php"; echo 'Usuário logado: ';  echo $logado; ?> </div>

<div class="container">
<h2>Alterar fornecedor</h2>
<?php
$altera=$_POST['altera'];
$erro= 0;


// cria a instrução SQL que vai selecionar os dados
$query = sprintf("SELECT * FROM cadfornecedor 
 WHERE idforn ='$altera'");
// executa a query
$dados = mysqli_query($mysqli, $query) or die(mysql_error($mysqli));
// transforma os dados em um array
$linha = mysqli_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysqli_num_rows($dados);
?>

<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($total > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
		$idforn=$linha['idforn'];
		$nome=$linha['nome'];
		$cnpj=$linha['cnpj'];
		$endereco=$linha['endereco'];
		$cidade=$linha['cidade'];
		$uf=$linha['uf'];
		$email=$linha['email'];
		$banco=$linha['banco'];
		$agencia=$linha['agencia'];
		$conta=$linha['conta'];
		
?>
<form name="form_altera" method="post" action="../salva/salva_altera_fornecedor.php""> 
<fieldset class="grupo">
<div class="campo">
<label class="form-control">Nome: </label>
<input type="text" class="form-control"  size="50" name="nome" value="<?php print "$nome" ?>"/> 
</div>
<div class="campo">
<label class="form-control">Cnpj: </label> 
<input type="text" class="form-control"  size="22" name="cnpj" maxlength="18" onkeypress="mascara(this, '##.###.###/####-##')" value="<?php print "$cnpj"?>"/> 
</div>
<div class="campo">
<label class="form-control">Endereço: </label>
<input type="text" class="form-control" size="40" name="endereco" value="<?php print "$endereco" ?>"/> 
</div>

<div class="campo">
 <label class="form-control">Email: </label> 
<input type="text" class="form-control" size="25" name="email" value="<?php print "$email" ?>"/>
</div>

<fieldset class="grupo">
		 <div class="form-group">
 <?php	$query = mysqli_query($mysqli, "SELECT * FROM cdbanco");
?>
 <label class="form-control" for="">Selecione o Banco:</label>
 <select class="form-control" name="banco">
 <option class="form-control" name="">Selecione...</option>
 <?php while($banco = mysqli_fetch_array($query)) { 
 ?>
 <option class="form-control"   value="<?php echo $banco['idbanco'] ?>"><?php echo $banco['codigo'].' - '.$banco['banco'] ?></option>
 <?php } ?>
 </select>
 </div>
<div class="campo">
<label class="form-control">Agencia: </label>
<input type="text" class="form-control" size="10" name="agencia" value="<?php print "$agencia" ?>"/>
</div>
<div class="campo">
<label class="form-control">Conta: </label>
<input type="text" class="form-control" size="10" name="conta" value="<?php print "$conta" ?>"/>
<input type="hidden" name="idforn" value="<?php print $linha['idforn']?>"/>
</div>
</fieldset>
		 <div class="campo">
<?php 
	$query = mysqli_query($mysqli, "SELECT * FROM cdsituacao");
?>
 <label for="">(Des)Ativa</label>
 <select class="form-control" name="situacao">
 <option class="form-control" name="">Ativo</option>
 <?php 
 while($busca = mysqli_fetch_array($query)) { 
 ?>
 <option class="form-control" value="<?php 
 echo $busca['situacao'] 
 ?>">
 <?php 
 echo $busca['situacao']
 ?></option>
 <?php } ?>
 </select>
 <?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = mysqli_fetch_assoc($dados));
	// fim do if 
	}
?>
<?php
// tira o resultado da busca da memória
mysqli_free_result($dados);
?>
	</div>

</fieldset>
 <fieldset class="grupo">
		 <div class="campo">

 <input type="submit" value="Alterar Fornecedor" name="altraforn"/>
 <input type="button" name="cancela" value="Cancelar" onclick="window.location.href='../painel.php'"/>
</div>
</fieldset>
</form>
</div>
<?php include "footer.php"; ?> </body>
</html>
