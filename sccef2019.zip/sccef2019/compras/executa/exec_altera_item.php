<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema Administrativo compras públicas.</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../../css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../../css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../../css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   
	    
   
	    
		<!--- scripts de validação de formulário --->
  <script type="text/javascript">
	  function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
 
 function moeda(z){
v = z.value;
v=v.replace(/\D/g,"") // permite digitar apenas numero
v=v.replace(/(\d{1})(\d{14})$/,"$1.$2") // coloca ponto antes dos ultimos digitos
v=v.replace(/(\d{1})(\d{11})$/,"$1.$2") // coloca ponto antes dos ultimos 11 digitos
v=v.replace(/(\d{1})(\d{8})$/,"$1.$2") // coloca ponto antes dos ultimos 8 digitos
v=v.replace(/(\d{1})(\d{5})$/,"$1.$2") // coloca ponto antes dos ultimos 5 digitos
v=v.replace(/(\d{1})(\d{1,2})$/,"$1,$2") // coloca virgula antes dos ultimos 2 digitos
z.value = v;
}

 function validacao() {



if(document.form.nitem.value=="")
{
alert("Por favor insira o número do item.");
document.form.nitem.focus();
return false;
}
if(document.form.ditem.value=="")
{
alert("Por favor insira descrição do item.");
document.form.ditem.focus();
return false;
}

if(document.form.quantidade.value=="")
{
alert("Por favor insira a.");
document.form.quantidade.focus();
return false;
}

if(document.form.situa.value=="Selecione...")
{
alert("Por favor selecione a situacao.");
document.form.situa.focus();
return false;
}

if(document.form.un.value=="Selecione")
{
alert("Por favor selecione a un.");
document.form.un.focus();
return false;
}

}
 </script>

</head>
<body> <div class="container"> <?php include "topo.php"; echo 'Usuário logado: ';  echo $logado; ?> </div>
<div class="container">
<h2>Alterar item</h2>
<?php
$altera=$_POST['altera'];
// cria a instrução SQL que vai selecionar os dados
$query = sprintf("SELECT * FROM caditem WHERE iditem ='$altera'");
// executa a query
$dados = @mysql_query($query) or die(mysql_error());
// transforma os dados em um array
$linha = @mysql_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysql_num_rows($dados);
?>

<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($total > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
		
?>
<form name="form" method="post" action="../salva/salva_altera_itens.php" onSubmit="return validacao();">
<input type="hidden" name="iditem" value="<?php print $linha['iditem']?>"/>
<input type="hidden" name="quant_lic" value="<?php print $linha['quant_lic']?>"/>
<fieldset class="grupo">
		 <div class="campo">
<label class="form-control">Item <br>n°: </label>
<input type="text" class="form-control"  size="2" name="nitem" value="<?php print $linha['nitem']?>"/> 
</div>
<div class="campo">
<label class="form-control">Situação <br>do item: </label> 
<select class="form-control" name="situa">
<option class="form-control" selected>Ativo</option>
<option class="form-control">Inativo</option>
</select>
</div>
<div class="campo">
<label class="form-control">Quant<br> Mínima: </label>
<input type="text" class="form-control" size="2" name="quant_min" value="<?php print $linha['quant_min']?>"/> 
</div>
<div class="campo">
<label class="form-control">Quant <br>máxima: </label>
<input type="text" class="form-control" size="2" name="quantidade" value="<?php print $linha['quant_lic']?>"/> 
</div>
</fieldset>
<fieldset class="grupo">
<div class="campo">
<label class="form-control">Descrição: </label>
<input type="text" class="form-control"  size="90" name="ditem" value="<?php print $linha['ditem']?>"/> 
</div>

<div class="campo">
<?php 
	$query = mysql_query("SELECT * FROM cdunidade");
?>
 <label for="">Selecione uma unidade</label>
 <select class="form-control" name="un">
 <option class="form-control" name="">Selecione</option>
 <?php while($prod = mysql_fetch_array($query)) { ?>
 <option class="form-control" value="<?php echo $prod['unidade']?>"><?php echo $prod['unidade'] ?></option>
 <?php  } ?>
 </select>
		</div>
		</fieldset>
	<fieldset class="grupo">
		<div class="campo">
 <input type="submit" value="Alterar" name="altitem"/> 
  <input type="button" name="cancela" value="Cancelar" onclick="window.location.href='../painel.php'"/>
 </div>
 </fieldset>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = @mysql_fetch_assoc($dados));
	// fim do if 
	}
?>
<?php
// tira o resultado da busca da memória
@mysql_free_result($dados);
?>
</form>
</div>
</div>
<?php include "footer.php"; ?> </body>
</html>
