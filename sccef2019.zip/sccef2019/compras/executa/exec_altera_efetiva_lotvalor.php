<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema Administrativo compras públicas.</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../../css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../../css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../../css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
		<!--- scripts de validação de formulário --->
	  <script type="text/javascript">
	  function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
 function moeda(z){
v = z.value;
v=v.replace(/\D/g,"") // permite digitar apenas numero
v=v.replace(/(\d{1})(\d{14})$/,"$1.$2") // coloca ponto antes dos ultimos digitos
v=v.replace(/(\d{1})(\d{11})$/,"$1.$2") // coloca ponto antes dos ultimos 11 digitos
v=v.replace(/(\d{1})(\d{8})$/,"$1.$2") // coloca ponto antes dos ultimos 8 digitos
v=v.replace(/(\d{1})(\d{5})$/,"$1.$2") // coloca ponto antes dos ultimos 5 digitos
v=v.replace(/(\d{1})(\d{1,2})$/,"$1,$2") // coloca virgula antes dos ultimos 2 digitos
z.value = v;
}
	 </script>
   </head>
	 <body> <div class="container"> <?php include "topo.php"; echo 'Usuário logado: ';  echo $logado; ?> </div>
  
	 <div class="container">
	<h2>Alterar valor do item </h2>
	
<br />
<div id="atencao">
<p>ATENÇÃO!: <br />
	Altere o valor  do item inserindo novo valor
	</p><br />
	</div>
	<div id="lotes">
	<?php
	$item=$_POST['item'];
	
 $sql = "SELECT * FROM produto
 INNER JOIN CDUNIDADE ON produto.un=cdunidade.idun
 WHERE id = '$item' AND (finalizado = 0) AND valor_unitario <>'' ";
 $res = mysqli_query($mysqli, $sql) or die(mysqli_error($mysqli));
  if (mysqli_num_rows($res) == 0 ) {
  echo "Não encontrei itens sem valor informado. <a href='../painel.php'>Voltar</a>";}
  else {
  if (mysqli_num_rows($res) > 0 ) {
  echo '<form method="post" action="../salva/salva_altera_efetiva_lotvalor.php">';
  while ( $row = mysqli_fetch_assoc($res) )
	  {
  //echo ' ' . $row["id_produto"]. '-';
    
  $valorb = str_replace('.',',',$row["valor_unitario"]);
  echo '<span class="colorc">Nº do item:</span> ' . $row["nitem"]. '<br>';
  echo '<span class="colorc">Descrição: </span> ' . $row["descricao"]. '<br>';
  echo '<span class="colorc">UN:</span>  ' . $row["unidade"]. '<br>';
  echo '<span class="colorc">Valor:</span> ' "$valorb". '<br>';
  echo ' <span class="colorc">Valor do item R$:  </span><input type="moeda" size="8" name="valor['.$row["id"].']" onkeyup="moeda(this)" value="'.$valorb.'">'.'<br></p>'."\n";
  echo '<input type="hidden" name="id[]" value="'.$row["id"].'"> '."\n";
  echo "<hr>\n";
  }
  echo '<input type="submit" name="submit" value="Infomar Valores">';
   echo '';
  echo '</form>';
  }
  }
?>
<input type="button" name="cancela" value="Cancelar" onclick="window.location.href='../painel.php'"/>
</div>
</div>
<?php include "footer.php"; ?> </body>
</html>
 