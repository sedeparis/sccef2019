<<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	//echo 'Acessado como: $logado';
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema Administrativo compras públicas.</title>
	<link href="../../css/print_tab.css" rel="stylesheet" />
	  <link href="../../css/print_div.css" rel="stylesheet" />
	   <link href="../../css/print_fontes.css" rel="stylesheet" />
   
	    
		<!--- scripts de validação de formulário --->
 </head>
	 <body> 
	 <div class="cabecalho">
	  <?php include "cabecalho.php"; ?> 
	  </div>
	 <div class="titulo">
	 <h3>DESPACHO MODALIDADE DE LICITAÇÃO</h3>
	 </div>
	  <?php 
	  
	  //pega valores de post.
	  $processo=$_POST['processo'];
	   $tipo=$_POST['tipo'];
	   $numcompra=$_POST['numcompra'];
	   $uasg=$_POST['uasg'];
	 //atualiza tabela cadcompras
 $sql = mysqli_query($mysqli,"UPDATE cadcompras SET tipo='$tipo', numcompra = '$numcompra', uasg= '$uasg' WHERE idcompra='$processo'");
$resultado = mysqli_query ($mysqli, $sql);
	  ?>
	  


<?php
// cria a instrução SQL que vai selecionar os dados do processo
$query = sprintf("SELECT * FROM cadcompras WHERE idcompra ='$processo'");
// executa a query
$dadosii = mysqli_query($mysqli, $query) or die(mysqli_error($mysqli));
// transforma os dados em um array
$linhaii = mysqli_fetch_assoc($dadosii);
// calcula quantos dados retornaram
$totalii = mysqli_num_rows($dadosii);
?>
<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($totalii > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
		$finalidade = $linhaii['finalidade'];
	$tipo = $linhaii['tipo'];
	$numcompra = $linhaii['numcompra'];
		
		?>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linhaii = mysqli_fetch_assoc($dadosii));
	// fim do if 
	}
?>
<!---mostra dados gerais da licitacao--->
<div class="textos">
<span class="subtitulo">
 Processo:
 </span> 
 <span class="rsubtitulo">
<?php echo "$processo"?>
</span>
<br>
<span class="subtitulo">
Finalidade: 
</span>
<span class="rsubtitulo">
<?php echo "$finalidade" ?>
</span>
<br>
<span class="subtitulo">
Compra-modalidade:
 </span>
<span class="rsubtitulo">
<?php echo $tipo.' - '.$numcompra.' - Uasg: '.$uasg?>
</span>
<br>

<?php
// tira o resultado da busca da memória
mysqli_free_result($dadosii);
?>
<?php
// cria a instrução SQL que vai selecionar os dados da soma total preço estimado 1
$resulta = mysqli_query($mysqli, "SELECT SUM(tot_estimado) AS valor_soma FROM produto WHERE idprocesso ='$processo' AND (finalizado = 0)");
 //executa a query
$row = mysqli_fetch_assoc($resulta);
$sum = $row['valor_soma'];
?>
<?php
// cria a instrução SQL que vai selecionar os dados da soma total preço estimado 1
$resultb = mysqli_query($mysqli, "SELECT SUM(tot_estimado2) AS valor_soma FROM produto WHERE idprocesso ='$processo' AND (finalizado = 0)");
 //executa a query
$row = mysqli_fetch_assoc($resultb);
$sum2 = $row['valor_soma'];
?>
<?php
// cria a instrução SQL que vai selecionar os dados da soma total preço estimado 1
$resultc = mysqli_query($mysqli, "SELECT SUM(tot_estimado3) AS valor_soma FROM produto WHERE idprocesso ='$processo' AND (finalizado = 0)");
 //executa a query
$row = mysqli_fetch_assoc($resultc);
$sum3 = $row['valor_soma'];
?>
<?php
$x= $sum;
$y= $sum2;
$z= $sum3;


//condiciona a desprezar valor zerados
$cont = 0;
if ($x != 0.00){ // ou NULL
$cont = $cont + 1;
}
if ($y != 0.00){ // ou NULL
$cont = $cont + 1;
}
if ($z != 0.00){ // ou NULL
$cont = $cont + 1;
}
if ($cont==0) { echo "<p class='inf'>Não encotramos pesquisas de preços lançadas para estimar a compra.</p> <br> " ;
$media = 0;
}
else{
	$media=($x+$y+$z)/$cont;}
echo 'Valor da compra estimado: R$ <span class="rel">';
 echo number_format($media,2, ",",".");
 echo '</span></p>';
?>
</div>
<br />
<?php
// cria a instrução SQL que vai selecionar os dados do despacho
$queryb = sprintf("SELECT * FROM cadtipo WHERE tipo ='$tipo'");
// executa a query
$dadosi = mysqli_query($mysqli, $queryb) or die(mysqli_error($mysqli));
// transforma os dados em um array
$linhai = mysqli_fetch_assoc($dadosi);
// calcula quantos dados retornaram
$totali = mysqli_num_rows($dadosi);
?>

<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($totalii > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
		$bloca = $linhai['texta'];
	$blocb = $linhai['textb'];
	$blocc = $linhai['textc'];
	$blocd = $linhai['textd'];
	$bloce = $linhai['texte'];
	$blocf = $linhai['textf'];
	$blocg = $linhai['textg'];
	$bloch = $linhai['texth'];
	$bloci = $linhai['texti'];
	$blocj = $linhai['textj'];
	
		?>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linhai = mysqli_fetch_assoc($dadosi));
	// fim do if 
	}
	
?>
<br />
<!---mostra dados gerais da licitacao--->
<div class="textos">

<?php 
if ($bloca == ''){ echo "Atenção: cadastre o texto para essa modalidade no icone TX_modal para imprimir o texto desejado";}

 echo '<p class="var">'."$bloca".'</p>';
 echo '<p class="var">'."$blocb".'</p>';
 echo '<p class="var">'."$blocc".'</p>' ;
 echo '<p class="var">'."$blocd".'</p>' ;
 echo '<p class="var">'."$bloce".'</p>' ;
 echo '<p class="var">'."$blocf".'</p>' ;
echo '<p class="var">'."$blocg".'</p>' ;
echo '<p class="var">'."$bloch".'</p>' ;
echo '<p class="var">'."$bloci".'</p>' ;
echo '<p class="var">'."$blocj".'</p>' ;
?>

<br />
<?php
// tira o resultado da busca da memória
mysqli_free_result($dadosi);
?>
</div>
<div class="textos">
<br />

<p class="direita"><?php echo "$local-$uf" ?> em  ___/____/20___
</p>
<br /><br />
<p class="center">_______________________________ <br />
 Gestor Financeiro  <br />

 </p>
</div>
 
<div class="button">
<input type="button" name="cancela" value="Voltar" onclick="window.location.href='../painel.php'"/>
</div>
</body>
</html>