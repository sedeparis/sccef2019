<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Parecer e Ratificação GF e OD</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 <link href="../../css/print_tab.css" rel="stylesheet" />
	  <link href="../../css/print_div.css" rel="stylesheet" />
	   <link href="../../css/print_fontes.css" rel="stylesheet" />
   
	    
		<!--- scripts de validação de formulário --->
 </head>
	 <body>
	 <div class="cabecalho">
	  <?php include "cabecalho.php"; ?> 
	  </div>
	 <div class="titulo">
	 <h3>PARECER/RATIFICAÇÃO DO GESTOR FINANCEIRO E ORDENADOR DE DESPESAS</h3>
	 </div>
	  	 <?php
// cria a instrução SQL que vai selecionar os dados para o cabeçalho
$sql = mysqli_query( $mysqli, "SELECT * FROM cdorgao WHERE orgao_principal = 'S'");
 $count = mysqli_num_rows($sql);
if ($count == 0) 
{ echo "Nenhum resultado!" ;}
while ($dados = mysqli_fetch_array($sql))
{ echo "";
 $endereco=$dados['endereco'];
 $orgao=$dados['nome'];
 $dirad=$dados['gestor'];
 $dirge=$dados['diretor'];
$local= $dados['cidade'];
 $uf=$dados['uf'];
 $fonte=$dados['fonte'];
 $preprocesso=$dados['iniprocesso'];
 }
 ?>
 
 <?php
//carrega dados do formulario do cdfolhaempenho
$processo=$_POST['processo'];
// cria a instrução SQL que vai selecionar os dados do processo e fornecedor
$querya = sprintf("SELECT * FROM cadcompras WHERE idcompra ='$processo'");
// executa a query
$dadosii = mysqli_query($mysqli, $querya) or die(mysqli_error($mysqli));
// transforma os dados em um array
$linhaii = mysqli_fetch_assoc($dadosii);
// calcula quantos dados retornaram
$totalii = mysqli_num_rows($dadosii);

	// se o número de resultados for maior que zero, mostra os dados//
	if($totalii > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
		$finalidade = $linhaii['finalidade'];
	$tipo = $linhaii['tipo'];
	$ncompra = $linhaii['numcompra'];
	$requisicao = $linhaii['numreq'];
	$numcompra = $linhaii['numcompra'];
	$nproces = $linhaii['processo'];
		// finaliza o loop que vai mostrar os dados
		}while($linhaii = mysqli_fetch_assoc($dadosii));
	// fim do if 
	}
	?>
<!---mostra dados gerais da licitacao--->

<div class="textos">
<span class="subtitulo">
Requisição Nº:
</span>
<span class="rsubtitulo">
 <?php echo "$requisicao"?>
 </span>
<br>
<span class="subtitulo">
Processo:
</span>
<span class="rsubtitulo">
<?php echo "$nproces"?>
</span>
<br>
<span class="subtitulo">
Finalidade:
</span>
<span class="rsubtitulo">
 <?php echo $finalidade ?> 
 </span>
 <br>
<span class="subtitulo">
Compra-modalidade:
</span>
<span class="rsubtitulo">
<?php echo $tipo. ' - '. $ncompra ?>
</span>

<?php
// tira o resultado da busca da memória
mysqli_free_result($dadosii);
?>
<?php
// cria a instrução SQL que vai selecionar os dados da soma total preço estimado 1
$result = mysqli_query($mysqli, "SELECT SUM(tot_estimado) AS valor_soma FROM produto WHERE idprocesso ='$processo' AND (finalizado = 0)");
 //executa a query
$row = mysqli_fetch_assoc($result);
$sum = $row['valor_soma'];
?>
<?php
// cria a instrução SQL que vai selecionar os dados da soma total preço estimado 1
$resulta = mysqli_query($mysqli, "SELECT SUM(tot_estimado2) AS valor_soma FROM produto WHERE idprocesso ='$processo' AND (finalizado = 0)");
 //executa a query
$row = mysqli_fetch_assoc($resulta);
$sum2 = $row['valor_soma'];
?>
<?php
// cria a instrução SQL que vai selecionar os dados da soma total preço estimado 1
$resultb = mysqli_query($mysqli, "SELECT SUM(tot_estimado3) AS valor_soma FROM produto WHERE idprocesso ='$processo' AND (finalizado = 0)");
 //executa a query
$row = mysqli_fetch_assoc($resultb);
$sum3 = $row['valor_soma'];
?>
<?php
$x= $sum;
$y= $sum2;
$z= $sum3;


//condiciona a desprezar valor zerados
$cont = 0;
if ($x != 0.00){ // ou NULL
$cont = $cont + 1;
}
if ($y != 0.00){ // ou NULL
$cont = $cont + 1;
}
if ($z != 0.00){ // ou NULL
$cont = $cont + 1;
}
$media = ($x+$y+$z)/$cont; 
?>

<p class="normal">
Valor da compra estimado: <span class="rel">
<?php echo number_format($media,2, ",",".");?></span></p>
<hr>
<br />
<p class="normal">Tendo em vista a justificativa apresentada, bem como a disponibilização orçamentária para a referida aquisição, 
autoriza-se o seguimento do processo de COMPRAS, conforme valor estimado e modalidade definidos acima. 
 </p>
<br />
<p class="direita"><?php echo "$local-$uf" ?>  ___/____/20___
</p>

<br />
<br />
<p class="center">
_________________________
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
________________________
<br /></p>
<p class="center">Gestor Financeiro
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
Ordenador de Despesas
</p>
</div>
<div class="button">
<input type="button" name="cancela" value="Voltar" onclick="window.location.href='../painel.php'"/>
</div>
</body>
</html>