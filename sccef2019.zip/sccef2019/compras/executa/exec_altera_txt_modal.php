<<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema Administrativo compras públicas.</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../../css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../../css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../../css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   
	    
	    
		<!--- scripts de validação de formulário --->
  <script type="text/javascript">
	  function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
 
 function validacao() {


if(document.form.ed.value=="")
{
alert("Por favor insira ED.");
document.form.ed.focus();
return false;
}

if(document.form.nitem.value=="")
{
alert("Por favor insira o número do item.");
document.form.nitem.focus();
return false;
}
if(document.form.ditem.value=="")
{
alert("Por favor insira descrição do item.");
document.form.ditem.focus();
return false;
}

if(document.form.quantidade.value=="")
{
alert("Por favor insira a.");
document.form.quantidade.focus();
return false;
}

if(document.form.situa.value=="Selecione...")
{
alert("Por favor selecione a situacao.");
document.form.situa.focus();
return false;
}

if(document.form.un.value=="Selecione")
{
alert("Por favor selecione a un.");
document.form.un.focus();
return false;
}

if(document.form.valor.value=="")
{
alert("Por favor insira o valor.");
document.form.valor.focus();
return false;
}
}
 </script>

</head>
<body> <div class="container"> <?php include "topo.php"; echo 'Usuário logado: ';  echo $logado; ?> </div>
<div class="container">
<h2>Alterar textos</h2>
<?php
$altera=$_POST['altera'];
// cria a instrução SQL que vai selecionar os dados
$query = sprintf("SELECT * FROM cadtipo WHERE idtipo ='$altera'");
// executa a query
$dados = mysqli_query($mysqli, $query) ;
// transforma os dados em um array
$linha = mysqli_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysqli_num_rows($dados);
?>

<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($total > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
		$valora=$linha['texta'];
		$valorb=$linha['textb'];
		$valorc=$linha['textc'];
		$valord=$linha['textd'];
		$valore=$linha['texte'];
		$valorf=$linha['textf'];
		$valorg=$linha['textg'];
		$valorh=$linha['texth'];
		$valori=$linha['texti'];
		$valorj=$linha['textj'];
		$idt=$linha['idtipo'];
?>
<form name="form" method="post" action="../salva/salva_altera_txt_modal.php" onSubmit="return validacao();">
<input type="hidden" name="tipo" value="<?php print $linha['idtipo']?>"/>

<fieldset class="grupo">
		 <div class="form-group">
<label class="form-control">Paragrafo 1: </label>
<textarea class="form-control" name="txta" cols="100" rows="5">
<?php print $linha['texta']?>
</textarea>
</div>
<div class="form-group">
<label class="form-control">Paragrafo 2: </label> 
<textarea class="form-control" name="txtb" cols="100" rows="5">
<?php print $linha['textb']?>
</textarea>
</div>
<div class="form-group">
 <label class="form-control">Paragrafo 3: </label>
<textarea class="form-control" name="txtc" cols="100" rows="5">
<?php print $linha['textc']?>
</textarea>
</div>
<div class="form-group">
<label class="form-control">Paragrafo 4: </label>
<textarea class="form-control" name="txtd" cols="100" rows="3">
<?php print $linha['textd']?>
</textarea>
</div>
<div class="form-group">
<label class="form-control">Paragrafo 5: </label>
<textarea class="form-control" name="txte" cols="100" rows="3">
<?php print $linha['texte']?>
</textarea>
</div>
<div class="form-group">
<label class="form-control">Paragrafo 6: </label>
<textarea class="form-control" name="txtf" cols="100" rows="3">
<?php print $linha['textf']?>
</textarea>
</div>
<div class="form-group">
<label class="form-control">Paragrafo 7: </label>
<textarea class="form-control" name="txtg" cols="100" rows="3">
<?php print $linha['textg']?>
</textarea>
</div>
<div class="form-group">
<label class="form-control">Paragrafo 8: </label>
<textarea class="form-control" name="txth" cols="100" rows="3">
<?php print $linha['texth']?>
</textarea>
</div>
<div class="form-group">
<label class="form-control">Paragrafo 9: </label>
<textarea class="form-control" name="txti" cols="100" rows="3">
<?php print $linha['texti']?>
</textarea>
</div>
<div class="form-group">
<label class="form-control">Paragrafo 10: </label>
<textarea class="form-control" name="txtj" cols="100" rows="3">
<?php print $linha['textj']?>
</textarea>
</div>
		</fieldset>
	<fieldset class="grupo">
		<div class="form-group">
 <input type="submit" value="Cadastrar/Alterar" name="altxt"/> 
  <input type="button" name="cancela" value="Cancelar" onclick="window.location.href='../painel.php'"/>
 </div>
 </fieldset>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = mysqli_fetch_assoc($dados));
	// fim do if 
	}
?>
<?php
// tira o resultado da busca da memória
mysqli_free_result($dados);
?>
</form>
</div>
</div>
<?php include "footer.php"; ?> </body>
</html>
