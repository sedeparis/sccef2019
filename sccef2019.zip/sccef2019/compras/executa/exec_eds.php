<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema Administrativo compras públicas.</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../../css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../../css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../../css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   
		<!--- scripts de validação de formulário --->
	  <script type="text/javascript">
	  function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
	 </script>
   </head>
	 <body> <div class="container"> <?php include "topo.php"; echo 'Usuário logado: ';  echo $logado; ?> </div>
  
	 <div class="container">
	<h2>Informar EDs</h2>
	
	<?php
	$processo=$_POST['processo'];
	$ed=$_POST['ed'];
	echo '<div id="dados">';
 $sql = "SELECT * from produto INNER JOIN cdunidade ON produto.un=cdunidade.idun  WHERE idprocesso = '$processo' AND (finalizado = 0) AND ed =''";
 $res = mysqli_query($mysqli, $sql) or die(mysqli_error($mysqli));
  if (mysqli_num_rows($res) == 0 ) {
  echo "Todos os itens possuem EDs. <a href='../painel.php'>Voltar</a>";}
  else {
  if (mysqli_num_rows($res) > 0 ) {
  echo '<form method="post" action="../salva/salva_eds.php">';
  while ( $row = mysqli_fetch_assoc($res) )
	  {
  //echo ' ' . $row["id"]. '-';
   echo '<span class="colorblue">Nº do item:</span> ' . $row["nitem"]. '<br>';
  echo '<span class="colorblue">Descrição:</span> ' . $row["descricao"]. '<br>';
  echo ' Un:' . $row["unidade"]. '<br>';
 echo  'O ED informado é o correto para o item? <br><span class="colorblue">  &emsp; Sim </span> <input type="radio" name="radio['.$row["id"].']" value="'.'1'.'"> '."\n";
 echo '<span class="color">       &emsp;     &emsp;   Não</span> <input type="radio" checked="checked" name="radio['.$row["id"].']" value="'.'0'.'"> '."\n";
  echo '<input type="hidden" size="5" name="elem['.$row["id"].']" value="'.$ed.'"> '."\n";
  echo '<input type="hidden" name="id[]" value="'.$row["id"].'"> '."\n";
  echo "<hr>\n";
  }
  echo '<input type="submit" name="submit" value="Infomar EDs">';
   echo '';
  echo '</form>';
  }
  }
  echo '</div>';
?><input type="button" name="cancela" value="Cancelar" onclick="window.location.href='../painel.php'"/>
</div>
<?php include "footer.php"; ?> </body>
</html>
