<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema Administrativo compras públicas.</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../../css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../../css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../../css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   
	    
	    
		<!--- scripts de validação de formulário --->
</head>
<body> <div class="container"> <?php include "topo.php"; echo 'Usuário logado: ';  echo $logado; ?> </div>
<div class="container">
<h2>Salva Efetiva item</h2>
<?php
$iditem=$_POST['item'];
$fornecedor=$_POST['fornecedor'];
$valor=$_POST['valor'];
$valora = str_replace(',','.',str_replace('.','',$valor));  
?>

<?php
 $sql = @mysql_query("UPDATE caditem SET valor ='$valora', idfornecedor='$fornecedor' WHERE iditem ='$iditem'");
 $resultado = @mysql_query ($sql);
{echo "Dados informados com sucesso!";
}
?>
<br />
<br /><br /><br />
<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='1;URL=../efetiva_item.php'>";
?>
</div>
</div>
<?php include "footer.php"; ?> </body>
</html>
