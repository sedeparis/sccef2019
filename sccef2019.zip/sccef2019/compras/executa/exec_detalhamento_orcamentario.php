<<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Imprime DO</title>
	  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 <link href="../../css/print_tab.css" rel="stylesheet" />
	  <link href="../../css/print_div.css" rel="stylesheet" />
	   <link href="../../css/print_fontes.css" rel="stylesheet" />
 </head>
	 <body>
	  <div class="cabecalho">
	  <?php include "cabecalho.php"; ?> 
	  </div>
	 <div class="titulo">
	  <h3>SOLICITAÇÃO DE DETALHAMENTO ORÇAMENTÁRIO</h3>
 </div>
	 <?php
// cria a instrução SQL que vai selecionar os dados para o cabeçalho
$sql = mysqli_query($mysqli, "SELECT * FROM cdorgao WHERE orgao_principal = 'S'");
 $count = mysqli_num_rows($sql);
if ($count == 0) 
{ echo "Nenhum resultado!" ;}
while ($dados = mysqli_fetch_array($sql))
{ echo "";
 $endereco=$dados['endereco'];
 $orgao=$dados['nome'];
 $dirad=$dados['gestor'];
 $dirge=$dados['diretor'];
$local= $dados['cidade'];
 $uf=$dados['uf'];
 $fonte=$dados['fonte'];
 $preprocesso=$dados['iniprocesso'];
 }
 ?>
 
 <?php
//carrega dados do formulario do cdfolhaempenho
$processo=$_POST['processo'];
$solic=$_POST['requisita'];
// cria a instrução SQL que vai selecionar os dados do processo 
$query = sprintf("SELECT * FROM cadcompras WHERE idcompra ='$processo'");
// executa a query
$dadosii = mysqli_query($mysqli, $query) or die(mysqli_error($mysqli));
// transforma os dados em um array
$linhaii = mysqli_fetch_assoc($dadosii);
// calcula quantos dados retornaram
$totalii = mysqli_num_rows($dadosii);

	// se o número de resultados for maior que zero, mostra os dados//
	if($totalii > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
		$finalidade = $linhaii['finalidade'];
	$tipo = $linhaii['tipo'];
	$requisicao = $linhaii['numreq'];
	$numcompra = $linhaii['numcompra'];
	$proc = $linhaii['processo'];
		// finaliza o loop que vai mostrar os dados
		}while($linhaii = mysqli_fetch_assoc($dadosii));
	// fim do if 
	}
	?>
<!---mostra dados gerais da licitacao--->

<div class="textos">
<span class="subtitulo">
Requisição Nº:
</span>
<span class="rsubtitulo">
 <?php echo "$requisicao"?>
 </span>
<br>
<span class="subtitulo">
Processo:
</span>
<span class="rsubtitulo">
<?php echo "$proc"?>
</span>
<br>
<span class="subtitulo">
Finalidade:
</span>
<span class="rsubtitulo">
 <?php echo $finalidade ?> 
 </span>
 <br>
</div>
<?php
// tira o resultado da busca da memória
@mysql_free_result($dadosii);
?>
<div class="textos">
<p class="normal">Prezado(a) Coordenador(a): <br />
Tendo em vista a intenção de compra, com os itens abaixo descriminados, solicitamos o detalhamento orçamentário.</p>

<?php
// cria a instrução SQL que vai selecionar os dados do processo e fornecedor
$queryb = sprintf("SELECT * FROM cdrequisitante WHERE idr ='$solic'");
// executa a query
$dadosi = mysqli_query($mysqli, $queryb) or die(mysql_error($mysqli));
// transforma os dados em um array
$linhai = mysqli_fetch_assoc($dadosi);
// calcula quantos dados retornaram
$totali = mysqli_num_rows($dadosi);

	// se o número de resultados for maior que zero, mostra os dados//
	if($totali > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
			$nomesolic = $linhai['nome'];
	$siape = $linhai['siape'];
	
	
		// finaliza o loop que vai mostrar os dados
		}while($linhai = mysqli_fetch_assoc($dadosi));
	// fim do if 
	}
	?>
	<p class="direita"><?php echo "$local-$uf,&nbsp;&nbsp;&nbsp;"?>
 <?php
date_default_timezone_set("America/Cuiaba");
echo date("d/m/Y");
?></p>
<br /><br /><br />

<p class="center">_______________________________<br />
<?php echo "$nomesolic"?><br />
 Solicitante <br />Siape  
 <?php echo "$siape"?><br />
 </p>
 </div>
<?php
// tira o resultado da busca da memória
@mysql_free_result($dadosii);
?>
<div class="tabela">
<table>
<colgroup>
<col width="10%">
<col width="70%">
<col width="20%">
</colgroup>
<thead>
<tr>
<th>Item</th>
<th>Descrição</th>
<th>E.d</th>
</tr>
</thead>
</table>

<?php
// cria a instrução SQL que vai selecionar os dos itens
$queryc = ("SELECT * FROM produto WHERE idprocesso ='$processo' AND finalizado = 0");
// executa a query
$dados = mysqli_query($mysqli, $queryc) or die(mysql_error($mysqli));
// transforma os dados em um array
$linha = mysqli_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysqli_num_rows($dados);
?>
<!-- mostra itens empenhados-->
<?php
if($total == 0) { echo 'Esse processo não tem itens cadastrados ou já foi concluído';}
	// se o número de resultados for maior que zero, mostra os dados//
	if($total > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {

$nitem = $linha['nitem'];
$ditem= $linha['descricao'];

?>
<table>
<colgroup>
<col width="10%">
<col width="70%">
<col width="20%">
</colgroup>
<tbody>
<tr>
<td class="a"><?php echo "$nitem"?></td>
<td class="a"><?php echo "$ditem"?></td>
<td></td>
</tr>
</tbody>
</table>

<?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = mysqli_fetch_assoc($dados));
	// fim do if 
	}
?>
</div>
<div class="tabela">
<table id="a" width="50%">
<colgroup>
<col width="20%">
<col width="30%">
</colgroup>
<tr>
<td class="a">Fonte</td>
<td class="a"></td>
</tr>
<tr>
<td class="a">PTRES</td>
<td class="a"></td>
</tr>
<tr>
<td class="a">PI</td>
<td class="a"></td>
</tr>
<tr>
<td class="a">PI</td>
<td class="a"></td>
</tr>
</table>
</div>

<div class="textos">
<p class="direita"><?php echo "$local-$uf,&nbsp;&nbsp;&nbsp;"?>  ____/______/______
 </p>
<br /><br /><br />

<p class="center">_______________________________<br />

 Responsável Copor <br />
 Siape   ____________<br />
 </p>
</div>
<div class="button">
<input type="button" name="cancela" value="Voltar" onclick="window.location.href='../painel.php'"/>
</div>
</body>
</html>
 	
