<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema Administrativo compras públicas.</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
	<link rel="icon" type="image/jpg" href="../img/icone_barra.jpg" />    
		<!--- scripts de validação de formulário --->
		<script type="text/javascript">
	   function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
 
 function validacao() {

if(document.form.uasg.value=="")
{
alert("Por favor informe o número de uasg.");
document.form.uasg.focus();
return false;
}

if(document.form.nome.value=="")
{
alert("Por favor informe o nome do órgão.");
document.form.nome.focus();
return false;
}
if(document.form.endereco.value=="")
{
alert("Por favor informe o endereco.");
document.form.endereco.focus();
return false;
}

if(document.form.cidade.value=="")
{
alert("Por favor informe a cidade.");
document.form.cidade.focus();
return false;
}

if(document.form.uf.value=="")
{
alert("Por favor informe o estado.");
document.form.uf.focus();
return false;
}
}

 </script>
   </head>
	  <body> 
	  <div class="container"> 
	  <?php include "topo.php"; echo 'Usuário logado: '. $logado; ?> 
	  </div> 
    
	 <div class="container">
	<h2 class="form-nome">Cadastro de Órgão</h2>
	 
	<form name="form" method="post" action="salva/salva_orgao.php" onSubmit="return validacao();"> 
	
	<fieldset class="grupo">
		  <div class="form-group">
		 <label class="form-control">Uasg:</label>
<input class="form-control" type="text" name="uasg" size="6" maxlength="6" requerid="requerid" title="uasg"/>
</div>
	  <div class="form-group">
			<label class="form-control">Nome do Órgão:</label>
<input class="form-control" type="text" name="nome" size="86" requerid="requerid" title="nome"/>
</div>
	  <div class="form-group">
		<label class="form-control">Endereço:</label>
		<input class="form-control" type="text" name="endereco" size="100" />
		</div>
			  <div class="form-group">
		<label class="form-control">Cidade:</label>
	<input class="form-control" type="text" name="cidade" size="40"/>
	</div>
	  <div class="form-group">
	<label class="form-control">Estado:</label>
<input class="form-control" type="text" name="uf" size="2"  maxlength="2" />
</div>
	</fieldset>
	  <div class="form-group">
	<input class="form-control-2"  type="submit" name="enviar" value="Cadastrar Órgão"/>
	<input class="form-control-2"  type="reset" name="limpa" value="Limpar"/>
	 <input class="form-control-2"  type="button" name="cancela" value="Cancelar" onclick="window.location.href='painel.php'"/>
</form>
</div>
 </div>
<?php include "footer.php" ?>
 </body>
 </html>