<?php
session_start();
	$_SESSION['email'];
	$_SESSION['senha'];
	header ("painel.php");
	$logado=$_SESSION['email'];
include ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Altera fornecedor</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	 <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/estiloform.css" type="text/css"/>
	  <script type="text/javascript">
	  
 function moeda(z){
v = z.value;
v=v.replace(/\D/g,"") // permite digitar apenas numero
v=v.replace(/(\d{1})(\d{14})$/,"$1.$2") // coloca ponto antes dos ultimos digitos
v=v.replace(/(\d{1})(\d{11})$/,"$1.$2") // coloca ponto antes dos ultimos 11 digitos
v=v.replace(/(\d{1})(\d{8})$/,"$1.$2") // coloca ponto antes dos ultimos 8 digitos
v=v.replace(/(\d{1})(\d{5})$/,"$1.$2") // coloca ponto antes dos ultimos 5 digitos
v=v.replace(/(\d{1})(\d{1,2})$/,"$1,$2") // coloca virgula antes dos ultimos 2 digitos
z.value = v;
}

function validacao() {

if(document.form.altera.value=="Selecione...")
{
alert("Por favor selecione o item.");
document.form.altera.focus();
return false;
}

if(document.form.fornecedor.value=="Selecione...")
{
alert("Por favor selecione o fornecedor.");
document.form.fornecedor.focus();
return false;
}
}
</script>
 </head>
	  <body> <div class="container"><?php include "topo.php"; echo 'Usuário Logado: '; echo $logado; ?> </div>
	 
   
	 <?php
	 
	 ?>
	 <div class="container">
	<h2 class="form-nome">Alterar fornecedor do item</h2>
	
<form  name="form" method="POST" action="executa/exec_altera_fornecedor_item.php" onSubmit="return validacao();">
	<?php 
	
	?>
	
		  <div class="form-group">
	<?php 
	$query = mysqli_query($mysqli, "SELECT * FROM produto WHERE efetivado = 1 ORDER by id DESC");
?>

 <label class="form-control" for="">Selecione o item</label>
 <select class="form-control" name="altera">
 <option class="form-control" name="">Selecione...</option>
 <?php 
 while($busca = mysqli_fetch_array($query)) { 
 ?>
 <option class="form-control"   value="<?php 
 echo $busca['id'] 
 ?>">
 <?php 
 echo $busca['processo'].' - '. $busca['nitem'].' - '.substr($busca['descricao'],0,100);
 ?></option>
 <?php } ?>
 </select>
</div>
 
	
	 <div class="form-group">
<input class="form-control-2"  type="submit" id="submit" value="Alterar Preço/fornecedor" name="Localizar"/>
<input class="form-control-2"  type="reset" id="reset" value="Limpar dados" name="limpar"/>
<input class="form-control-2"  type="button" name="cancela" value="Cancelar" onclick="window.location.href='painel.php'"/>
</div>
</form>

	 
</div>	
<?php include "footer.php" ?> 
	</body>
 </html>