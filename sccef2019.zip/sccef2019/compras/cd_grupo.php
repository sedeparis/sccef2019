<?php
session_start();
	$_SESSION['email'];
	$_SESSION['senha'];
	header ("painel.php");
	$logado=$_SESSION['email'];
include ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Agrupar itens</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	 <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	  <link rel="stylesheet" href="../css/estiloform.css" type="text/css"/>
   <script type="text/javascript">
	   function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
 function validacao() {

if(document.form.processo.value=="Selecione...")
{
alert("Por favor informe o nome o processo.");
document.form.processo.focus();
return false;
}

if(document.form.grupo.value=="Selecione...")
{
alert("Por favor informe o grupo.");
document.form.grupo.focus();
return false;
}

}
 
 </script>
   </head>
	 <body> <div class="container">
	 <?php include "topo.php"; echo 'Usuário Logado: '; echo $logado; ?> </div>
	 

	 <div class="container">
	<h2 class="form-nome">Agrupar itens</h2>
	 <br />
	<p>Use essa ferramenta informar o grupo dos itens de uma compra.</p>
	
	<form name="form" method="post" action="executa/exec_grupo.php" onSubmit="return validacao();"> 
		<fieldset class="grupo">
		  <div class="form-group">
		<?php 
	$query = mysqli_query($mysqli, "SELECT * FROM cadcompras WHERE situacao = '1' AND (finalcompra=0) ORDER BY idcompra DESC");
?>
 <label class="form-control" for="">Selecione uma compra</label>
 <select class="form-control" name="processo">
 <option class="form-control" name="">Selecione...</option>
 <?php while($proc = mysqli_fetch_array($query)) { ?>
 <option class="form-control"   value="<?php echo $proc['idcompra'] ?>"><?php echo $proc['processo']." - ".$proc['finalidade'] ?></option>
 <?php } ?>
 </select>
 </div>
 </fieldset>
	 <fieldset class="grupo">
	  <div class="form-group">
		<?php 
	$queryb = mysqli_query($mysqli, "SELECT * FROM grupos");
?>
 <label class="form-control" for="">Selecione um grupo</label>
 <select class="form-control" name="grupo">
 <option class="form-control" name="">Selecione...</option>
 <?php while($proc = mysqli_fetch_array($queryb)) { ?>
 <option class="form-control"   value="<?php echo $proc['grupo'] ?>"><?php echo $proc['grupo'] ?></option>
 <?php } ?>
 </select>
 </div>
		  </fieldset>
		 <fieldset class="grupo">
		 <div class="form-group">
	<input class="form-control-2"  type="submit" value="Selecionar itens"/>
	 <input class="form-control-2"  type="reset" value="Limpar"/>
	  <input class="form-control-2"  type="button" name="cancela" value="Cancelar" onclick="window.location.href='painel.php'"/>
	 </div>
	  </fieldset>
</form>
</div>
 <?php include "footer.php" ?>
  </body>
 </html>