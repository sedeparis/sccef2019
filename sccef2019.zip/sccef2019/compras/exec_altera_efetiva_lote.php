<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema Administrativo compras públicas.</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../../css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../../css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../../css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   
	    
   
	    
		<!--- scripts de validação de formulário --->
	  <script type="text/javascript">
	  function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
	 </script>
   </head>
	 <body> 
	 <div class="container">
	 <?php include "topo.php"; echo 'Usuário logado: ';  echo $logado; ?> 
	 </div>
  
	 <div class="container">
	<h2>Informar Fornecedor em série</h2>
	
<br />
<div id="atencao">
<p>ATENÇÃO!: <br /><br />
	Marque sim para os itens cujo fornecedor informado na tela anterior for o vencedor. 
	Para os demais, vá repetindo a operação até contemplar todos os itens.
	</p><br />
	
	<?php
	
	$processo=$_POST['processo'];
	$fornecedor=$_POST['fornecedor'];
	
	echo 'Processo: '.$processo; 
	echo '<br>Fornecedor: ' .$fornecedor;
	echo '<br><br><br></div>';
	echo '<div id="dados">';
 $sql = "SELECT * from produto WHERE idprocesso= '$processo' AND finalizado = 0 AND (fornecedora <> '') ";
 $res = mysqli_query($mysqli, $sql) or die(mysqli_error($mysqli));
  if (mysqli_num_rows($res) == 0 ) {
  echo "Todos os itens sem fornecedor. <a href='../painel.php'>Voltar</a>";}
  else {
  if (mysqli_num_rows($res) > 0 ) {
  echo '<form method="post" action="../salva/salva_altera_efetiva_lotfor.php">';
  while ( $row = mysqli_fetch_assoc($res) )
	  {
  //echo ' ' . $row["iditem"]. '-';
  echo '<span class="colorc">Nº do item:</span> ' . $row["nitem"]. '<br>';
  echo '<span class="colorc">Descrição:</span> ' . $row["descricao"]. '<br>';
  echo '<span class="colorc">UN:</span>  ' . $row["un"]. '<br>';
 echo  '<span class="colorc">O Fornecedor informado é o vencedor do item?</span> Sim <input type="radio" name="radio['.$row["id"].']" value="'.'1'.'"> '."\n";
 echo '<span class="color">       &emsp;     &emsp;   Não</span> <input type="radio" checked="checked" name="radio['.$row["id"].']" value="'.'0'.'"> '."\n";
  echo '<input type="hidden" size="5" name="fornecedor['.$row["id"].']" value="'.$fornecedor.'"> '."\n";
  echo '<input type="hidden" name="id[]" value="'.$row["id"].'"> '."\n";
  echo "<hr>\n";
  }
  echo '<input type="submit" name="submit" value="Infomar Fornecedor">';
   echo '';
  echo '</form>';
  }
  }
  echo '</div>';
?>
<input type="button" name="cancela" value="Cancelar" onclick="window.location.href='../painel.php'"/>
</div>
</div>
<?php include "footer.php"; ?> </body>
</html>
 