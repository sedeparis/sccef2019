<?php
session_start();
	$_SESSION['email'];
	$_SESSION['senha'];
	header ("painel.php");
	$logado=$_SESSION['email'];
include ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema Administrativo compras públicas.</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
	    
		<!--- scripts de validação de formulário --->
	  <script type="text/javascript">
 function validacao() {
if(document.form.altera.value=="Selecione...")
{
alert("Por favor selecione a modalidade.");
document.form.altera.focus();
return false;
}
}
</script>
 </head>
	  <body>
 <div class="container"><?php include "topo.php"; echo 'Usuário Logado: '; echo $logado; ?> 
 </div>
	 <div class="container">
	<h2 class="form-nome">Alterar textos escolha da modalidade</h2>
	
<form name="form" method="POST" action="executa/exec_altera_txt_modal.php" onSubmit="return validacao();">
<fieldset class="grupo">
		  <div class="form-group">
	<?php 
	$query = mysqli_query($mysqli, "SELECT * FROM cadtipo");
?>
 <label class="form-control" for="">Selecione a modalidade</label>
 <select class="form-control"  class="form-control" name="altera">
 <option class="form-control" name="">Selecione...</option>
 <?php 
 while($busca = mysqli_fetch_array($query)) { 
 ?>
 <option class="form-control"   value="<?php 
 echo $busca['idtipo'] 
 ?>">
 <?php 
 echo $busca['tipo'];?>
 </option>
 <?php } ?>
 </select>
</div>
	</fieldset>
	<fieldset class="grupo">
		  <div class="form-group">
<input class="form-control-2"  type="submit" id="submit" value="Selecionar" name="Localizar"/>
<input class="form-control-2"  type="reset" id="reset" value="Limpar item" name="reset"/>
<input class="form-control-2"  type="button" name="cancela" value="Cancelar" onclick="window.location.href='painel.php'"/>
</div>
	</fieldset>
</form>
 </div>
<?php include "footer.php" ?> 
	
	 </body>
 </html>