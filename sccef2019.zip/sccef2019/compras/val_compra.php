<?php
session_start();
	$_SESSION['email'];
	$_SESSION['senha'];
	header ("painel.php");
	$logado=$_SESSION['email'];
include ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Informar validade da compra</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	 <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/estiloform.css" type="text/css"/>
	<link rel="stylesheet" href="../js/jquery.js"/>
<link rel="stylesheet" href="http://code.jquery.com/ui/1.9.0/themes/base/jquery-ui.css"/>
<script src="http://code.jquery.com/jquery-1.8.2.js"></script>
<script src="http://code.jquery.com/ui/1.9.0/jquery-ui.js"></script>
<script type="text/javascript">
	  function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
 function moeda(z){
v = z.value;
v=v.replace(/\D/g,"") // permite digitar apenas numero
v=v.replace(/(\d{1})(\d{14})$/,"$1.$2") // coloca ponto antes dos ultimos digitos
v=v.replace(/(\d{1})(\d{11})$/,"$1.$2") // coloca ponto antes dos ultimos 11 digitos
v=v.replace(/(\d{1})(\d{8})$/,"$1.$2") // coloca ponto antes dos ultimos 8 digitos
v=v.replace(/(\d{1})(\d{5})$/,"$1.$2") // coloca ponto antes dos ultimos 5 digitos
v=v.replace(/(\d{1})(\d{1,2})$/,"$1,$2") // coloca virgula antes dos ultimos 2 digitos
z.value = v;
}

 function validacao() {
if(document.form.processo.value=="Selecione...")
{
alert("Por favor selecione o processo.");
document.form.processo.focus();
return false;
}


if(document.form.data.value=="")
{
alert("Por favor informe a data.");
document.form.data.focus();
return false;
}
}
<!-- chamar calendario --->
$(function() {
$("#calendario").datepicker({dateFormat: 'dd-mm-yy'});
});

$(function() {
$( "#calendario" ).datepicker({
showOn: "button",
buttonImage: "calendario.png",
buttonImageOnly: true
});
});
$(function() {
$("#calendario").datepicker({
changeMonth: true,
changeYear: true
});
});
$(function() {
$("#calendario").datepicker({
showOtherMonths: true,
selectOtherMonths: true
});
});
</script>
 </head>
	 <body>
	 <div class="container">
	 <?php include "topo.php"; echo 'Usuário Logado: '; echo $logado; ?> 
	 </div>
	 
    
	 <div class="container">
	<h2 class="form-nome">Informar validade da compra</h2>
	
	
	<form name="form" method="post" action="salva/salva_val_compra.php" onSubmit="return validacao();">
	<fieldset class="grupo">
		  <div class="form-group">
	<?php 
	$query = mysqli_query($mysqli,"SELECT * FROM cadcompras WHERE situacao='1' AND fase='1' AND dataval = '' ORDER BY idcompra DESC");
?>
 <label class="form-control" for="">Selecione uma compra</label>
 <select class="form-control" name="processo">
 <option class="form-control" name="">Selecione...</option>
 <?php while($prod = mysqli_fetch_array($query)) { ?>
 <option class="form-control"   value="<?php echo $prod['idcompra'] ?>"><?php echo $prod['processo']." - ".$prod['finalidade'] ?></option>
 <?php } ?>
 </select>
 </div>
 </fieldset>
	<fieldset class="grupo">
		  <div class="form-group">
 <label class="form-control">Data limite para empenho:</label>
		<input class="form-control" type="text" name="data" id="calendario" onkeypress="mascara(this, '##/##/####')"/>
	 </div>
		</fieldset>
		
		<fieldset class="grupo">
  <div class="form-group">
	<input class="form-control-2"  type="submit" value="Informar data"/>
	 <input class="form-control-2"  type="reset" value="Limpar"/>
	 <input class="form-control-2"  type="button" name="cancela" value="Cancelar/Voltar" onclick="window.location.href='painel.php'"/>
	 </div>
 </fieldset>
</form>
 </div>
 <?php include "footer.php" ?> 

 </body>
 </html>