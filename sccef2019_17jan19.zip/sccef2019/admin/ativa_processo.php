<?php
session_start();
if((!isset ($_SESSION['email']) == true) and (!isset ($_SESSION['senha']) == true))
{
  unset($_SESSION['email']);
  unset($_SESSION['senha']);
  header('location:../index.php');
  }
 
$logado=$_SESSION['email'];
echo '<div class="container">';
echo 'Acessado como:  '.$logado;
echo '</div>';
include_once ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../img/icone_barra.jpg" />
	 <title>Inativar processo</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/estiloform.css" type="text/css"/>
 </head>
	 <body>
<div class="container">
	 <?php include "topo.php"; echo 'Usuário Logado: '; echo $logado; ?> </div>
	 
	 <div class="container">
	<h1>Inativar processo</h1>
	
<form name="form" method="POST" action="../executa/exec_ativa_processo.php">
	<?php
	$e= ' - ';
$query = mysql_query("SELECT * FROM cadcompras WHERE situacao = 'Inativo'");
?>
<br />
 <br />
 <label class="form-control" for="">Selecione processo:</label>
 <select class="form-control" name="local">
 <option class="form-control" name="">Selecione...</option>
 <?php while($busca = mysql_fetch_array($query)) { ?>
 <option  class="form-control"value="<?php echo $busca['idcompra'] ?>">
 <?php echo $busca['processo'].$e.$busca['finalidade']?></option>
 <?php } ?>
 </select>

<input type="submit" value="ativar" name="buscar"/>
<br />
 <br />
</form>
</div>
<?php include "footer.php" ?>
	 </body>
 </html>