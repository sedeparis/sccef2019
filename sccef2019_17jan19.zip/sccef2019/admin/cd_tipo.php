<<?php
session_start();
if((!isset ($_SESSION['email']) == true) and (!isset ($_SESSION['senha']) == true))
{
  unset($_SESSION['email']);
  unset($_SESSION['senha']);
  header('location:../index.php');
  }
 
$logado=$_SESSION['email'];
echo '<div class="container">';
echo 'Acessado como:  '.$logado;
echo '</div>';
include_once ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../img/icone_barra.jpg" />
	 <title>cadastro de tipos de processos</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	 <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	  <link rel="stylesheet" href="../css/estiloform.css" type="text/css"/>
	  	 <script type="text/javascript">
	  function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
 function validacao() {

if(document.form.tipo.value=="")
{
alert("Por favor informe o tipo de processo.");
document.form.tipo.focus();
return false;
}
}
</script>
 </head>
	  <body> <div class="container"><?php include "topo.php"; echo 'Usuário Logado: '; echo $logado; ?> </div>
	 
    
	 <div class="container">
	<h2 class="form-nome">Cadastro de tipos de processos</h2>
	<div id="corpo">
	<fieldset>
	<form name="form" method="post" action="salva/salva_tipo.php" onSubmit="return validacao();"> 
			<fieldset class="grupo">
		  <div class="form-group">
		 <label class="form-control">Tipo de processo:</label>
<input class="form-control" type="text" name="tipo" size="35" requerid="requerid"/>
</div>
	</fieldset>
		  <div class="form-group">
	<input class="form-control-2"  type="submit" name="enviar" value="Cadastrar Tipo"/>
	<input class="form-control-2"  type="submit" name="limpar" value="Limpar"/>
	<input class="form-control-2"  type="button" name="cancela" value="Cancelar" onclick="window.location.href='admin.php'"/>
	</div>
</form>
</div>
 <div class="container"><?php include "footer.php" ?> </div> </body>
 </html>