<?php  
include_once '../conecta_banco.php';

?>
<!DOCTYPE html>
<html>
<head>
	<title>Limpar tabelas banco</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	 <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/estiloform.css" type="text/css"/>
	 <script type="text/javascript">
	  
 function validacao() {

if(document.form.altera.value=="Selecione...")
{
alert("Por favor informe sua escolha.");
document.form.altera.focus();
return false;
}

if(document.form.backup.value=="Selecione...")
{
alert("Por favor informe sua escolha .");
document.form.backup.focus();
return false;
}
}
</script>
</head>
<body>
	<div class="container">
<form name="form" method="POST" action="exec_reset_banco.php" onSubmit="return validacao();">
	
	<div class="form-group">
	<fieldset class="grupo">
	<label>Tem certeza que quer limpar as tabelas do banco</label>
	<?php 
	$query = mysqli_query($mysqli, "SELECT * FROM condicao");
?>
 <label class="form-control" for="" >Confirme sua opção</label>
 <select class="form-control" name="altera">
 <option class="form-control" name="">Selecione...</option>
 <?php 
 while($busca = mysqli_fetch_array($query)) { 
 ?>
 <option class="form-control"   value="<?php 
 echo $busca['idc'] 
 ?>">
 <?php 
 echo $busca['condicao']
 ?></option>
 <?php } ?>
 </select>
</div>

 <div class="form-group">
	<label>Tem backup das tabelas do banco</label>
	<?php 
	$queryb = mysqli_query($mysqli, "SELECT * FROM condicao");
?>
 <label class="form-control" for="" >Confirme sua opção</label>
 <select class="form-control" name="backup">
 <option class="form-control" name="">Selecione...</option>
 <?php 
 while($buscab = mysqli_fetch_array($queryb)) { 
 ?>
 <option class="form-control"   value="<?php 
 echo $buscab['idc'] 
 ?>">
 <?php 
 echo $buscab['condicao']
 ?></option>
 <?php } ?>
 </select>
 </div>
 </fieldset>
 <fieldset class="grupo">
 <div class="form-group">
<input class="form-control-2"  type="submit"  value="Executar" name="Executar"/>
<input class="form-control-2"  type="reset"  value="Limpar" name="limpa"/>
<input class="form-control-2"  type="button" name="cancela" value="Cancelar" onclick="window.location.href='admin.php'"/>
</div>
</fieldset>
</form>
</div>
</body>
</html>