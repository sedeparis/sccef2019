<?php
session_start();
if((!isset ($_SESSION['email']) == true) and (!isset ($_SESSION['senha']) == true))
{
  unset($_SESSION['email']);
  unset($_SESSION['senha']);
  header('location:../index.php');
  }
 
$logado=$_SESSION['email'];
echo '<div class="container">';
echo 'Acessado como:  '.$logado;
echo '</div>';
include_once ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../img/icone_barra.jpg" />
	 <title>cadastro de setor</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	 <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/estiloform.css" type="text/css"/>
	 <script type="text/javascript">
	  function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
 function validacao() {

if(document.form.setor.value=="")
{
alert("Por favor informe o nome do setor.");
document.form.setor.focus();
return false;
}
}

</script>
 </head>
	 <body>
	 <div class="container"><?php include "topo.php"; echo 'Usuário Logado: '; echo $logado; ?> 
	 </div>
	 <div class="container">
	<h2 class="form-nome">Cadastro de setor</h2>
	<form name="form" method="post" action="salva/salva_setor.php" onSubmit="return validacao();"> 
	<fieldset class="grupo">
		  <div class="form-group">
			<label class="form-control">Setor:</label>
<input class="form-control" type="text" name="setor" size="60"/>
	</div>
	</fieldset>
	<fieldset class="grupo">
		  <div class="form-group">
	<input class="form-control-2"  type="submit" name="enviar" value="Cadastrar setor"/>
	<input class="form-control-2"  type="submit" name="limpar" value="Limpar"/>
	<input class="form-control-2"  type="button" name="cancela" value="Cancelar" onclick="window.location.href='admin.php'"/>
	</div>
</form>
</div>
 <?php include "footer.php" ?>
 </body>
 </html>