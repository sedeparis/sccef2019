<?php include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Salva alterar orgão padrão .</title>
<!-- BOOTSTRAP STYLES-->
    <link href="../../css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../../css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../../css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
</head>
<body>
<div class="container">
<p class="center"><img src="../../img/salva.gif"/></p>
<br>
<br>
<?php
$idorgao=$_POST['idorgao'];	
	$uasg=$_POST['uasg'];
		$nome=$_POST['nome'];
		$endereco=$_POST['endereco'];
		$cidade=$_POST['cidade'];
		$uf=$_POST['uf'];
		$email=$_POST['email'];
		$fone=$_POST['fone'];
		$gestor=$_POST['gestor'];
		$diretor=$_POST['diretor'];
		$fonte=$_POST['fonte'];
		

$sql = mysqli_query($mysqli, "UPDATE cdorgao SET uasg ='$uasg', nome ='$nome',  endereco ='$endereco', cidade ='$cidade', uf ='$uf', 
 email ='$email', fone ='$fone', gestor ='$gestor', diretor ='$diretor', fonte ='$fonte' WHERE idorgao ='$idorgao'");
$resultado = mysqli_query ($mysqli, $sql);
{echo " Orgão alterado com sucesso!";
}
?>
<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='3;URL=../admin.php'>";
?>
</div>
<?php
include "footer.php";
?>
</body>
</html>