<?php 
include "../../conecta_banco.php";
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<title>Cadastro do Órgão</title>
<!-- BOOTSTRAP STYLES-->
    <link href="../../css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../../css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../../css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
</head>
<body>
<div class="container">
<?php
$uasg=$_POST['uasg'];
$nome=$_POST['nome'];
$endereco=$_POST['endereco'];
$cidade=$_POST['cidade'];
$uf=$_POST['uf'];
$email=$_POST['email'];
$fone=$_POST['fone'];
$gestor=$_POST['gestor'];
$diretor=$_POST['diretor'];
$fonte=$_POST['fonte'];


 $pesq = ( "SELECT * FROM cdorgao where orgao_principal = 'S'");
$result = mysqli_query($mysqli, $pesq);
if (mysqli_num_rows($result) > 0) {
   echo "Órgao padrão ja cadastrado. Use alterar orgão padrão";

} else {
$sql = mysqli_query($mysqli, "INSERT INTO cdorgao(uasg, nome, endereco, cidade, uf, email,  fone, gestor, diretor, fonte,  orgao_principal)
VALUES('$uasg','$nome', '$endereco', '$cidade', '$uf', '$email', '$fone', '$gestor', '$diretor', '$fonte',  'S')");
$resultado = mysqli_query ($mysqli, $sql);
{echo "Cadastro efetuado com sucesso!";}
}
?>
</div>
<p class="center"><img src="../../img/salva.gif"/></p>
<br />
<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='3;URL=../admin.php'>";
?>
</div>
<?php
include "footer.php";
?>
</body>
</html>