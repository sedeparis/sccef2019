<?php
$servidor = 'localhost';
$user = 'root';
$password = '';
$banco = 'test';
// Conecta-se ao banco de dados MySQL
$mysqli = new mysqli($servidor, $user, $password, $banco);
// Caso algo tenha dado errado, exibe uma mensagem de erro
if (mysqli_connect_error()) trigger_error(mysqli_connect_error());
mysqli_set_charset( $mysqli, 'utf8');
?>
 

 
<!DOCTYPE html>
<html>
<head>
	<title>reset</title>
</head>
<body>
	<?php 
$resposta=$_POST['altera'];
$respostab=$_POST['backup'];

$resultado = $resposta + $respostab;
echo $resultado;
if ($resultado<=3){
	
header('location:../index.php');
}
	 ?>
<?php
//limpa cadcompras
$sql = "truncate cadcompras";
 $res = mysqli_query($mysqli, $sql);
 echo 'limpa cadacompras';
 echo '<br>';
?>


<?php
//limpa fornecedor
$sql = "truncate cadfornecedor";
 $res = mysqli_query($mysqli, $sql);
 echo 'limpo fornecedor';
  echo '<br>';
?>

<?php
//limpa banco
$sql = "truncate cdbanco";
 $res = mysqli_query($mysqli, $sql);
 echo 'limpa banco';
?>
<br>
<?php
//limpa requisitante
$sql = "truncate cdrequisitante";
 $res = mysqli_query($mysqli, $sql);
 echo 'limpa requisitante';
?>
<br>
<?php
//limpa servidor
$sql = "truncate cdservidor";
 $res = mysqli_query($mysqli, $sql);
 echo 'limpa servidor';
?>
<br>
<?php
//limpa cdsetor
$sql = "truncate cdsetor";
 $res = mysqli_query($mysqli, $sql);
 echo 'limpa setor';
?>
<br>
<!--//limpa bloco estoque 1-->
<?php
//limpa entrada_produto
$sql = "truncate entrada_produto";
 $res = mysqli_query($mysqli, $sql);
 echo 'limpa entrada produto';
?>
<br>
<?php
//limpa saida_produto
$sql = "truncate saida_produto";
 $res = mysqli_query($mysqli, $sql);
 echo 'limpa saida produto';
?>
<br>
<?php
//limpa estoque
$sql = "truncate estoque";
 $res = mysqli_query($mysqli, $sql);
 echo 'limpa estoque';
?>
<br>
<!--//limpa bloco estoque 2-->
<?php
//limpa bloco estoque 2
$sql = "truncate entrada_produto_ie";
 $res = mysqli_query($mysqli, $sql);
 echo 'limpa entrada produto';
?>
<br>
<?php
//limpa saida_produto
$sql = "truncate saida_produto_ie";
 $res = mysqli_query($mysqli, $sql);
 echo 'limpa saida produto';
?>
<br>
<?php
//limpa estoque
$sql = "truncate estoque_ie";
 $res = mysqli_query($mysqli, $sql);
 echo 'limpa estoque';
?>
<br>
<!--//limpa bloco estoque 3-->
<?php

$sql = "truncate entrada_produto_ee";
 $res = mysqli_query($mysqli, $sql);
 echo 'limpa entrada produto';
?>
<br>
<?php
//limpa saida_produto
$sql = "truncate saida_produto_ee";
 $res = mysqli_query($mysqli, $sql);
 echo 'limpa saida produto';
?>
<br>
<?php
//limpa estoque
$sql = "truncate estoque_ee";
 $res = mysqli_query($mysqli, $sql);
 echo 'limpa estoque';
?>
<br>
<?php
//limpa produto
$sql = "truncate produto";
 $res = mysqli_query($mysqli, $sql);
 echo 'limpa produto';
?>
<br>


</body>
</html>

