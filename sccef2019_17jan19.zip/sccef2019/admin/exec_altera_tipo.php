<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../img/icone_barra.jpg" />
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema Administrativo compras públicas.</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   
	    
		<!--- scripts de validação de formulário --->
  <script type="text/javascript">
	 function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
 
 function validacao() {

if(document.form.tipo.value=="")
{
alert("Por favor informe o tipo de processo.");
document.form.tipo.focus();
return false;
}
}
	 </script>
</head>
 <body> <div class="container"> 
 <?php include "topo.php"; echo 'Usuário logado: ';  echo $logado; ?>
 </div>
	 
	 <div class="container">
<h2>Alterar tipo de processo</h2>
<?php
$altera=$_POST['altera'];
// cria a instrução SQL que vai selecionar os dados
$query = sprintf("SELECT * FROM cadtipo WHERE idtipo ='$altera'");
// executa a query
$dados = mysqli_query($mysqli, $query) ;
// transforma os dados em um array
$linha = mysqli_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysqli_num_rows($dados);
?>
<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($total > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
?>
<form method="post" action="salva/salva_altera_tipo.php" name="form" onSubmit="return validacao();"> 
<fieldset class="grupo">
		 <div class="campo">
<label class="form-control">Alterar tipo de processo: </label>
<input type="text" class="form-control" size="17" name="tipo" value="<?php print $linha['tipo']?>" />  
</div>
</fieldset>	
				<div class="campo">
				<input type="hidden"  size="10" name="idtipo" value="<?php print $linha['idtipo']?>" />  
<input type="submit" nome="setor" value="Alterar tipo" /> 
<input type="reset" nome="alterar" value="Limpar"/> 
 <input type="button" name="cancela" value="Cancelar" onclick="window.location.href='admin.php'"/>
 </div>
</fieldset>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = mysqli_fetch_assoc($dados));
	// fim do if 
	}
?>
<?php
// tira o resultado da busca da memória
mysqli_free_result($dados);
?>
</form>
</div>
</div>
<?php include "footer.php"; ?> 
 </body>
</html>
