<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
     <link rel="icon" type="image/jpg" href="../img/icone_barra.jpg" />
    <title>Sistema Administrativo compras públicas.</title>
	 <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<!-- BOOTSTRAP STYLES-->
    <link href="../css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   
	    
		<!--- scripts de validação de formulário --->
</head>
<body> 
<div class="container"> <?php include "topo.php"; echo 'Usuário logado: ';  echo $logado; ?> </div>
	 <div class="container">
<h2>Alterar orgão Principal</h2>
<?php
$altera=$_POST['altera'];
// cria a instrução SQL que vai selecionar os dados
$query = sprintf("SELECT * FROM cdorgao WHERE idorgao ='$altera'");
// executa a query
$dados = mysqli_query($mysqli, $query) ;
// transforma os dados em um array
$linha = mysqli_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysqli_num_rows($dados);
?>

<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($total > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
		$idorgao=$linha['idorgao'];
		$uasg=$linha['uasg'];
		$nome=$linha['nome'];
		$endereco=$linha['endereco'];
		$cidade=$linha['cidade'];
		$uf=$linha['uf'];
		$email=$linha['email'];
		$fone=$linha['fone'];
		$gestor=$linha['gestor'];
		$diretor=$linha['diretor'];
		$fonte=$linha['fonte'];
		
		
?>
<form name="form_altera" method="post" action="salva/salva_altera_orgao_padrao.php">
<fieldset class="grupo">
		 <div class="campo">
<input type="hidden" name="idorgao" value="<?php print $linha['idorgao']?>"/>
<label class="form-control">Uasg: </label> 
<input type="text" class="form-control"  size="8" name="uasg" value="<?php print "$uasg"?>"/> 
<label class="form-control">Nome: </label>
<input type="text" class="form-control"  size="60" name="nome" value="<?php print "$nome" ?>"/> 
	</div>
	</fieldset>
<fieldset class="grupo">
		 <div class="campo">
<label class="form-control">Endereço: </label>
<input type="text" class="form-control" size="60" name="endereco" value="<?php print "$endereco" ?>"/> 
</div>
<div class="campo">
 <label class="form-control">Cidade: </label>
<input type="text" class="form-control" size="35" name="cidade" value="<?php echo "$cidade" ?>"/> 
</div>
<div class="campo">
 <label class="form-control">UF: </label>
<input type="text" class="form-control" size="2" name="uf" value="<?php print "$uf" ?>"/> 
</div>
<div class="campo">
 <label class="form-control">Email: </label> 
<input type="text" class="form-control" size="15" name="email" value="<?php print "$email" ?>"/>
</div>
<div class="campo">
<label class="form-control">Fone: </label>
<input type="text" class="form-control" size="10" name="fone" value="<?php print "$fone" ?>"/>
</div>
<div class="campo">
<label class="form-control">Gestor Financeiro: </label>
<input type="text" class="form-control" size="40" name="gestor" value="<?php print "$gestor" ?>"/>
</div>
<div class="campo">
<label class="form-control">Ordenador de Despesas: </label>
<input type="text" class="form-control" size="40" name="diretor" value="<?php print "$diretor" ?>"/>
</div>
<div class="campo">
<label class="form-control">Fonte Pagadora: </label>
<input type="text" class="form-control" size="5" name="fonte" value="<?php print "$fonte" ?>"/>
</div>
	</fieldset>
 <input type="submit" value="Alterar órgao" name="alteraorgao"/>
  <input type="reset" name="Limpar" value="Limpar" />
		 <input type="button" name="cancela" value="Cancelar" onclick="window.location.href='../admin/admin.php'"/>
 </div>

<?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = mysqli_fetch_assoc($dados));
	// fim do if 
	}
?>
<?php
// tira o resultado da busca da memória
mysqli_free_result($dados);
?>
</form>
</div>
<div class="container">
 <?php include "footer.php"; ?> 
 </div> 
 </body>
</html>
