﻿<?php
session_start();
if((!isset ($_SESSION['email']) == true) and (!isset ($_SESSION['senha']) == true))
{
  unset($_SESSION['email']);
  unset($_SESSION['senha']);
  header('location:../index.php');
  }
 
$logado=$_SESSION['email'];
echo '<div class="container">';
echo 'Acessado como:  '.$logado;
echo '</div>';
include_once ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../img/icone_barra.jpg" />
	 <title>Alterar tipo de processo</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	 <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/estiloform.css" type="text/css"/>
	  	 <script type="text/javascript">
	  function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
 function validacao() {

if(document.form.altera.value=="")
{
alert("Por favor informe o tipo de processo.");
document.form.altera.focus();
return false;
}
}
</script> 
 </head>
	 <body> <div class="container"
	 ><?php include "topo.php"; echo 'Usuário Logado: '; echo $logado; ?>
	 </div>
	 <!-------- inicia pagina-------------->
	
	 <div class="container">
	<h2 class="form-nome">Alterar tipo de processo</h2>
<form method="POST" action="exec_altera_tipo.php" name="form" onSubmit="return validacao();"> 
	<fieldset class="grupo">
		 <div class="form-group">
	<?php 
	$query = mysqli_query($mysqli, "SELECT * FROM cadtipo");
?>
 <label class="form-control" for="">Selecione o tipo</label>
 <select class="form-control" name="altera">
 <option class="form-control" name="">Selecione...</option>
 <?php 
 while($busca = mysqli_fetch_array($query)) { 
 ?>
 <option class="form-control"   value="<?php 
 echo $busca['idtipo'] 
 ?>">
 <?php 
 echo $busca['tipo']
 ?></option>
 <?php } ?>
 </select>
 </div>
 </fieldset>
 <fieldset class="grupo">
 <div class="form-group">
<input class="form-control-2"  type="submit"  value="Buscar Tipo" name="Localizar"/>
<input class="form-control-2"  type="reset"  value="Limpar" name="limpa"/>
<input class="form-control-2"  type="button" name="cancela" value="Cancelar" onclick="window.location.href='admin.php'"/>
</div>
</fieldset>
</form>
</div>
<?php include "footer.php" ?>  </body>
 </html>