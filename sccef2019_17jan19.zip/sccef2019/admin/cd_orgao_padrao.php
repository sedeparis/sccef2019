<?php
session_start();
if((!isset ($_SESSION['email']) == true) and (!isset ($_SESSION['senha']) == true))
{
  unset($_SESSION['email']);
  unset($_SESSION['senha']);
  header('location:../index.php');
  }
 
$logado=$_SESSION['email'];
echo '<div class="container">';
echo 'Acessado como:  '.$logado;
echo '</div>';
include_once ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../img/icone_barra.jpg" />
	 <title>Cadastro do orgão</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	 <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/estiloform.css" type="text/css"/>
   </head>
	   <script type="text/javascript">
	   function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
 function validacao() {

if(document.form.uasg.value=="")
{
alert("Por favor informe o número de uasg.");
document.form.uasg.focus();
return false;
}

if(document.form.nome.value=="")
{
alert("Por favor informe o nome do órgão.");
document.form.nome.focus();
return false;
}
if(document.form.endereco.value=="")
{
alert("Por favor informe o endereco.");
document.form.endereco.focus();
return false;
}

if(document.form.cidade.value=="")
{
alert("Por favor informe a cidade.");
document.form.cidade.focus();
return false;
}

if(document.form.uf.value=="")
{
alert("Por favor informe o estado.");
document.form.uf.focus();
return false;
}
if(document.form.fone.value=="")
{
alert("Por favor informe o telefone do órgão.");
document.form.fone.focus();
return false;
}

if(document.form.email.value=="")
{
alert("Por favor informe o email do órgão.");
document.form.email.focus();
return false;
}

if(document.form.gestor.value=="")
{
alert("Por favor informe o nome do gestor financeiro do órgão.");
document.form.gestor.focus();
return false;
}
if(document.form.diretor.value=="")
{
alert("Por favor informe o nome do diretor do órgão.");
document.form.diretor.focus();
return false;
}

if(document.form.fonte.value=="")
{
alert("Por favor informe a fonte pagadora do órgão.");
document.form.fonte.focus();
return false;
}
if(document.form.iniprocesso.value=="")
{
alert("Por favor informe os cinco primeiros digitos do processo do órgão.");
document.form.iniprocesso.focus();
return false;
}
}
 </script>
	  <body>
	 <div class="container">
	 <?php include "topo.php"; echo 'Usuário Logado: '; echo $logado; ?> </div>
	 
	 <div class="container">
	<h1>Cadastro de Orgão</h1>
	 
	<form name="form" method="post" action="salva/salva_orgao_padrao.php" onSubmit="return validacao();"> 
	<fieldset class="grupo">
		 <div class="form-group">
	<label class="form-control">Uasg:</label>

<input type="text" class="form-control"  name="uasg" size="6" maxlength="6" />
</div>
	 <div class="form-group">
			<label class="form-control">Nome do Órgão:</label>
<input class="form-control" type="text" name="nome" size="80" requerid="requerid" title="nome"/>
</div>
	</fieldset>
	<fieldset class="grupo">
	 <div class="form-group">
		<label class="form-control">Endereço:</label>
		<input class="form-control" type="text" name="endereco" size="80" />
		</div>
				 <div class="form-group">
		<label class="form-control">Cidade:</label>
	<input class="form-control" type="text" name="cidade"/>
	</div>
	<div class="form-group">
	<label class="form-control">Estado:</label>
<input class="form-control" type="text" name="uf" size="2"  maxlength="2" />
</div>
	 <div class="form-group">
		<label class="form-control">Email:</label>
		<input class="form-control" type="text" name="email" size="30"/>
		</div>
		 <div class="form-group">
		<label class="form-control">Telefone:</label>
		<input class="form-control" type="text" name="fone" size="10" maxlength="13"  onkeypress="mascara(this, '##-####-####')" />
		 </div>
		 </fieldset>
		 <fieldset class="grupo">
		 <div class="form-group">
		<label class="form-control">Gestor Financeiro:</label>
		<input class="form-control" type="text" name="gestor" size="50"/>
		</div>
		 <div class="form-group">
	<label class="form-control">Diretor Geral:</label>
		<input class="form-control" type="text" name="diretor" size="50"/>
		</div>
		 <div class="form-group">
	<label class="form-control">Fonte pagadora:</label>
		<input class="form-control" type="text" name="fonte" size="10"/>
		</div>
		 
		</fieldset>
		 <div class="form-group">
	<input type="submit" name="enviar" value="Cadastrar Órgão"/>
	<input type="reset" name="Limpar" value="Limpar" />
		 <input type="button" name="cancela" value="Cancelar" onclick="window.location.href='admin.php'"/>
		 </div>
</form>
</div>
<?php include "footer.php" ?>
 </body>
 </html>