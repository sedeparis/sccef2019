<?php
session_start();
if((!isset ($_SESSION['email']) == true) and (!isset ($_SESSION['senha']) == true))
{
  unset($_SESSION['email']);
  unset($_SESSION['senha']);
  header('location:../index.php');
  }
 
$logado=$_SESSION['email'];
echo '<div class="container">';
echo 'Acessado como:  '.$logado;
echo '</div>';
include_once ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../img/icone_barra.jpg" />
	 <title>Alterar órgao</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	 <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/estiloform.css" type="text/css"/>
	 <script type="text/javascript">
	  function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
 function validacao() {

if(document.form.altera.value=="Selecione...")
{
alert("Por favor selecione o orgão.");
document.form.altera.focus();
return false;
}
}
	 </script>
 </head>
	  <body>
	 <div class="container">
	 <?php include "topo.php"; echo 'Usuário Logado: '; echo $logado; ?> </div>
	 
	 <div class="container">
	 
	<h2>Alterar órgao</h2>
<form name="form" method="POST" action="exec_altera_orgao_padrao.php" onSubmit="return validacao();"> 
	<fieldset class="grupo">
		 <div class="form-group">
	<?php 
	$query = mysqli_query($mysqli, "SELECT * FROM cdorgao WHERE orgao_principal= 'S'");
?>
<br />
<br />
 <label class="form-control" for="">Selecione o órgão</label>
 <select class="form-control" name="altera">
 <option class="form-control" name="">Selecione...</option>
 <?php 
 while($busca = mysqli_fetch_array($query)) { 
 ?>
 <option value="<?php 
 echo $busca['idorgao'] 
 ?>">
 <?php 
 echo $busca['nome']
 ?></option>
 <?php } ?>
 </select>
</div>
	</fieldset>
	<div class="form-group">
<input type="submit" id="submit" value="Buscar" name="Localizar"/>
<input type="submit" id="reset" value="Limpar" name="Limpar"/>
 <input type="button" name="cancela" value="Cancelar" onclick="window.location.href='admin.php'"/>
</div>
</form>
</div>
<?php include "footer.php" ?>
</body>
 </html>