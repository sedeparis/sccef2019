<?php
session_start();
$_SESSION['email'];
$_SESSION['senha'];
//header ('autenticara.php');
$logado=$_SESSION['email'];
include_once ("conecta_banco.php");
?>