﻿ <?php
 session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado com usuário: ';
echo	$logado;
	echo '</div>';
include "../../conecta_banco.php";

?>
<!DOCTYPE HTML>
<html lang="pt_br">
<head>
  <link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Lista compras por periodo</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	 <link href="../../css/print_tab.css" rel="stylesheet" />
	  <link href="../../css/print_div.css" rel="stylesheet" />
	   <link href="../../css/print_fontes.css" rel="stylesheet" />
</head>
 <body>
	 <div class="cabecalho">
	  <?php include "cabecalho.php"; ?> 
	  </div>
	 <div class="titulo">
  	 <h3>Listagem de compras por período</h3>
	 </div>
	 <div class="textos">
<?php
$datai=$_POST['datai'];
$dataf=$_POST['dataf'];
$text= 'Durante o período de';
$a= 'a';
$textb= 'foram realizadas a compra dos seguintes itens:<br>';
echo $text.' '.$datai.' a '.$dataf.' '.$textb;
?>
</div>
<div class="tabela">
<?php
//com pdo

// cria a instrução SQL que vai selecionar os dados dos itens
$sql = $mysqli ->prepare("SELECT idcompra, nitem, ditem, idfornecedor, nempenho FROM caditem WHERE data BETWEEN '$datai' AND '$dataf' AND (nempenho<>'')");
$sql->execute();
$sql->bind_result($idcompra, $nitem, $ditem, $idfornecedor, $nempenho);
echo "<table>
<thead>
<tr>
<td>Processo</td>
<td>Item</td>
<td>Descrição</td>
<td>Fornecedor</td>
<td>Empenho</td>
</tr>
</thead>

<tbody>
";

while ($sql->fetch())
{
	echo " <tr>
<td>$idcompra</td>
<td>$nitem</td>
<td>$ditem</td>
<td>$idfornecedor</td>
<td>$nempenho</td>

</tr>";
}
echo "<tbody>
</table>
";
	
?>
</div>

<div class="button">
 <input type="button" name="ok" value="Voltar" onclick="window.location.href='../painel_alm.php'"/>
</div>
<?php include "footer.php"; ?> 
</body>
</html>
