<?php 
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado com usuário: ';
echo	$logado;
	echo '</div>';
include ("../../conecta_banco.php");
?>
 <!DOCTYPE HTML>
 <html lang="pt-br">
 <head>
  <link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Receber item</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	 <link rel="stylesheet" href="../../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../../css/custom.css" type="text/css"/>
	  <link rel="stylesheet" href="../../css/bootstrap.css" type="text/css"/>
	  <script type="text/javascript">
	  function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
	 </script>
   </head>
	   <body> 
   <?php include "topo.php"; ?>
	 <div class="container">
	 <br />
	<h2 class="form-nome">Selecionar itens a receber</h2>

	<?php
	 $processo=$_POST['processo'];
$fornecedor=$_POST['fornecedor'];
$nempenho=$_POST['nempenho'];
$data= date_default_timezone_set("America/Cuiaba");
$data= date('d/m/Y');
$datarec =  str_replace("/", "-", $data);
//echo $datarec;
echo '<br>';
//seleciona dados
$queryb = "SELECT * FROM estoque_ee INNER JOIN produto
	ON estoque_ee.id_produto_ee=produto.id 
	INNER JOIN cdunidade ON produto.un=cdunidade.idun
 WHERE (fornecedora= '$fornecedor') AND idprocesso='$processo' AND (qtde_ee >0)";
 $resb = mysqli_query($mysqli, $queryb) or die(mysqli_error($mysqli));
  if (mysqli_num_rows($resb) == 0 ) {
  echo "Não há itens para receber<br>";}
  else {
  if (mysqli_num_rows($resb) > 0 ) {
  echo '<form method="post" action="../salva/salva_recebe_item.php">';
  while ( $row = mysqli_fetch_assoc($resb) )
	  {
		  echo '<hr>';
		 // echo ' ' . $row["id_produto_ee"]. '<hr>';
  echo '<span class="color">Nº do item: </span> ' . $row["nitem"]. '<br>';
  echo '<span class="color">Descrição.: </span>' . $row["descricao"]. '<br>';
  echo '<span class="color">UN: </span> ' . $row["unidade"]. '<br>';
  echo '<span class="color">Qtde. disponível: </span> ' . $row["qtde_ee"]. '<br>';
  //passar qtde, datarec,  idprodutoee
	  echo '<span class="color"> Quant. entregue: </span> <input type="text" size="5" name="qtde['.$row["id_produto_ee"].']" value=""><br />'."\n";
  echo '<input type="hidden" size="5" name="datarec['.$row["id_produto_ee"].']" value="'.$datarec.'">'."\n";
echo '<input type="hidden" size="5" name="nempenho['.$row["id_produto_ee"].']" value="'.$nempenho.'">'."\n";  
  echo '<input type="hidden" name="id_produto_ee[]" value="'.$row["id_produto_ee"].'"> '."\n";
  }
  echo '<input type="submit" name="submit" value="Receber_Fornecimento"/>';
  echo '</form>';
  }
  }
?>
 <input type="button" name="cancela" value="Cancelar" onclick="window.location.href='../painel_alm.php'"/>
 </div>
 
 <?php include "footer.php"; ?> 
 </body>
</html>