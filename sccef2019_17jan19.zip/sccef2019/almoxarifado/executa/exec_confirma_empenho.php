<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado com usuário: ';
echo	$logado;
	echo '</div>';
include "../../conecta_banco.php";
?>
 <!DOCTYPE HTML>
<html lang="pt_br">
<head>
  <link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Selecao para empenho</title>
	 <<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	 <link rel="stylesheet" href="../../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../../css/custom.css" type="text/css"/>
	 <link rel="stylesheet" href="../../css/bootstrap.css" type="text/css"/>
	  <script type="text/javascript">
	  function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
	 </script>
   </head>
	 <body>
	  <?php include "topo.php"; ?> 
	  <div class="container">
	<h2 class="form-nome">Confirmar quantidade empenho</h2>
	
<p><b>ATENÇÃO!:</b><br /><br />
	A quantidade solicitada mostrada é a quantidade máxima de itens que foi solicitada empenhar. <br />
	Caso na hora do empenho foi lançada uma outra quantidade informe agora.<br />
	</p><br />
	<?php
	$processo=$_POST['processo'];
	$nempenho=$_POST['nempenho'];
	$fornecedor=$_POST['fornecedor'];
	$dataemp= $_POST['dataemp'];
	$sql = "SELECT * FROM entrada_produto_ie INNER JOIN produto
	ON entrada_produto_ie.id_produto_ie=produto.id 
 INNER JOIN estoque_ie 
 ON estoque_ie.id_produto_ie=produto.id
 WHERE processo ='$processo' AND (fornecedor_ie= '$fornecedor')";
 $res = mysqli_query($mysqli, $sql) or die(mysqli_error($mysqli));
  if (mysqli_num_rows($res) == 0 ) {
  echo "Não há item  empenhados para esse fornecedor.";}
  else {
  if (mysqli_num_rows($res) > 0 ) {
  echo '<form method="post" action="../salva/salva_confirma_empenho.php">';
  while ( $row = mysqli_fetch_assoc($res) )
	  {
   echo '<span class="colorblue">Nº do item:</span> ' . $row["nitem"]. '<br>';
  echo 'Descrição: ' . $row["descricao"]. '<br>';
  echo 'UN: ' . $row["un"]. '<br>';
  echo 'Quant. solicitada empenho: ' . $row["qtde_ie"]. '<br />';
  echo ' Quant.  que foi empenhada: <input type="text" size="2" name="quanto['.$row["id_ie"].']" value="'.$row["qtde_ie"].'"> '."\n";
  
  echo ' <input type="hidden" size="5" name="valor['.$row["id_ie"].']" value="'.$row["valor_unitario_ie"].'"><br /> '."\n";
echo ' <input type="hidden" size="5" name="nempenho['.$row["id_ie"].']" value="'.$nempenho.'"> '."\n";
echo ' <input type="hidden" size="5" name="dataemp['.$row["id_ie"].']" value="'.$dataemp.'"> '."\n";
echo '<input type="hidden" size="5" name="fornecedor['.$row["id_ie"].']" value="'.$fornecedor.'"> '."\n"; //data post tela anterior
  echo '<input type="hidden" name="id_ie[]" value="'.$row["id_ie"].'"><br /> '."\n";
  echo "<hr>\n";
  }
  echo '<input type="submit" name="submit" value="Confirmar Empenho">';
  
  echo '</form>';
  }
  }
?>
 <input type="button" name="cancela" value="Cancelar" onclick="window.location.href='../painel_alm.php'"/>
</div>
<?php include "footer.php"; ?> 
</body>
</html>