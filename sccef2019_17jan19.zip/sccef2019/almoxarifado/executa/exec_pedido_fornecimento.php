<?php 
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado com usuário: ';
echo	$logado;
	echo '</div>';
include ("../../conecta_banco.php");
?>
  <!DOCTYPE HTML>
  <html lang="pt-br">
 <head>
 <link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Imprime pedido</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	 <link rel="stylesheet" href="../../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../../css/custom.css" type="text/css"/>
	 <link rel="stylesheet" href="../../css/bootstrap.css" type="text/css"/>
 </head>
	 <body>
	  <?php include "topo.php"; ?> 
	  <div class="container">
	 <h2 class="form-nome">Informar pedido de fornecimento</h2>
	<br />
		<br />
			<br />
 <?php
 $processo=$_POST['processo'];
$fornecedor=$_POST['fornecedor'];
$nempenho=$_POST['nempenho'];
$data= date_default_timezone_set("America/Cuiaba");
$data= date('d-m-Y');
$dataped =  $data;

echo '<br>';
//seleciona dados
$queryb = "SELECT * FROM produto INNER JOIN estoque_ie
	ON produto.id=estoque_ie.id_produto_ie 
	INNER JOIN CDUNIDADE ON produto.un=cdunidade.idun
 WHERE idprocesso ='$processo' AND (fornecedora= '$fornecedor') AND qtde_ie>0 ";
 $resb = mysqli_query($mysqli, $queryb) or die(mysqli_error($mysqli));
  if (mysqli_num_rows($resb) == 0 ) {
  echo "Não itens sem solicitar ou correspondente a este fornecedor<br>";}
  else {
  if (mysqli_num_rows($resb) > 0 ) {
  echo '<form method="post" action="../salva/salva_pedido_fornec.php">';
  while ( $row = mysqli_fetch_assoc($resb) )
	  {
		  echo ' ' . $row["id_produto_ie"]. '-';
  echo '<span class="color">Nº do item: </span> ' . $row["nitem"]. '<br>';
  echo '<span class="color">Descrição.: </span>' . $row["descricao"]. '<br>';
  echo '<span class="color">UN: </span> ' . $row["unidade"]. '<br>';
   echo '<span class="color">Quant. Disponível: </span> ' . $row["qtde_ie"]. '<br>';
	  echo '<span class="color"> Quant a solicitar: </span> <input type="text" size="5" name="qtde['.$row["id_produto_ie"].']" value="'.$row["qtde_ie"].'"><br />'."\n";
  echo '<input type="hidden" size="5" name="dataped['.$row["id_produto_ie"].']" value="'.$dataped.'"><br />'."\n";
  echo '<input type="hidden" size="5" name="nempenho['.$row["id_produto_ie"].']" value="'.$nempenho.'"><br />'."\n";
  echo '<input type="hidden" name="id_produto_ie[]" value="'.$row["id_produto_ie"].'"> '."\n";
  }
  echo '<input type="submit" name="submit" value="Salvar Sol_Fornecimento"/>';
  echo '</form>';
  }
  }
?>
<input type="button" name="cancela" value="Cancelar" onclick="window.location.href='../painel_alm.php'"/>

</div>
<?php include "footer.php"; ?> 
</body>
</html>


