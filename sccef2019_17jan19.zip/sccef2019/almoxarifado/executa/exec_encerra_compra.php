<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado com usuário: ';
echo	$logado;
	echo '</div>';
include "../../conecta_banco.php";
?>
<!DOCTYPE HTML>
<html lang="pt_br">
<head>
  <link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	<!DOCTYPE HTML>
<html lang="pt-br">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema Administrativo compras públicas.</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../../css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../../css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../../css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   
	  <script type="text/javascript">
	  function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
	 </script>
   </head>
	 <body>
  <img class="logo" src="../../img/banner.jpg">
	 <div id="tudo">
	<h2 class="form-nome">Selecionar itens para finalizar compra</h2>
	<?php

?>
<p><b>ATENÇÃO!:</b><br /><br />
	A quantidade recebida mostrada é a quantidade que o fornecedor entregou. <br />
	Caso for diferente da quantidade licitada e não deseje mais receber os bens encerre a compra do item.
	Do contrário, marque só os itens que queira encerrar ou cancele a ação clicando em Cancelar.
	</p><br />
	<?php
	$une = " - ";
	$processo=$_POST['processo'];
	$fornecedor=$_POST['fornecedor'];
	$data= date("d/m/Y");
 $sql = "SELECT * from caditem WHERE idcompra = '$processo' AND(idfornecedor LIKE '%$fornecedor%')";
 $res = @mysql_query($sql) or die(mysql_error());
  if (mysql_num_rows($res) == 0 ) {
  echo "Não há item para empenhar. <a href='../painel_alm.php'>Voltar</a>";}
  else {
  if (mysql_num_rows($res) > 0 ) {
  echo '<form method="post" action="../salva/salva_encerra_compra.php">';
  while ( $row = mysql_fetch_assoc($res) )
	  {
  echo 'Nº item: ' . $row["nitem"]. '-';
  echo ' ' . $row["ditem"]. '-';
  echo 'Quant licitada: ' . $row["quant_lic"]. '-';
  echo 'Quant recebida: ' . $row["recebido"]. '<br />';
   echo '<b>Finalizar item: '."\n";
  echo '<b>Sim:</b><input type="radio"  name="finaliza['.$row["iditem"].']" value="1"> '."\n";
  echo '<b>Não:</b><input type="radio"  name="finaliza['.$row["iditem"].']" value="0" checked="checked"> '."\n";
  echo '<input type="hidden" name="iditem[]" value="'.$row["iditem"].'"> '."\n";
  echo "<hr>\n";
  }
  echo '<input type="submit" name="submit" value="Finalizar itens">';
   echo '';
  echo '</form>';
  }
  }
?><input type="button" name="cancela" value="Cancelar" onclick="window.location.href='../painel_alm.php'"/>
</div>
<?php include "footer.php"; ?> 
</body>
</html>