﻿<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado com usuário: ';
echo	$logado;
	echo '</div>';
include "../../conecta_banco.php";

?>
<!DOCTYPE HTML>
<html lang="pt_br">
<head>
  <link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<title>relatórios</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		 <link href="../../css/print_tab.css" rel="stylesheet" />
	  <link href="../../css/print_div.css" rel="stylesheet" />
	   <link href="../../css/print_fontes.css" rel="stylesheet" />
</head>
 <body>
	 <div class="cabecalho">
	  <?php include "cabecalho.php"; ?> 
	  </div>
	 <div class="titulo">
	  <h3>Lista validade da compra</h3>
	  </div>
<?php
$datai=$_POST['datai'];
$dataf=$_POST['dataf'];
?>
<div class="tabela">
<?php
//com pdo

// cria a instrução SQL que vai selecionar os dados dos itens
$sql = $mysqli ->prepare("SELECT idcompra, nitem, ditem, idfornecedor, quant_lic, data FROM caditem WHERE data BETWEEN '$datai' AND '$dataf'");
$sql->execute();
$sql->bind_result($idcompra, $nitem, $ditem, $idfornecedor, $quant_lic, $data);
echo "<table>
<thead>
<tr>
<td>Processo</td>
<td>Item</td>
<td>Descrição</td>
<td>Fornecedor</td>
<td>Lic</td>
<td>Validade</td>
</tr>
</thead>

<tbody>
";

while ($sql->fetch())
{
	echo " <tr>
<td>$idcompra</td>
<td>$nitem</td>
<td>$ditem</td>
<td>$idfornecedor</td>
<td>$quant_lic</td>
<td>$data</td>
</tr>";
}
echo "<tbody>
</table>
";

?>
</div>
<div class="button">
 <input type="button" name="ok" value="Voltar" onclick="window.location.href='../painel_alm.php'"/>
</div>
<?php include "footer.php"; ?> 
</body>
</html>

