<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado com usuário: ';
echo	$logado;
	echo '</div>';
include "../../conecta_banco.php";
?>
  <!DOCTYPE HTML><html lang="pt-br">
 <head>
 <link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Confirmar empenho</title>
	 <<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	 <link rel="stylesheet" href="../../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../../css/custom.css" type="text/css"/>
	 <link rel="stylesheet" href="../../css/bootstrap.css" type="text/css"/>
	  <script type="text/javascript">
	  function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
	 </script>
   </head>
	 <body>
	  <?php include "topo.php"; ?> 
	  <div class="container">
	<h2 class="form-nome">Informar data e número do empenho</h2>
	
<p><b>ATENÇÃO!:</b><br />
	
	Marque o item cujo empenho informado corresponde.<br />
	</p><br />
	<?php
	$processo=$_POST['processo'];
	$nempenho=$_POST['nempenho'];
	$fornecedor=$_POST['fornecedor'];
	$dataemp= $_POST['dataemp'];
	$datareq= $_POST['datareq'];
	
	//echo $processo.'<br>'; echo $nempenho.'<br>';echo $fornecedor.'<br>';echo $dataemp.'<br>'; echo $datareq.'<br>';
	$sql = "SELECT * FROM entrada_produto_ie INNER JOIN produto
	ON entrada_produto_ie.id_produto_ie=produto.id 
	INNER JOIN cdunidade ON produto.un=cdunidade.idun
 WHERE idprocesso ='$processo' AND (fornecedora= '$fornecedor') AND data_entrada_ie = '$datareq' AND (nempenho ='')";
 $res = mysqli_query($mysqli, $sql) or die(mysqli_error($mysqli));
  if (mysqli_num_rows($res) == 0 ) {
  echo "Número de empenho já informado ou data de solicitação errada.";}
  else {
  if (mysqli_num_rows($res) > 0 ) {
  echo '<form method="post" action="../salva/salva_informa_nempenho.php">';
  while ( $row = mysqli_fetch_assoc($res) )
	  {
		   echo ' ' . $row["id_produto_ie"]. '-'; // mostra id oculta
   echo '<span class="colorblue">Nº do item:</span> ' . $row["nitem"]. '<br>';
  echo 'Descrição: ' . $row["descricao"]. '<br>';
  echo 'UN: ' . $row["unidade"]. '<br>';
  echo 'Quant. solicitada empenho: ' . $row["qtde_ie"]. '<br />';
    echo  '<span class="colorc">O empenho informado é correspondente ao item?  </span> Sim <input type="radio" name="radio['.$row["id_produto_ie"].']" value="'.'1'.'"> '."\n";
 echo '<span class="color">       &emsp;     &emsp;   Não</span> <input type="radio" checked="checked" name="radio['.$row["id_produto_ie"].']" value="'.'0'.'"> '."\n";
  echo ' <input type="hidden" size="5" name="nempenho['.$row["id_produto_ie"].']" value="'.$nempenho.'"> '."\n";
echo ' <input type="hidden" size="5" name="dataemp['.$row["id_produto_ie"].']" value="'.$dataemp.'"> '."\n";
echo ' <input type="hidden" size="5" name="datareq['.$row["id_produto_ie"].']" value="'.$datareq.'"> '."\n";
  echo '<input type="hidden" name="id_produto_ie[]" value="'.$row["id_produto_ie"].'"><br /> '."\n";
  echo "<hr>\n";
  }
  echo '<input type="submit" name="submit" value="Confirmar Empenho">';
  
  echo '</form>';
  }
  }
?>
 <input type="button" name="cancela" value="Cancelar" onclick="window.location.href='../painel_alm.php'"/>
</div>
<?php include "footer.php"; ?> 
</body>
</html>