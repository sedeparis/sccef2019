﻿<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: ';
	echo  $logado;
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema Administrativo compras públicas.</title>
	 <link href="../../css/print_tab.css" rel="stylesheet" />
	  <link href="../../css/print_div.css" rel="stylesheet" />
	   <link href="../../css/print_fontes.css" rel="stylesheet" />
   
	    
		<!--- scripts de validação de formulário --->
 </head>
	 <body> 
	 <div class="cabecalho">
	  <?php include "cabecalho.php"; ?> 
	  </div>
	 <div class="titulo">
	 <h3>Listagem de itens com data pedido de empenho</h3>
	 </div>
	 <div class="tabela">

<?php
//tras dados da pagina anterior
$processo=$_POST['processo'];
// cria a instrução SQL que vai selecionar os dos itens
$queryb = ("SELECT * FROM produto 
INNER JOIN cadcompras 
ON cadcompras.idcompra = produto.idprocesso
INNER JOIN entrada_produto_ie
 ON entrada_produto_ie.id_produto_ie = produto.id
 INNER JOIN cadfornecedor
 ON cadfornecedor.idforn = produto.fornecedora
 WHERE idprocesso = '$processo'");
// executa a query
$dados = mysqli_query ($mysqli, $queryb);
// transforma os dados em um array
$linha = mysqli_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysqli_num_rows($dados);
?>


<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($total > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
//$id =$linha['id_produto'];
$nitem = $linha['nitem'];
$ditem= $linha['descricao'];
$fornec= $linha['nome'];
$data= $linha['data_entrada_ie'];

 ?>
<table>
<colgroup>
<col width="05%">
<col width="35%">
<col width="35%">
<col width="10%">
</colgroup>
<thead>
<tr>
<th>Item</th>
<th>Descrição</th>
<th>Fornecedor</th>
<th>Data</th>
</tr>
</thead>
<tbody>
<tr>
<td><?php echo $nitem ?></td>
<td><?php echo $ditem ?></td>
<td><?php echo $fornec ?></td>
<td><?php echo $data ?></td>
</tr>
</tbody>
</table>

<?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = mysqli_fetch_assoc($dados));
	// fim do if 
	}
?>

<?php
// tira o resultado da busca da memória
mysqli_free_result($dados);
?>
</div>
<br />
<div class="button">
<input type="button" name="voltar" value="Voltar" onclick="window.location.href='../painel_alm.php'"/>
</div>
	</div>

	 </body>
	</html>