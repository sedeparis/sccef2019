<?php 
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado com usuário: ';
echo	$logado;
	echo '</div>';
include ("../../conecta_banco.php");
?>
 <!DOCTYPE HTML>
<html lang="pt_br">
<head>
  <link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Alterar quantidade espelho empenho</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	 <link rel="stylesheet" href="../../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../../css/custom.css" type="text/css"/>
	  <link rel="stylesheet" href="../../css/bootstrap.css" type="text/css"/>
	<link rel="stylesheet" href="../../css/print_fontes.css" type="text/css"/>
	  <script type="text/javascript">
	  function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
	 </script>
   </head>
	 <body>
   <div class="container">
	  <?php include "topo.php"; ?> 
	  </div>
	 <div class="container">
	<h2 class="form-nome">Selecionar itens para alterar solicitação de empenho</h2>
<p>ATENÇÃO!:<br /><br />
	A quantidade mostrada é a quantidade do item que foi informado para empenho
	 no campo "Quantidade solicitada para empenho".<br />
	Ao marcar sim essa quantidade será excluida e deverás informar novamente em "Quant a empemhar" para gerar o espelho de empenho.</p>
	<p class="inf">Somente será permitida essa operação para itens que o cujo número de empenho não foi informado.</p>
	<br />
	</div>
	 <div class="container">
	<?php
	$processo=$_POST['processo'];
	$fornecedor=$_POST['fornecedor'];
$date= $_POST['data'];
echo $date;
//var_dump($date);
$data =  str_replace("/", "-", $_POST["data"]);
echo $data;
 $sql = "SELECT * FROM produto 
 INNER JOIN saida_produto ON produto.id=saida_produto.id_produto
 inner join cdunidade on produto.un=cdunidade.idun
 WHERE idprocesso ='$processo' AND (fornecedora= '$fornecedor') AND qtde > 0 AND (data_saida= '$data') AND nempenho= ''";
 $res = mysqli_query($mysqli, $sql) ;
  if (mysqli_num_rows($res) == 0 ) {
  echo "Não há item com possibilidade de alteração. <a href='../painel_alm.php'>Voltar</a>";}
  else {
  if (mysqli_num_rows($res) > 0 ) {
  echo '<form method="post" action="../salva/salva_exclui_empenha.php">';
  while ( $row = mysqli_fetch_assoc($res) )
	  {
		  //dados mostrados
  echo ' ' . $row["id_produto"]. '-'.'<br>'; // mostra id oculta
 echo 'Nº do item na Compra: ' . $row["nitem"]. '<br>'; // numero do item
  echo 'Descrição: ' . $row["descricao"]. '<br>'; // descrição do item
  echo 'UN: '  .$row["unidade"]. '<br>'; // quantidade licitada do item e a unidade
  echo 'Quantidade solicitada para empenho: ' . $row["qtde"]. '<br>'; // quantidade disponivel para empenhar do item
//repassar para outras telas
   
   echo  '<span class="colored">     Atenção!!: Pretende excluir a quantidade marcada para empenho anteriormente? <br>';
   echo '<span class="colorblue">  &emsp; Sim </span> <input type="radio" name="radio['.$row["id_produto"].']" value="'.'1'.'"> '."\n";
 echo '<span class="color">       &emsp;     &emsp;   Não</span> <input type="radio" checked="checked" name="radio['.$row["id_produto"].']" value="'.'0'.'"> '."\n";
   echo '<input type="hidden" size="5" name="data['.$row["id_produto"].']" value="'.$data.'"> '."\n"; //data post tela anterior
    echo '<input type="hidden" name="id_produto[]" value="'.$row["id_produto"].'"> '."\n";  // id do item
  echo "<hr>\n";
  }
  echo '<input type="submit" name="submit" value="Excluir quantidade Empenhar">';
   echo '';
  echo '</form>';
  }
  }
?>
<input type="button" name="cancela" value="Cancelar" onclick="window.location.href='../painel_alm.php'"/>
</div>

<?php include "footer.php"?>

</body>
</html>