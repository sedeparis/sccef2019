<?php 
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como:';
	echo  $logado .'</div>';
include "../../conecta_banco.php";
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<title>Cadastro empenho</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="../../css/reset.css" type="text/css"/>
<link rel="stylesheet" href="../../css/estilo.css" type="text/css"/>
<link rel="stylesheet" href="../../css/bootstrap.css" type="text/css"/>
</head>
<body>
<div class="container">
<p class="center"><img src="../../img/salva.gif"/></p>
<p class="center"><img src="../../img/moldura.gif"/></p>
<?php
if ( isset($_POST["submit"]))	{
echo '<pre>';
print_r($_POST);
echo '</pre>';
foreach($_POST["id_produto_ie"] AS $id_produto_ie){
echo 'id_produto_ie is '. $id_produto_ie . '<br />';//id_produto_ie do item
echo 'radio is ' . $_POST["radio"][$id_produto_ie]."<br />";
echo 'dataemp is ' . $_POST["dataemp"][$id_produto_ie]."<br />";// data
echo 'datareq is ' . $_POST["datareq"][$id_produto_ie]."<br />";// datareq
echo 'nempenho ' . $_POST["nempenho"][$id_produto_ie]."<br />";// empenho

 $radio = mysqli_real_escape_string($mysqli, $_POST["radio"][$id_produto_ie]);
$dataemp = mysqli_real_escape_string($mysqli, $_POST["dataemp"][$id_produto_ie]); // data do empenho
$datareq = mysqli_real_escape_string($mysqli, $_POST["datareq"][$id_produto_ie]); // data req emepnho
$nempenho = mysqli_real_escape_string($mysqli, $_POST["nempenho"][$id_produto_ie]); // nempenho
//informa mpenho na table a entrada produto

if ($radio <> 1) {
   echo 'item não selecionado<br />';

} else {
$sql = ("UPDATE entrada_produto_ie SET nempenho= '$nempenho', data_empenho_ie= '$dataemp' 
WHERE id_produto_ie = '$id_produto_ie'
 AND data_entrada_ie = '$datareq'");
$resultado = mysqli_query($mysqli, $sql);
{echo 'Itens atualizados e saidos do estoque II!<br><br>';}


//insere numero do empenho na tabela saida_produto para impedir que no alterar quantidade de empenho se altere itens já empenhados
$sqlb = ("UPDATE saida_produto SET nempenho= '$nempenho', data_empenho= '$dataemp' 
WHERE id_produto = '$id_produto_ie' AND data_saida = '$datareq'");
$resultadob = mysqli_query($mysqli, $sqlb);
{echo 'Itens atualizados e saidos do estoque Ii!<br><br>';}
}
}
}
?>
<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='3;URL=../painel_alm.php'>";
?>

</div>
<?php include "footer.php"; ?>
</body>
</html>