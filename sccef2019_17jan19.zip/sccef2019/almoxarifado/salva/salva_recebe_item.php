<?php 
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include ("../../conecta_banco.php");
?>
 <!DOCTYPE HTML>
 <html lang="pt-br">
 <head>
 <link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Receber item</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	 <link rel="stylesheet" href="../../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../../css/custom.css" type="text/css"/>
	  <link rel="stylesheet" href="../../css/bootstrap.css" type="text/css"/>
   </head>
	 <body>
	  <div class="container">
	   <p class="center"><img src="../../img/salva.gif"/></p>
	 <p class="center"><img src="../../img/moldura.gif"/></p>
<?php
if ( isset($_POST["submit"]))	{
echo '<p><pre></p>';
		print_r($_POST);
		echo '<p></pre></p>';
		foreach($_POST["id_produto_ee"] AS $id_produto_ee){
			echo '<p>id_produto_ee is '. $id_produto_ee. '<br /></p>';//passar qtde, datarec,, idprodutoee
			echo '<p>qtde is ' . $_POST["qtde"][$id_produto_ee]."</p><br />";
			 echo '<p>datarec is ' . $_POST["datarec"][$id_produto_ee]."</p><br />";
				 echo '<p>nempenho is ' . $_POST["nempenho"][$id_produto_ee]."</p><br />";
				 
			  $qtde = mysqli_real_escape_string($mysqli, $_POST["qtde"][$id_produto_ee]);
			$datarec= mysqli_real_escape_string($mysqli, $_POST["datarec"][$id_produto_ee]);
			$nempenho= mysqli_real_escape_string($mysqli, $_POST["nempenho"][$id_produto_ee]);
			
	//sai produtos do estoque de fornecimento
$sql = ("INSERT INTO saida_produto_ee(id_produto_ee, qtde_ee, data_saida_ee, nempenho_ee)
VALUES('$id_produto_ee', '$qtde', '$datarec', '$nempenho')");
$resultado = mysqli_query($mysqli, $sql);
{echo 'Itens recebidos !<br><br>';}
	}
	}
	echo "<meta HTTP-EQUIV='refresh' CONTENT='3;URL=../painel_alm.php'>";
	?>

	</div>
	<?php include "footer.php"; ?>
	</body>
	</html>