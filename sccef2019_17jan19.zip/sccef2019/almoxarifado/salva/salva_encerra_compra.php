 <?php 
 session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include "../../conecta_banco.php";
?>
 <!DOCTYPE HTML>
 <html lang="pt-br">
 <head>
 <link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Finalizar compra</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	  <link rel="stylesheet" href="../../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../../css/custom.css" type="text/css"/>
	  <link rel="stylesheet" href="../../css/bootstrap.css" type="text/css"/>
   </head>
	 <body>
	<div class="container">
	 <p class="center"><img src="../../img/salva.gif"/></p>
	 <p class="center"><img src="../../img/moldura.gif"/></p>
	 
<?php
if ( isset($_POST["submit"]))	{
echo '<p><pre></p>';
		print_r($_POST);
		echo '<p></pre></p>';
		foreach($_POST["iditem"] AS $iditem){
			echo '<p>iditem is '. $iditem . '<br /></p>';
			    echo '<p>finaliza is ' . $_POST["finaliza"][$iditem]."</p><br />";
			
			  $finaliza = mysql_real_escape_string($_POST["finaliza"][$iditem]);
			 echo $finaliza;
			 echo $iditem;
	$update ="UPDATE caditem SET finalizado = '$finaliza' WHERE iditem = '$iditem'";
	mysql_query($update)or die (mysql_error());
	echo 'Itens gravados com sucesso';
	}
	}
	echo "<meta HTTP-EQUIV='refresh' CONTENT='2;URL=../painel_alm.php'>";
	?>
	</div>
	<?php include "footer.php"; ?>
		</body>
		</html>