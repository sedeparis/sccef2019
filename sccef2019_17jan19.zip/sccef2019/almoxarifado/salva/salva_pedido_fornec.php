 <?php 
 session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include "../../conecta_banco.php";
?>
 <!DOCTYPE HTML>
 <html lang="pt-br">
<head>
<title>Pedido de fornecimento
</title>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	 <link rel="stylesheet" href="../../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../../css/custom.css" type="text/css"/>
	  <link rel="stylesheet" href="../../css/bootstrap.css" type="text/css"/>
</head>
<body>
<div class="container">
	 <p class="center"><img src="../../img/salva.gif"/></p>
	 <p class="center"><img src="../../img/moldura.gif"/></p>
<?php
if ( isset($_POST["submit"]))	{
echo '<p><pre></p>';
		print_r($_POST);
		echo '<p></pre></p>';
		foreach($_POST["id_produto_ie"] AS $id_produto_ie){
			echo '<p>id_produto_ie is '. $id_produto_ie. '<br /></p>';
			echo '<p>qtde is ' . $_POST["qtde"][$id_produto_ie]."</p><br />";
			echo '<p>nempenho is ' . $_POST["nempenho"][$id_produto_ie]."</p><br />";
			 echo '<p>dataped is ' . $_POST["dataped"][$id_produto_ie]."</p><br />";
			
			  
			 
			  $qtde = mysqli_real_escape_string($mysqli, $_POST["qtde"][$id_produto_ie]);
				$nempenho= mysqli_real_escape_string($mysqli, $_POST["nempenho"][$id_produto_ie]);
				$dataped= mysqli_real_escape_string($mysqli, $_POST["dataped"][$id_produto_ie]);
			  
			 	 
	//sai produtos do estoque de empenho
$sql = ("INSERT INTO saida_produto_ie(id_produto_ie, qtde_ie, data_saida_ie, nempenho_ie)
VALUES('$id_produto_ie', '$qtde', '$dataped', '$nempenho')");
$resultado = mysqli_query($mysqli, $sql);
{echo 'Itens atualizados para';}

//entra produto estoque fornecimento
$sqlb = ("INSERT INTO entrada_produto_ee (id_produto_ee, qtde_ee, data_entrada_ee, nempenho_ee )
VALUES ('$id_produto_ie', '$qtde', '$dataped', '$nempenho')");
$resultadob = mysqli_query($mysqli, $sqlb);
{echo ' imprimir o pedido de fornecimento!';}
	}
	}
	echo "<meta HTTP-EQUIV='refresh' CONTENT='3;URL=../painel_alm.php'>";
	?>
	
</div>
<?php include "footer.php"; ?>
</body>
</html>