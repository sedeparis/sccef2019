<?php
session_start();
if((!isset ($_SESSION['email']) == true) and (!isset ($_SESSION['senha']) == true))
{
  unset($_SESSION['email']);
  unset($_SESSION['senha']);
  header('location:../index.php');
  }
 
$logado=$_SESSION['email'];
echo '<div class="container">';
echo 'Acessado como: $logado';
echo '</div>';
include_once ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<title>Finalizar compras</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="../css/reset.css" type="text/css"/>
<link rel="stylesheet" href="../css/custom.css" type="text/css"/>
<link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
<script type="text/javascript">
function mascara(t, mask){
var i = t.value.length;
var saida = mask.substring(1,0);
var texto = mask.substring(i)
if (texto.substring(0,1) != saida){
t.value += texto.substring(0,1);
}
}

function validacao() {
if(document.form.processo.value=="Selecione...")
{
alert("Por favor selecione o processo.");
document.form.processo.focus();
return false;
}

if(document.form.fornecedor.value=="Selecione...")
{
alert("Por favor selecione o fornecedor.");
document.form.fornecedor.focus();
return false;
}
}
</script>
</head>
<body>
<div class="container">
<?php include "topo.php"; echo 'Usuário Logado: '; echo $logado; ?>
</div>
<div class="container">
<h2 class="form-nome">Selecionar itens para finalizar</h2>
<br />
<p>Use essa ferramenta para finalizar itens de uma compra.<br />
</p>
<br />
<form name="form" method="post" action="executa/exec_encerra_compra.php" onSubmit="return validacao();"> 
<fieldset class="grupo">
<div class="form-group">
<?php 
$query = mysqli_query($mysqli, "SELECT * FROM cadcompras WHERE situacao = 'Ativo' AND (fase='Corrente') ORDER BY idcompra DESC");
?>
<label class="form-control" for="">Selecione uma compra</label>
<select class="form-control" name="processo">
<option class="form-control" name="">Selecione...</option>
<?php while($proc = mysqli_fetch_array($query)) { ?>
<option class="form-control" value="<?php echo $proc['processo'] ?>"><?php echo $proc['processo'].' - '.$proc['finalidade'] ?></option>
<?php } ?>
</select>
</div>
<div class="form-group">
<?php 
$queryb = mysqli_query($mysqli, "SELECT DISTINCT idfornecedor FROM caditem");
?>
<label class="form-control" for="">Selecione um fornecedor</label>
<select class="form-control" name="fornecedor">
<option class="form-control" name="">Selecione...</option>
<?php while($prodb = mysqli_fetch_array($queryb)) { ?>
<option class="form-control" value="<?php echo $prodb['idfornecedor'] ?>"><?php echo $prodb['idfornecedor'] ?></option>
<?php } ?>
</select>
<p>Se o fornecedor desejado não aparecer verifique se o mesmo foi lançado para o item. Senão, vá em alterar item e informe o fornecedor.</p>
</div>
</fieldset>
<div class="form-group">
<input type="submit" value="Selecionar compras"/>
<input type="reset" value="Limpar"/>
<input type="button" name="cancela" value="Cancelar" onclick="window.location.href='painel_alm.php'"/>
</div>
</form>
</div>

 <?php include "footer.php"; ?> 

 </body>
</html>