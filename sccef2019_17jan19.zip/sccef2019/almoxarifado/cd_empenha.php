<?php
session_start();
if((!isset ($_SESSION['email']) == true) and (!isset ($_SESSION['senha']) == true))
{
  unset($_SESSION['email']);
  unset($_SESSION['senha']);
  header('location:../index.php');
  }
 
$logado=$_SESSION['email'];
echo '<div class="container">';
echo 'Acessado como: $logado';
echo '</div>';
include_once ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<title>Cadastro do empenho</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="../css/reset.css" type="text/css"/>
<link rel="stylesheet" href="../css/custom.css" type="text/css"/>
<link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
<link rel="stylesheet" href="../js/jquery.js"/>
<!--<link rel="stylesheet" href="http://code.jquery.com/ui/1.9.0/themes/base/jquery-ui.css"/>
<script src="../js/jquery-1.8.2.js"></script>
<script src="../js/jquery-ui.js"></script>-->
<script type="text/javascript">
function mascara(t, mask){
var i = t.value.length;
var saida = mask.substring(1,0);
var texto = mask.substring(i)
if (texto.substring(0,1) != saida){
t.value += texto.substring(0,1);
}
}
function validacao() {
if(document.form.processo.value=="Selecione...")
{
alert("Por favor selecione o processo.");
document.form.processo.focus();
return false;
}
if(document.form.fornecedor.value=="Selecione...")
{
alert("Por favor selecione o fornecedor.");
document.form.fornecedor.focus();
return false;
}
if(document.form.data.value=="")
{
alert("Por favor informe a data.");
document.form.data.focus();
return false;
}
if(document.form.solic.value=="Selecione...")
{
alert("Por favor informe o solicitante da requisição.");
document.form.solic.focus();
return false;
}
}
<!-- chamar calendario --->
$(function() {
$("#calendario").datepicker({dateFormat: 'dd-mm-yy'});
});

$(function() {
$( "#calendario" ).datepicker({
showOn: "button",
buttonImage: "calendario.png",
buttonImageOnly: true
});
});
$(function() {
$("#calendario").datepicker({
changeMonth: true,
changeYear: true
});
});
$(function() {
$("#calendario").datepicker({
showOtherMonths: true,
selectOtherMonths: true
});
});
</script>
</head>
<body> 
<div class="container">
<?php include "topo.php"; echo 'Usuário Logado: '; echo $logado; ?>
</div>

<div class="container">
<h2 class="form-nome">Selecionar itens para empenho</h2>
</br>
</br>
<div class="container">
<p>Use essa ROTINA para empenhar itens de uma compra, total ou parcialmente.<br />
A quantidade que sobrar estará disponível para uma próxima operação, caso for necessário.</p>
<p>Se o fornecedor desejado não aparecer verifique se o mesmo foi linkado no modulo COMPRA com a compra.</p>
</div>
<form name="form" method="post" action="executa/exec_empenha.php" onSubmit="return validacao();"> 
<fieldset class="grupo">
<div class="form-group">
<?php 
$query = mysqli_query($mysqli, "SELECT * FROM cadcompras WHERE situacao = '1' AND (finalcompra=0) ORDER BY idcompra DESC");
?>
<label class="form-control" for="">Selecione uma compra</label>
<select class="form-control" name="processo">
<option class="form-control" name="">Selecione...</option>
<?php while($proc = mysqli_fetch_array($query)) { ?>
<option class="form-control" value="<?php echo $proc['idcompra'] ?>">
<?php echo $proc['processo'].' - '.$proc['finalidade'] ?></option>
<?php } ?>
</select>
</div>
</fieldset>
<fieldset class="grupo">
<div class="form-group">
<?php 
$queryb = mysqli_query($mysqli, "SELECT Distinct fornecedora, nome, idforn FROM produto 
INNER JOIN cadfornecedor ON produto.fornecedora=cadfornecedor.idforn WHERE fornecedora <>'' ORDER BY nome asc");
?>
<label class="form-control" for="">Selecione um fornecedor</label>
<select class="form-control" name="fornecedor">
<option class="form-control" name="">Selecione...</option>
<?php while($var = mysqli_fetch_array($queryb)) { ?>
<option class="form-control" value="<?php echo $var['idforn'] ?>"><?php echo $var['nome'] ?></option>
<?php } ?>
</select>
</div>

</fieldset>
<div class="form-group">
<label class="form-control">Data do pedido de empenho:</label>
<input class="form-control" type="text" name="data" id="calendario" onkeypress="mascara(this, '##/##/####')"/>
</div>
<div class="form-group">
<input type="submit" value="Selecionar compras"/>
<input type="reset" value="Limpar"/>
<input type="button" name="cancela" value="Cancelar" onclick="window.location.href='painel_alm.php'"/>
</div>
</form>
</div>

 <?php include "footer.php"; ?> 

 </body>
</html>