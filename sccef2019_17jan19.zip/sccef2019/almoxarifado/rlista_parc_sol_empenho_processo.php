<?php
session_start();
if((!isset ($_SESSION['email']) == true) and (!isset ($_SESSION['senha']) == true))
{
  unset($_SESSION['email']);
  unset($_SESSION['senha']);
  header('location:../index.php');
  }
 
$logado=$_SESSION['email'];
echo '<div class="container">';
echo 'Acessado como: $logado';
echo '</div>';
include_once ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt_br">
<head>
<title>Lista itens nunca solicitado empenho</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		 <link href="../css/print_tab.css" rel="stylesheet" />
	  <link href="../css/print_div.css" rel="stylesheet" />
	   <link href="../css/print_fontes.css" rel="stylesheet" />
</head>
 <body>
	 <div class="cabecalho">
	  <?php include "cabecalho.php"; ?> 
	  </div>
	  <br>
	  
	  <br>
	 <div class="titulo">
	  <h3>ITENS QUE NÃO SE SOLICITOU EMPENHO PARCIALMENTE DA QUANTIDADE</h3>
	  </div>
	
<div class="tabela">
<?php
$processos=$_POST['processo'];
//echo $processos;
// cria a instrução SQL que vai selecionar os dados
$query = sprintf("SELECT * FROM produto 
INNER JOIN saida_produto ON produto.id=saida_produto.id_produto
INNER JOIN cadfornecedor ON produto.fornecedora=cadfornecedor.idforn
INNER JOIN cdunidade ON produto.un=cdunidade.idun
INNER JOIN cadcompras ON produto.idprocesso=cadcompras.idcompra
INNER JOIN estoque ON estoque.id_produto= saida_produto.id_produto
WHERE saida_produto.qtde>0 AND estoque.qtde <> 0 AND (produto.idprocesso='$processos')");
// executa a query
$dados = mysqli_query($mysqli, $query) or die(mysqli_error($mysqli));
// transforma os dados em um array
$linha = mysqli_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysqli_num_rows($dados);
?>

<?php
if($total == 0)  { echo 'Sua pesquisa não retornou nenhum resultado!';}
	// se o número de resultados for maior que zero, mostra os dados//
	if($total > 0) { 
		// inicia o loop que vai mostrar todos os dados
		do {
		$nitem=$linha['nitem'];
		$ditem=$linha['descricao'];
		$un=$linha['unidade'];
		$fornec=$linha['nome'];	
		$proc=$linha['processo'];
		$qtd=$linha['qtde'];
?>
<table>
<colgroup>
<col width="25%">
<col width="6%">
<col width="50%">
<col width="12%">
<col width="7%">
</colgroup>
<thead>
<tr>
<th>Processo</th>
<th>It</th>
<th>Descrição</th>
<th>UN</th>
<th>QTD estoque</th>
</tr>
</thead>

<colgroup>
<col width="25%">
<col width="6%">
<col width="50%">
<col width="12%">
<col width="7%">
</colgroup>
<tbody>
<tr>
<td><?php echo "$proc"?></td>
<td><?php echo "$nitem"?></td>
<td><?php echo "$ditem"?></td>
<td><?php echo "$un"?></td>
<td><?php echo "$qtd"?></td>
</tr>
</tbody>
</table>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = mysqli_fetch_assoc($dados));
	// fim do if 
	}
?>
<?php
// tira o resultado da busca da memória
mysqli_free_result($dados);
?>


</div>
<div class="button">
 <input type="button" name="ok" value="Voltar" onclick="window.location.href='../almoxarifado/painel_alm.php'"/>
</div>
</body>
</html>
