<?php
session_start();
if((!isset ($_SESSION['email']) == true) and (!isset ($_SESSION['senha']) == true))
{
  unset($_SESSION['email']);
  unset($_SESSION['senha']);
  header('location:../index.php');
  }
 
$logado=$_SESSION['email'];
echo '<div class="container">';
echo 'Acessado como: $logado';
echo '</div>';
include_once ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Pedido de pagamento</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	 <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/custom.css" type="text/css"/>
	  <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	  <link rel="stylesheet" href="../js/jquery.js"/>
	  <link rel="stylesheet" href="../js/jquery-ui.css" />
<script src="../js/jquery-1.8.2.js"></script>
<script src="../js/jquery-ui.js"></script>
   <script type="text/javascript">
	  function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
 
 function moeda(z){
v = z.value;
v=v.replace(/\D/g,"") // permite digitar apenas numero
v=v.replace(/(\d{1})(\d{14})$/,"$1.$2") // coloca ponto antes dos ultimos digitos
v=v.replace(/(\d{1})(\d{11})$/,"$1.$2") // coloca ponto antes dos ultimos 11 digitos
v=v.replace(/(\d{1})(\d{8})$/,"$1.$2") // coloca ponto antes dos ultimos 8 digitos
v=v.replace(/(\d{1})(\d{5})$/,"$1.$2") // coloca ponto antes dos ultimos 5 digitos
v=v.replace(/(\d{1})(\d{1,2})$/,"$1,$2") // coloca virgula antes dos ultimos 2 digitos
z.value = v;
}
 
 function validacao() {
	 
	 if(document.form.processo.value=="Selecione...")
{
alert("Por favor selecione o processo.");
document.form.processo.focus();
return false;
}


if(document.form.fornecedor.value=="Selecione...")
{
alert("Por favor selecione o fornecedor.");
document.form.fornecedor.focus();
return false;
}

if(document.form.solic.value=="Selecione...")
{
alert("Por favor informe o requisitante.");
document.form.solic.focus();
return false;
}

if(document.form.requisita.value=="")
{
alert("Por favor informe o número da requisicao.");
document.form.requisita.focus();
return false;
}

if(document.form.nfe.value=="")
{
alert("Por favor informe o número nfe.");
document.form.nfe.focus();
return false;
}
if(document.form.valor.value=="")
{
alert("Por favor informe o valor da nota.");
document.form.valor.focus();
return false;
}

if(document.form.data.value=="")
{
alert("Por favor informe a data.");
document.form.data.focus();
return false;
}

 

}

<!-- chamar calendario --->
$(function() {
     $("#calendario").datepicker({dateFormat: 'dd-mm-yy'});
});

$(function() {
    $( "#calendario" ).datepicker({
        showOn: "button",
        buttonImage: "calendario.png",
        buttonImageOnly: true
    });
});
$(function() {
    $("#calendario").datepicker({
        changeMonth: true,
        changeYear: true
    });
});
$(function() {
    $("#calendario").datepicker({
        showOtherMonths: true,
        selectOtherMonths: true
    });
});
	 </script>

   </head>
	 <body> 
	 <div class="container">
<?php include "topo.php"; echo 'Usuário Logado: '; echo $logado; ?>
</div>
	 
	 <div class="container">
	<h2 class="form-nome">Pedido de pagamento</h2>
	<form name="form" method="post" action="executa/exec_pedido_pagamento.php" onSubmit="return validacao();">  
	<fieldset class="grupo">	
	<div class="form-group">
	<?php 
	$query = mysqli_query($mysqli, "SELECT * FROM cadcompras WHERE situacao='1' AND finalcompra='0' ORDER BY idcompra DESC");
?>
 <label class="form-control" for="">Selecione uma compra</label>
 <select class="form-control" name="processo">
 <option class="form-control" name="">Selecione...</option>
 <?php while($proc = mysqli_fetch_array($query)) { ?>
 <option class="form-control" value="<?php echo $proc['idcompra'] ?>"><?php echo $proc['processo'].' - '.$proc['finalidade'] ?></option>
 <?php } ?>
 </select>
 </div>
		 <div class="form-group">
			 	<?php 
	$queryb = mysqli_query($mysqli, "SELECT DISTINCT  idforn, nome FROM cadfornecedor ORDER BY nome ASC");
?>
 <label class="form-control" for="">Selecione um fornecedor</label>
 <select class="form-control" name="fornecedor">
 <option class="form-control" name="">Selecione...</option>
 
 <?php while($prodb = mysqli_fetch_array($queryb)) { ?>
 <option class="form-control" value="<?php echo $prodb['idforn'] ?>"><?php echo $prodb['nome'] ?></option>
 <?php } ?>
 </select>
 </div>	
	 				<div class="form-group">
		 <?php	   
  $queryc = mysqli_query($mysqli, "SELECT * FROM cdrequisitante ORDER BY nome ASC");
?>
 <label class="form-control" for="">Requisitante do pagamento:</label>		     
 <select class="form-control" name="solic">
 <option class="form-control" name="">Selecione...</option>
 <?php while($setor = mysqli_fetch_array($queryc)) { ?>
 <option class="form-control" value="<?php echo $setor['idr'] ?>"><?php echo $setor['nome'] ?></option>
 <?php } ?>
 </select>
 </div>
 </fieldset>
	<fieldset class="grupo">
		 <div class="form-group">
			<label class="form-control">Nº Requisição: (xxx/xxxx)</label>
			<input class="form-control" type="text" size="8" name="requisicao" onkeypress="mascara(this, '###/####')" maxlength="8"/>
			</div>
		 <div class="form-group">
		 <label class="form-control">Número NFe:</label>
		 <input class="form-control" type="text" size="8" name="nfe"/>
		 </div>
		 <div class="form-group">
	 <label class="form-control">Valor:</label>
	 <input class="form-control" type="text" size="8" name="valor" onkeyup="moeda(this)" />
	 </div>
		 <div class="form-group">
		 <label class="form-control">Data:</label>
		 <input class="form-control" type="text" name="data" id="calendario" onkeypress="mascara(this, '##/##/####')" maxlength="10"/>
		 </div>
	 </fieldset>

		 <div class="form-group">
	<input type="submit" value="Gerar pedido de pagamento"/>
	 <input type="reset" value="Limpar"/>
	  <input type="button" name="cancela" value="Cancelar" onclick="window.location.href='painel_alm.php'"/>
	  </div>
</form>
</div>

 <?php include "footer.php"; ?> 

  </body>
 </html>