<?php
session_start();
if((!isset ($_SESSION['email']) == true) and (!isset ($_SESSION['senha']) == true))
{
  unset($_SESSION['email']);
  unset($_SESSION['senha']);
  header('location:../index.php');
  }
 
$logado=$_SESSION['email'];
echo '<div class="container">';
echo 'Acessado como: $logado';
echo '</div>';
include_once ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt_br">
<head>
<title>Lista itens nunca inf empenho</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		 <link href="../css/print_tab.css" rel="stylesheet" />
	  <link href="../css/print_div.css" rel="stylesheet" />
	   <link href="../css/print_fontes.css" rel="stylesheet" />
</head>
 <body>
	 <div class="cabecalho">
	  <?php include "cabecalho.php"; ?> 
	  </div>
	  <br>
	  
	  <br>
	 <div class="titulo">
	  <h3>ITENS QUE NÃO CONFIRMOU EMPENHO DE NENHUMA QUANTIDADE</h3>
	  </div>
	
<div class="tabela">
<?php
$processos=$_POST['processo'];
//echo $processos;
// cria a instrução SQL que vai selecionar os dados
$query = sprintf("SELECT * FROM produto 
inner join entrada_produto_ie on produto.id=entrada_produto_ie.id_produto_ie
inner join cadfornecedor on produto.fornecedora=cadfornecedor.idforn
inner join cdunidade on produto.un=cdunidade.idun
inner join cadcompras on produto.idprocesso=cadcompras.idcompra
inner join estoque_ie on estoque_ie.id_produto_ie=entrada_produto_ie.id_produto_ie
where (produto.idprocesso= '$processos')AND estoque_ie.qtde_ie =entrada_produto_ie.qtde_ie
");
// executa a query
$dados = mysqli_query($mysqli, $query) or die(mysqli_error($mysqli));
// transforma os dados em um array
$linha = mysqli_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysqli_num_rows($dados);
?>

<?php
if($total == 0)  { echo 'Sua pesquisa não retornou nenhum resultado!';}
	// se o número de resultados for maior que zero, mostra os dados//
	if($total > 0) { 
		// inicia o loop que vai mostrar todos os dados
		do {
		$nitem=$linha['nitem'];
		$ditem=$linha['descricao'];
		$un=$linha['unidade'];
		$fornec=$linha['nome'];	
		$proc=$linha['processo'];
		$qtd=$linha['qtde_ie'];

?>
<table>
<colgroup>
<col width="25%">
<col width="5%">
<col width="48%">
<col width="10%">
<col width="5%">
<col width="7%">
</colgroup>
<thead>
<tr>
<th>Processo</th>
<th>It</th>
<th>Descrição</th>
<th>UN</th>
<th>Qtd sem</th>
<th>Empenho</th>
</tr>
</thead>

<colgroup>
<col width="25%">
<col width="5%">
<col width="48%">
<col width="10%">
<col width="5%">
<col width="7%">
</colgroup>
<tbody>
<tr>
<td><?php echo "$proc"?></td>
<td><?php echo "$nitem"?></td>
<td><?php echo "$ditem"?></td>
<td><?php echo "$un"?></td>
<td><?php echo "$qtd"?></td>
<td><?php echo ""?></td>
</tr>
</tbody>
</table>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = mysqli_fetch_assoc($dados));
	// fim do if 
	}
?>
<?php
// tira o resultado da busca da memória
mysqli_free_result($dados);
?>


</div>
<div class="button">
 <input type="button" name="ok" value="Voltar" onclick="window.location.href='painel_alm.php'"/>
</div>
</body>
</html>
