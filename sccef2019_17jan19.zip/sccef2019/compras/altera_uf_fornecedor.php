<?php
session_start();
if((!isset ($_SESSION['email']) == true) and (!isset ($_SESSION['senha']) == true))
{
  unset($_SESSION['email']);
  unset($_SESSION['senha']);
  header('location:../index.php');
  }
 
$logado=$_SESSION['email'];
echo '<div class="container">';
echo 'Acessado como: $logado';
echo '</div>';
include_once ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Alterar Fornecedor</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	 <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/estiloform.css" type="text/css"/>
	 <script type="text/javascript">
 
 function validacao() {
if(document.form.altera.value=="Selecione...")
{
alert("Por favor selecione o fornecedor.");
document.form.altera.focus();
return false;
}
}
 
 </script>
 </head>
	 <body> <div class="container">
	 <?php include "topo.php"; echo 'Usuário Logado: '; echo $logado; ?> </div>
	 <!-------- inicia pagina-------------->
	 
   
	 <div class="container">
	<h2 class="form-nome">Alterar Cidade fornecedor</h2>
	
<form name="form" method="POST" action="executa/exec_altera_uf_fornecedor.php"  onSubmit="return validacao();">
	
	<fieldset class="grupo">
		  <div class="form-group">
	<?php 
	$query = mysqli_query($mysqli, "SELECT * FROM cadfornecedor ORDER BY idforn DESC");
?>
 <label class="form-control" for="">Selecione o fornecedor</label>
 <select class="form-control" name="altera">
 <option class="form-control" name="">Selecione...</option>
 <?php 
 while($busca = mysqli_fetch_array($query)) { 
 ?>
 <option class="form-control"   value="<?php 
 echo $busca['idforn'] 
 ?>">
 <?php 
 echo $busca['cnpj'].' - '.$busca['nome']
 ?></option>
 <?php } ?>
 </select>
 </div>
	</fieldset>
<fieldset class="grupo">
		  <div class="form-group">
<input class="form-control-2"  type="submit" id="submit" value="Buscar" name="Localizar"/>
<input class="form-control-2"  type="reset" id="reset" value="Limpar" name="Localizar"/>
<input class="form-control-2"  type="button" name="cancela" value="Cancelar" onclick="window.location.href='painel.php'"/>
</div>
	</fieldset>
</form>
</div>
<?php include "footer.php" ?>  </body>
 </html>