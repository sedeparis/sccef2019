<?php
session_start();
if((!isset ($_SESSION['email']) == true) and (!isset ($_SESSION['senha']) == true))
{
  unset($_SESSION['email']);
  unset($_SESSION['senha']);
  header('location:../index.php');
  }
 
$logado=$_SESSION['email'];
echo '<div class="container">';
echo 'Acessado como: $logado';
echo '</div>';
include_once ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../img/icone_barra.jpg" />
	 <title>Despacho de modalidade</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	 <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/estiloform.css" type="text/css"/>
	  <script type="text/javascript">
	    function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
 
function validacao() {

if(document.form.processo.value=="Selecione...")
{
alert("Por favor selecione o processo.");
document.form.processo.focus();
return false;
}


if(document.form.tipo.value=="Selecione...")
{
alert("Por favor selecione a modalidade.");
document.form.tipo.focus();
return false;
}


if(document.form.numcompra.value=="")
{
alert("Por favor informe o número da compra.");
document.form.numcompra.focus();
return false;
}
}
</script>
 </head>
	  <body> <div class="container"><?php include "topo.php"; echo 'Usuário Logado: '; echo $logado; ?> </div>
	 <div class="container">
	<h2 class="form-nome">Dados complementares do Processo</h2>
	<p></p>
	<p></p>
	
	<p></p>
	<p></p>
<form  name="form" method="POST" action="salva/salva_complementar_processo.php" onSubmit="return validacao();">
	<fieldset class="grupo">
		  <div class="form-group">
		 <!---selecionar processo --->
	<?php 
	$query = mysqli_query($mysqli, "SELECT * FROM cadcompras WHERE numcompra = '' ORDER BY idcompra DESC");
?>
 <label class="form-control" for="">Selecione o processo</label>
 <select class="form-control" name="processo">
 <option class="form-control" name="">Selecione...</option>
 <?php 
 while($busca = mysqli_fetch_array($query)) { 
 ?>
 <option class="form-control"   value="<?php 
 echo $busca['idcompra'] 
 ?>">
 <?php 
 echo $busca['processo'].' - '.$busca['finalidade'];?>
 </option>
 <?php } ?>
 </select>
</div>
</fieldset>

<fieldset class="grupo">
		  <div class="form-group">
		 <!---selecionar modalidade --->
	<?php 
	$queryb = mysqli_query($mysqli, "SELECT * FROM cadtipo");
?>
 <label class="form-control" for="">Selecione a Modalidade</label>
 <select class="form-control" name="tipo">
 <option class="form-control" name="">Selecione...</option>
 <?php 
 while($buscab = mysqli_fetch_array($queryb)) { 
 ?>
 <option class="form-control"   value="<?php 
 echo $buscab['tipo'] 
 ?>">
 <?php 
 echo $buscab['tipo'];?>
 </option>
 <?php } ?>
 </select>
</div>
 <div class="form-group">
		<label class="form-control">Número da compra:</label>
<input class="form-control" type="text" name="numcompra" size="7" onkeypress="mascara(this, '##/####')" maxlength="7"/>
</div>
<div class="form-group">
		<label class="form-control">Número da Uasg:</label>
<input class="form-control" type="text" name="uasg" size="7" onkeypress="mascara(this, '######')" maxlength="6"/>
</div>
</fieldset>
 
<fieldset class="grupo">
		  <div class="form-group">
 <!---selecionar PI 1--->
	<?php 
	$queryb = mysqli_query($mysqli, "SELECT * FROM cdptres WHERE tipo = 'PI' AND nome <> 1");
?>
 <label class="form-control" for="">Selecione um PI da compra</label>
 <select class="form-control" name="pi">
 <option class="form-control" name="">Selecione...</option>
 <?php 
 while($busca = mysqli_fetch_array($queryb)) { 
 ?>
 <option class="form-control"   value="<?php 
 echo $busca['nome'] 
 ?>">
 <?php 
 echo $busca['nome'];?>
 </option>
 <?php } ?>
 </select>
</div>
 <div class="form-group">
 <!---selecionar PI 2--->
	<?php 
	$queryc = mysqli_query($mysqli, "SELECT * FROM cdptres WHERE tipo = 'PI' AND nome <> 1");
?>
 <label class="form-control" for="">Selecione novo PI se necessário</label>
 <select class="form-control" name="pi2">
 <option class="form-control" name="">Selecione...</option>
 <?php 
 while($busca = mysqli_fetch_array($queryc)) { 
 ?>
 <option class="form-control"   value="<?php 
 echo $busca['nome'] 
 ?>">
 <?php 
 echo $busca['nome'];?>
 </option>
 <?php } ?>
 </select>
</div>
 <div class="form-group">
 <!---selecionar PTRES --->
	<?php 
	$queryd = mysqli_query($mysqli, "SELECT * FROM cdptres WHERE tipo = 'PTRES' AND nome <> 2");
?>
 <label class="form-control" for="">Selecione o PTRES da compra</label>
 <select class="form-control" name="ptres">
 <option class="form-control" name="">Selecione...</option>
 <?php 
 while($busca = mysqli_fetch_array($queryd)) { 
 ?>
 <option class="form-control"   value="<?php 
 echo $busca['nome'] 
 ?>">
 <?php 
 echo $busca['nome'];?>
 </option>
 <?php } ?>
 </select>
</div>
</fieldset>
  <div class="form-group">
<input class="form-control-2"  type="submit" id="submit" value="Cadastrar" name="print"/>
<input class="form-control-2"  type="reset" id="reset" value="Limpar dados" name="limpar"/>
<input class="form-control-2"  type="button" name="cancela" value="Cancelar" onclick="window.location.href='painel.php'"/>
</div>
</form>
</div> 
	 <?php include "footer.php" ?> </body>
 </html>