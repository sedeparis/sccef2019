<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como:  '. $logado;
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Cadastro empenho</title>
	<link rel="stylesheet" type="text/css" href="../../css/reset.css"/>
  <link rel="stylesheet" type="text/css" href="../../css/bootstrap.css" media="screen"/>
   <link rel="stylesheet" type="text/css" href="../../css/custom.css" media="screen"/>
   </head>
	 <body>
	 <div id="container">
	<br>
<br>
<p class="center"><img src="../../img/salva.gif"/></p>
<p class="center"><img src="../../img/moldura.gif"/></p>
<br>
<br>
	 
<?php
if ( isset($_POST["submit"]))	{
echo '<pre>';
		print_r($_POST);
		echo '</pre>';
		foreach($_POST["id"] AS $id){
			
			echo '<p class="oculta">id is '. $id . '</p><br />';
			echo '<p class="oculta">elem is ' . $_POST["elem"][$id].'</p><br />';
			echo '<p class="oculta">radio is ' . $_POST["radio"][$id].'</p><br />';
	
						 	 
			
			   $elem = mysqli_real_escape_string($mysqli, $_POST["elem"][$id]);
			 $radio = mysqli_real_escape_string($mysqli, $_POST["radio"][$id]);
			 
			
			if ($radio <> 1) {
   echo 'Ed não selecionado<br />';

} else {
	
	$update = "UPDATE produto SET  ed = '$elem' WHERE
	id =$id;";
	
	mysqli_query($mysqli, $update)or die (mysqli_error($mysqli));
echo 'Ed gravados!<br />';
	}
	}
	}
	?>
	<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='2;URL=../painel.php'>";
?>
	</div>
	</body>
	</html>