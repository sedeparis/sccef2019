<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como:  '. $logado;
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<title>Gerenciamento de compras
</title>
<link rel="stylesheet" type="text/css" href="../../css/reset.css"/>
  <link rel="stylesheet" type="text/css" href="../../css/bootstrap.css" media="screen"/>
   <link rel="stylesheet" type="text/css" href="../../css/custom.css" media="screen"/>
</head>
<body>
<div class="container">
<?php
$idforn=$_POST['idforn'];
		$cidade=$_POST['cod_cidades'];
$uf=$_POST['cod_estados'];
	

$sql = mysqli_query($mysqli, "UPDATE cadfornecedor SET cidade ='$cidade', uf ='$uf' WHERE idforn ='$idforn'");
$resultado = mysqli_query ($mysqli, $sql);
{echo "Fornecedor alterado com sucesso!";
}

?>
<br>
<br>
<p class="center"><img src="../../img/salva.gif"/></p>
<br>
<br>
<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='3;URL=../painel.php'>";
?>
</div>
</body>
</html>