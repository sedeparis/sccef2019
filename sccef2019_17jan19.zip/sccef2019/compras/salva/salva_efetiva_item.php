<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como:  '. $logado;
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema Administrativo compras públicas.</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../../css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../../css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../../css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   
	    
	    
		<!--- scripts de validação de formulário --->
</head>
<body> <div class="container"> <?php include "topo.php"; echo 'Usuário logado: ';  echo $logado; ?> </div>
<div class="container">
<h2>Salva Efetiva item</h2>
<?php
$id=$_POST['item'];
$fornecedor=$_POST['fornecedor'];
$valor=$_POST['valor'];
$valora = str_replace(',','.',str_replace('.','',$valor));  
?>
<?php 
$query = sprintf("SELECT estoque_maximo FROM produto WHERE id = $id ");
$retorno = mysqli_query($mysqli, $query) or die (mysqli_error($mysqli));
$linha = mysqli_fetch_assoc($retorno);
// calcula quantos dados retornaram
$total = mysqli_num_rows($retorno);
?>

<?php
	if($total > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
		$qtde=$linha['estoque_maximo'];
		?>
<?php
 $sql = mysqli_query($mysqli, "UPDATE produto SET valor_unitario ='$valora', fornecedora ='$fornecedor' WHERE id ='$id'");
 $resultado = mysqli_query ($mysqli, $sql);
{echo "Update e";
}
//alimentar tabela entrada de produto
$sqlb = mysqli_query($mysqli, "INSERT INTO entrada_produto (id_produto, qtde, data_entrada)
VALUES ('$id','$qtde', NOW()) ");
 $resultado = mysqli_query ($mysqli, $sqlb);
{echo " dados informados com sucesso!";
}
?>

<br>
<br>
<p class="center"><img src="../../img/salva.gif"/></p>
<br>
<br>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = mysqli_fetch_assoc($retorno));
	// fim do if 
	}
?>
<?php
// tira o resultado da busca da memória
mysqli_free_result($retorno);
?>
<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='3;URL=../efetiva_item.php'>";
?>
</div>
</div>
<?php include "footer.php"; ?> </body>
</html>
