﻿<?php
session_start();
if((!isset ($_SESSION['email']) == true) and (!isset ($_SESSION['senha']) == true))
{
  unset($_SESSION['email']);
  unset($_SESSION['senha']);
  header('location:../index.php');
  }
 
$logado=$_SESSION['email'];
echo '<div class="container">';
echo 'Acessado como: $logado';
echo '</div>';
include_once ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema Administrativo compras públicas.</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <!--link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' /-->

   </head>
<body>       
<script type="text/javascript" src="../js/wz_tooltip.js"></script>  
    <div id="wrapper">
         <div class="navbar navbar-inverse navbar-fixed-top">
            <div class="adjust-nav">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">
                        <img src="../img/logoif.jpg" />
                    </a>
                </div>
                <span class="logout-spn" >
                  <a href="../logout.php" style="color:#fff;">LOGOUT</a>  
                </span>
            </div>
        </div>
        <!-- /. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
<div class="sidebar-collapse">
<ul class="nav" id="main-menu">
<li class="active-link">
<a href="../admin/index.php"><i class="fa fa-desktop "></i>Admin<span class="badge"></span></a>
</li>
<li>
<a href="../requisitante/painelr.php"><i class="fa fa-user"></i>
Requisitante</a>
</li>
<li>
<a href="painel.php"><i class="fa fa-shopping-cart"></i>
Compras</a>
</li>
<li>
<a href="../almoxarifado/painel_alm.php"><i class="fa fa-print"></i>Almoxarifado</a>
</li>
<li>
<a href="../controles/painelctrl.php"><i class="fa fa-print"></i>Controles</a>
</li>
<li>
<a href="../sobre.php"><i class="fa fa-edit"></i>Ajuda/sobre  <span class="badge"></span></a>
</li>
</ul>
</div>
</nav>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-lg-12">
                     <h2 class="form-nome">PAINEL COMPRAS</h2>   
                    </div>
                </div>              
                 <!-- /. ROW  -->
                  <hr />
                <div class="row">
                    <div class="col-lg-12 ">
                        <div class="alert alert-info">
                             <strong>Bem vindo <?php echo "$logado!";?> </strong>
                        </div>
                    </div>
                    </div>
                  <!-- /. ROW  --> 
                            <div class="row text-center pad-top">
							<h3>Cadastros Gerais</h3>
							<p>* Rotinas obrigatórias para o funcionamento do sistema</p>
							
                 <!--1-->
				  				   <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="cd_fornecedor.php"   onmouseover="Tip('Cadastrar Fornecedor')" onmouseout="UnTip()">
 <i class="fa fa-pencil fa-3x"></i>
                      <h4>*Cadastro <br>Forn</h4>
                      </a>
                      </div>
                  </div>
				     <!--2-->
                  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="altera_dados_fornecedor.php"  onmouseover="Tip('Alterar fornecedor')" onmouseout="UnTip()" >
 <i class="fa fa-edit fa-3x"></i>
                      <h4>Alterar <br>Forn</h4>
                      </a>
                      </div>
                  </div>
				     <!--3-->
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="cd_piptres.php"  onmouseover="Tip('Cadastrar PI e PTRES')" onmouseout="UnTip()" >
 <i class="fa fa-spinner fa-3x"></i>
                      <h4>+Pi-ptres</h4>
                      </a>
                      </div>
                  </div>
				     <!--4-->
                  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="cd_banco.php"  onmouseover="Tip('Cadastrar Bancos para inserir no cadastro dos fornecedores')" onmouseout="UnTip()" >
 <i class="fa fa-bank fa-3x"></i>
                      <h4>*Cadastro <br>Bancos</h4>
					 </a>
                      </div>                     
                  </div>
				     <!--5-->
				   <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="altera_banco.php"  onmouseover="Tip('Alterar Bancos')" onmouseout="UnTip()" >
 <i class="fa fa-bank fa-3x"></i>
                      <h4>Altera <br>Bancos</h4>
					 </a>
                      </div>                     
                  </div>
				     <!--6-->
				  
				   <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="cd_ed.php"  onmouseover="Tip('Cadastra elemento de despesas')" onmouseout="UnTip()" >
 <i class="fa fa-pencil fa-3x"></i>
                      <h4>Cadastrar <br>E.D.</h4>
					 </a>
                      </div>                     
                  </div>
				   
				  
              </div>
                 <!-- /. ROW  --> 
                <div class="row text-center pad-top">
                  
				   <!--1-->
				  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="altera_ed.php"  onmouseover="Tip('Alterar ED')" onmouseout="UnTip()" >
 <i class="fa fa-edit fa-3x"></i>
                      <h4>Altera <br>E.D.</h4>
					 </a>
                      </div>                     
                  </div>
                  
                  </div> 
                  <!-- /. ROW fim do ciclo de cadastro gerais -->   
  <!-- /. ROW inicio ciclo de compras -->  
   
                 <div class="row text-center pad-top">
                   <h3>Compras</h3>
				     
				   
				  <!-- /01 -->  
				  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="informa_eds.php"  onmouseover="Tip('Informar ED dos itens')" onmouseout="UnTip()">
 <i class="fa fa-barcode fa-3x"></i>
                      <h4>*ED/item</h4>
                      </a>
                      </div>
                  </div>
				   
                     <!-- /02 --->  
                 <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="cd_complementar_processo.php"  onmouseover="Tip('Incluir dados complementares processo')" onmouseout="UnTip()">
 <i class="fa fa-pencil fa-3x"></i>
                      <h4>Complentar <br>Info Processo</h4>
                      </a>
                      </div>
						</div>
				<!-- /03 --> 
	<div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="altera_num_compra.php" onmouseover="Tip('Alterar numero da compra caso necessário')" onmouseout="UnTip()" >
 <i class="fa fa-asterisk  fa-3x"></i>
                      <h4>Alt_n°<br>Compra </h4>
                      </a>
                      </div>
                  </div>
				   
				  				   <!--/5--> 
                 <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="informa_val_compra.php"  onmouseover="Tip('Informar data limite para solicitar itens')" onmouseout="UnTip()" >
 <i class="fa fa-calendar fa-3x"></i>
                      <h4>Validade<br>compras </h4>
                      </a>
                      </div>
                  </div>
				   <!-- /6 -->  
                      <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="efetiva_item.php"  onmouseover="Tip('Informar fornecedor e valor de compra item a item')" onmouseout="UnTip()" >
 <i class="fa fa-sign-in fa-3x"></i>
                      <h4>Informa Valor<br>Forn item</h4>
                      </a>
                      </div>
                  </div>
				     </div>
                 <!-- /. ROW  -->  
                 
                 <div class="row text-center pad-top">
				                
                  <!---1-->
                  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="efetiva_forn_lote.php" onmouseover="Tip('Informar fornecedor para mais de um item')" onmouseout="UnTip()">
 <i class="fa fa-list fa-3x"></i>
                      <h4>Informa Forn<br>vários itens</h4>
                      </a>
                      </div>
                  </div>
				  <!-- /2 -->  
					  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="efetiva_valor_lote.php"  onmouseover="Tip('Informar valor para vários itens')" onmouseout="UnTip()">
 <i class="fa fa-dollar fa-3x"></i>
                      <h4>Informar valor <br>vários itens</h4>
                      </a>
                      </div>
                  </div>
				   
				   <!---3-->
                     <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="altera_efetiva_lote_forn.php"  onmouseover="Tip('Alterar fornecedor de vários itens')" onmouseout="UnTip()" >
 <i class="fa fa-edit  fa-3x"></i>
                      <h4>altera forn<br> vários itens</h4>
                      </a>
                      </div>
                  </div> 
				   <!---4-->
				  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="altera_efetiva_valor_item.php" onmouseover="Tip('Alterar valor de um item efetivados')" onmouseout="UnTip()" >
 <i class="fa fa-edit  fa-3x"></i>
                      <h4>altera valor<br> itens</h4>
                      </a>
                      </div>
                  </div> 
				  <!---5-->
                  <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                      <div class="div-square">
                           <a href="filtro_itens_efetivado.php"  onmouseover="Tip('Gerar relação de itens efetivados por compra')" onmouseout="UnTip()" >
 <i class="fa fa-rocket fa-3x"></i>
                      <h4>Itens<br>efetiv.</h4>
                      </a>
                      </div>
                  </div>
              </div>   
			   
			   
                  <!-- /. ROW  -->  
				 
				  <div class="row">
                    <div class="col-lg-12 ">
					<br/>
                    </div>
                    </div>
                  <!-- /. ROW  --> 
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
    <div class="footer">
            <div class="row">
                <div class="col-lg-12" >
                  <?php 

include_once '../versao.php';
?> 
                </div>
            </div>
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="js/jquery.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="js/bootstrap.min.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="js/custom.js"></script>

</div>
</body>
</html>