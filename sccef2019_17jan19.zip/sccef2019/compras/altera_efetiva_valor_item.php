<?php
session_start();
if((!isset ($_SESSION['email']) == true) and (!isset ($_SESSION['senha']) == true))
{
  unset($_SESSION['email']);
  unset($_SESSION['senha']);
  header('location:../index.php');
  }
 
$logado=$_SESSION['email'];
echo '<div class="container">';
echo 'Acessado como: $logado';
echo '</div>';
include_once ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../img/icone_barra.jpg" />
	 <title>Altera valor</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	 <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/estiloform.css" type="text/css"/>
	  <script type="text/javascript">
	  
 function moeda(z){
v = z.value;
v=v.replace(/\D/g,"") // permite digitar apenas numero
v=v.replace(/(\d{1})(\d{16})$/,"$1.$2") // coloca ponto antes dos ultimos digitos
v=v.replace(/(\d{1})(\d{13})$/,"$1.$2") // coloca ponto antes dos ultimos 11 digitos
v=v.replace(/(\d{1})(\d{10})$/,"$1.$2") // coloca ponto antes dos ultimos 8 digitos
v=v.replace(/(\d{1})(\d{7})$/,"$1.$2") // coloca ponto antes dos ultimos 5 digitos
v=v.replace(/(\d{1})(\d{1,4})$/,"$1,$2") // coloca virgula antes dos ultimos 2 digitos
z.value = v;
}

function validacao() {

if(document.form.altera.value=="Selecione...")
{
alert("Por favor selecione o item.");
document.form.altera.focus();
return false;
}

if(document.form.fornecedor.value=="Selecione...")
{
alert("Por favor selecione o fornecedor.");
document.form.fornecedor.focus();
return false;
}
}
</script>
 </head>
	  <body> <div class="container"><?php include "topo.php"; echo 'Logado: '; echo $logado; ?> </div>
	 <div class="container">
	<h2 class="form-nome">Alterar Valor do item</h2>
<form  name="form" method="POST" action="executa/exec_altera_valor_item.php" onSubmit="return validacao();">
	<fieldset class="grupo">
		  <div class="form-group">
	<?php 
	$query = mysqli_query($mysqli, "SELECT * FROM produto WHERE valor_unitario <> '' ");
?>
 <label class="form-control" for="">Selecione o item</label>
 <select class="form-control" name="altera">
 <option class="form-control" name="">Selecione...</option>
 <?php 
 while($busca = mysqli_fetch_array($query)) { 
 ?>
 <option class="form-control"   value="<?php 
 echo $busca['id'] 
 ?>">
 <?php 
 echo $busca['nitem'].' - '.substr($busca['descricao'],0,100);
 ?></option>
 <?php } ?>
 </select>
</div>
 
</fieldset>
	
	 <div class="form-group">
<input class="form-control-2"  type="submit" id="submit" value="Alterar" name="Localizar"/>
<input class="form-control-2"  type="reset" id="reset" value="Limpar dados" name="limpar"/>
<input class="form-control-2"  type="button" name="cancela" value="Cancelar" onclick="window.location.href='painel.php'"/>
</div>
</form>
</div> 
	 <?php include "footer.php" ?> </body>
 </html>