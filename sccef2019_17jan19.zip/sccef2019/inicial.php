﻿<?php
session_start();
if((!isset ($_SESSION['email']) == true) and (!isset ($_SESSION['senha']) == true))
{
  unset($_SESSION['email']);
  unset($_SESSION['senha']);
  header('location:index.php');
  }
 
$logado=$_SESSION['email'];

include_once 'conecta_banco.php';
include_once 'versao.php';
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="icon" type="image/jpg" href="img/icone_barra.jpg" />
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Sccef - index</title>
<!-- BOOTSTRAP STYLES-->
<link href="css/bootstrap.css" rel="stylesheet" />
<!-- FONTAWESOME STYLES-->
<link href="css/font-awesome.css" rel="stylesheet" />
<!-- CUSTOM STYLES-->
<link href="css/custom.css" rel="stylesheet" />
<!-- GOOGLE FONTS-->
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>

<body> 
<?php include "topo.php" ?>
<div id="wrapper">
<div class="navbar navbar-inverse navbar-fixed-top">
<div class="adjust-nav">
<div class="navbar-header">
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a class="navbar-brand" href="#">
<img src="img/logo.png"/>
</a>
</div>
<h1 style="color:#fff;"> SCCEF Beta</h1>
<span class="logout-spn">
<a href="logout.php" style="color:#fff;">LOGOUT</a>  
</span>
</div>
</div>
<!-- /. NAV TOP  -->
<nav class="navbar-default navbar-side" role="navigation">
<div class="sidebar-collapse">
<ul class="nav" id="main-menu">
<li class="active-link">
<a href="admin/index.php"><i class="fa fa-desktop "></i>Admin<span class="badge"></span></a>
</li>
<li>
<a href="requisitante/painelr.php"><i class="fa fa-user"></i>
Requisitante</a>
</li>
<li>
<a href="compras/painel.php"><i class="fa fa-shopping-cart"></i>
Compras</a>
</li>
<li>
<a href="almoxarifado/painel_alm.php"><i class="fa fa-print"></i>Almoxarifado</a>
</li>
<li>
<a href="controles/painelctrl.php"><i class="fa fa-print"></i>Controles</a>
</li>
<li>
<a href="sobre.php"><i class="fa fa-edit"></i>Ajuda/sobre  <span class="badge"></span></a>
</li>
</ul>
</div>
</nav>
<!-- /. NAV SIDE  -->

<div id="page-wrapper" >

<div id="page-inner">
<div class="row">
<div class="container">
<div class="col-md-12">
<br>
<br>
<h2 class="center">SCCEF</h2>
 <h3 class="center">Sistema de Controle de Compras, Empenho e Fornecimento de Compras Públicas</h3>
<br>
<br>
</div>
</div>              
<p class="center">Desenvolvido com:</p>
<p class="center">
<img class="index" src="img/php.jpeg">
<img class="index" src="img/mariabd.png">
<img class="index" src="img/apache.jpeg">
<img class="index" src="img/html.png">
<img class="index" src="img/notepadd.png">
<img class="index" src="img/office.jpeg">
<img class="index" src="img/fire.png">
<img class="index" src="img/filezilla.png">
</p>
<hr />
<!-- /. ROW  -->           
</div>
<!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->
</div>
</div>
<!-- /. WRAPPER  -->
<!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
<!-- JQUERY SCRIPTS -->
<script src="js/jquery.js"></script>
<!-- BOOTSTRAP SCRIPTS -->
<script src="js/bootstrap.min.js"></script>
<!-- CUSTOM SCRIPTS -->
<script src="js/custom.js"></script>
</body>
</html>
	