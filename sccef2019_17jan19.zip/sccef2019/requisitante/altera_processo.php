<?php
session_start();
if((!isset ($_SESSION['email']) == true) and (!isset ($_SESSION['senha']) == true))
{
  unset($_SESSION['email']);
  unset($_SESSION['senha']);
  header('location:../index.php');
  }
 
$logado=$_SESSION['email'];
echo '<div class="container">';
echo 'Acessado como: $logado';
echo '</div>';
include_once ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../img/icone_barra.jpg" />
	 <title>Alterar Processo</title> 
	 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
  <script type="text/javascript">
 function validacao() {
if(document.form.altera.value=="Selecione...")
{
alert("Por favor selecione o processo.");
document.form.altera.focus();
return false;
}

}
</script>

 </head>
	 <body> <div class="container"><?php include "topo.php"; echo 'Usuário Logado: '; echo $logado; ?> 
 </div>
	 <!-------- inicia pagina-------------->
	 <div class="container">
	<h2 class="form-nome">Alterar processo</h2>
	
<form name="form" method="POST" action="executa/exec_altera_processo.php" onSubmit="return validacao();">
	
	<fieldset class="grupo">
	<div class="form-group">
	<?php 
	$query = mysqli_query($mysqli, "SELECT * FROM cadcompras WHERE situacao = '1' ORDER BY idcompra DESC");
?>
 <label class="form-control" class="form-control" for="">Selecione o processo</label>
 <select class="form-control" name="altera">
 <option class="form-control" name="">Selecione...</option>
 <?php 
 while($busca = mysqli_fetch_array($query)) { 
 ?>
 <option class="form-control" value="<?php 
 echo $busca['idcompra'] 
 ?>">
 <?php 
 echo $busca['processo'].' - '.$busca['finalidade']
 ?></option>
 <?php } ?>
 </select>
 </div>
	</fieldset>
<div class="form-group">
<input type="submit" id="submit" value="Buscar Processo" name="Localizar"/>
<input type="reset" id="reset" value="Limpar" name="limpar"/>
<input type="button" name="cancela" value="Cancelar" onclick="window.location.href='painelr.php'"/>
</div>
</form>
</div>
	<?php include "footer.php"; ?> 
	</body>
 </html>