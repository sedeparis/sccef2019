<?php
session_start();
if((!isset ($_SESSION['email']) == true) and (!isset ($_SESSION['senha']) == true))
{
  unset($_SESSION['email']);
  unset($_SESSION['senha']);
  header('location:../index.php');
  }
 
$logado=$_SESSION['email'];
echo '<div class="container">';
echo 'Acessado como: $logado';
echo '</div>';
include_once ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../img/icone_barra.jpg" />
	 <title>Cadastro de itens da compra</title> 
	 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>

	 <script type="text/javascript">
	  function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
 function moeda(z){
v = z.value;
v=v.replace(/\D/g,"") // permite digitar apenas numero
v=v.replace(/(\d{1})(\d{14})$/,"$1.$2") // coloca ponto antes dos ultimos digitos
v=v.replace(/(\d{1})(\d{11})$/,"$1.$2") // coloca ponto antes dos ultimos 11 digitos
v=v.replace(/(\d{1})(\d{8})$/,"$1.$2") // coloca ponto antes dos ultimos 8 digitos
v=v.replace(/(\d{1})(\d{5})$/,"$1.$2") // coloca ponto antes dos ultimos 5 digitos
v=v.replace(/(\d{1})(\d{1,2})$/,"$1,$2") // coloca virgula antes dos ultimos 2 digitos
z.value = v;
}

 function validacao() {
if(document.form.processo.value=="Selecione...")
{
alert("Por favor selecione o processo.");
document.form.processo.focus();
return false;
}


if(document.form.nitem.value=="")
{
alert("Por favor insira o número do item.");
document.form.nitem.focus();
return false;
}
if(document.form.ditem.value=="")
{
alert("Por favor insira descrição do item.");
document.form.ditem.focus();
return false;
}

if(document.form.quantidade.value=="")
{
alert("Por favor insira a quantidade.");
document.form.quantidade.focus();
return false;
}

if(document.form.un.value=="Selecione...")
{
alert("Por favor selecione a un.");
document.form.un.focus();
return false;
}

}
 </script>
 </head>
	 <body> <div class="container"><?php include "topo.php"; echo 'Usuário Logado: '; echo $logado; ?> 
 </div>
	 
    
	 <div class="container">
	<h2 class="form-nome">Cadastro de itens por compra</h2>
	
	
	<form name="form" method="post" action="salva/vsalva_item.php" onSubmit="return validacao();">
	<fieldset class="grupo">
		 <div class="form-group">
	<?php 
	$query = mysqli_query($mysqli, "SELECT * FROM cadcompras WHERE situacao='1' ORDER BY idcompra DESC");
?>
 <label class="form-control" class="form-control" for="">Selecione uma compra</label>
 <select class="form-control" name="processo">
 <option class="form-control" name="">Selecione...</option>
 <?php while($prod = mysqli_fetch_array($query)) { ?>
 <option class="form-control" value="<?php echo $prod['idcompra'] ?>"><?php echo $prod['processo'].'- '.$prod['finalidade'] ?></option>
 <?php } ?>
 </select>
 </div>
 </fieldset>
 <fieldset class="grupo">
 <div class="form-group">
	<label class="form-control">Descrição do item:</label>
	<textarea class="form-control" id="geral" name="ditem" rows="03" cols="100"></textarea>
		</div>
		</fieldset>
	<fieldset class="grupo">
		 <div class="form-group">
		 
		<label class="form-control">N° do item: Se adesão IRP/ARP informe cfme o pregão do Gerenciador</label>
	<input type="number" class="form-control"  name="nitem" size="2" />
		</div>
		
		 <div class="form-group">
		<label class="form-control">Quantidade Minima  Solicitada:</label>
		<input type="number" class="form-control"  name="quant" size="2" />	
</div>
		 <div class="form-group">
		<label class="form-control">Quantidade Máxima   Solicitada:</label>
		<input type="number" class="form-control"  name="quantidade" size="2" />	
</div>
 <div class="form-group">		
		<?php 
	$query = mysqli_query($mysqli, "SELECT * FROM cdunidade ORDER BY unidade ASC");
?>
 <label class="form-control" class="form-control" for="">Selecione uma  unidade</label>
 <select class="form-control" name="un">
 <option class="form-control" name="">Selecione...</option>
 <?php while($prod = mysqli_fetch_array($query)) { ?>
 <option class="form-control" value="<?php echo $prod['idun']?>"><?php echo $prod['unidade'] ?></option>
 <?php  } ?>
 </select>
		</div>
 </fieldset>
	
		
		<fieldset class="grupo">
 <div class="form-group">
	<input type="submit" value="Cadastrar item"/>
	 <input type="reset" value="Limpar"/>
	 <input type="button" name="cancela" value="Cancelar/Voltar" onclick="window.location.href='painelr.php'"/>
	 </div>
 </fieldset>
</form>
<div id="frame">
<iframe width="100%" height="300px" scrolling="yes" src="../frames/divitem.php"> </iframe>
</div>
</div>
<?php include "footer.php"; ?> 
 </body>
 </html>