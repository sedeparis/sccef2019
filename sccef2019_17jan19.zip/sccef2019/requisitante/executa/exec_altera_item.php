<<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como:  '.$logado;
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<title>Alterar item
</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <link rel="stylesheet" href="../../css/bootstrap.css" type="text/css"/>
  <script type="text/javascript">
	  function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
 
 function moeda(z){
v = z.value;
v=v.replace(/\D/g,"") // permite digitar apenas numero
v=v.replace(/(\d{1})(\d{14})$/,"$1.$2") // coloca ponto antes dos ultimos digitos
v=v.replace(/(\d{1})(\d{11})$/,"$1.$2") // coloca ponto antes dos ultimos 11 digitos
v=v.replace(/(\d{1})(\d{8})$/,"$1.$2") // coloca ponto antes dos ultimos 8 digitos
v=v.replace(/(\d{1})(\d{5})$/,"$1.$2") // coloca ponto antes dos ultimos 5 digitos
v=v.replace(/(\d{1})(\d{1,2})$/,"$1,$2") // coloca virgula antes dos ultimos 2 digitos
z.value = v;
}

 function validacao() {


if(document.form.nitem.value=="")
{
alert("Por favor insira o número do item.");
document.form.nitem.focus();
return false;
}

if(document.form.descricao.value=="")
{
alert("Por favor insira descrição do item.");
document.form.descricao.focus();
return false;
}

if(document.form.un.value=="Selecione...")
{
alert("Por favor selecione a un.");
document.form.un.focus();
return false;
}
if(document.form.situa.value=="Selecione...")
{
alert("Por favor selecione a situacao.");
document.form.situa.focus();
return false;
}

if(document.form.ed.value=="Selecione...")
{
alert("Por favor insira ED.");
document.form.ed.focus();
return false;
}

if(document.form.quant_min.value=="")
{
alert("Por favor insira a quantidade minima.");
document.form.quant_min.focus();
return false;
}
if(document.form.quantidade.value=="")
{
alert("Por favor insira a quantidade máxima.");
document.form.quantidade.focus();
return false;
}
}
 </script>

</head>
<body> <?php include "topo.php"; ?>
<div class="container">
<h2>Alterar item</h2>
<?php
$altera=$_POST['altera'];
// cria a instrução SQL que vai selecionar os dados
$query = sprintf("SELECT * FROM produto WHERE id ='$altera'");
// executa a query
$dados = mysqli_query ($mysqli, $query);
// transforma os dados em um array
$linha = mysqli_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysqli_num_rows($dados);
?>

<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($total > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
		
?>
<form name="form" method="post" action="../salva/vsalva_altera_item.php" onSubmit="return validacao();">
<input type="hidden" name="id" value="<?php print $linha['id']?>"/>
<fieldset class="grupo">
		<div class="form-group">
<label class="form-control">Item  n°:</label>
<input type="text" class="form-control"  size="2" name="nitem" value="<?php print $linha['nitem']?>"/> 
</div>
<div class="form-group">
<label class="form-control">Descrição:</label>
<input type="text"    class="form-control"  size="90" name="descricao" value="<?php print $linha['descricao']?>"/> 
</div>

<div class="form-group">
<?php 
$query = mysqli_query($mysqli, "SELECT * FROM cdunidade");
?>
 <label class="form-control" for="">Selecione uma unidade</label>
 <select class="form-control" name="un">
 <option class="form-control" name="">Selecione...</option>
 <?php while($prod = mysqli_fetch_array($query)) { ?>
 <option  class="form-control" value="<?php echo $prod['idun']?>"><?php echo $prod['unidade'] ?></option>
 <?php  } ?>
 </select>
		</div>
<div class="form-group">
<?php 
$queryb = mysqli_query($mysqli, "SELECT * FROM cdsituacao");
?>
<label class="form-control" for="">Situação  do item:</label> 
<select class="form-control" name="situa">
<option class="form-control" name="">Selecione...</option>
 <?php while($prodb = mysqli_fetch_array($queryb)) { ?>
 <option  class="form-control" value="<?php echo $prodb['idsit']?>"><?php echo $prodb['situacao'] ?></option>
 <?php  } ?>
 </select>
</div>
<div class="form-group">
<label class="form-control">Quant  Mínima:</label>
<input type="number"  class="form-control" size="2" name="estoque_minimo" value="<?php print $linha['estoque_minimo']?>"/> 
</div>
<div class="form-group">
<label class="form-control">Quant  máxima:</label>
<input type="number"  class="form-control" size="2" name="estoque_maximo" value="<?php print $linha['estoque_maximo']?>"/> 
</div>
</fieldset>
<fieldset class="grupo">
		</fieldset>
	<fieldset class="grupo">
		<div class="form-group">
 <input type="submit" value="Alterar" name="altitem"/> 
  <input type="button" name="cancela" value="Cancelar" onclick="window.location.href='../painelr.php'"/>
 </div>
 </fieldset>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = mysqli_fetch_assoc($dados));
	// fim do if 
	}
?>
<?php
// tira o resultado da busca da memória
mysqli_free_result($dados);
?>
</form>
</div>
</div>
 <?php include "footer.php"; ?> 
 <body> 
</html>
