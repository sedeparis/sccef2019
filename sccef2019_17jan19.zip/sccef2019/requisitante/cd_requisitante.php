<?php
session_start();
if((!isset ($_SESSION['email']) == true) and (!isset ($_SESSION['senha']) == true))
{
  unset($_SESSION['email']);
  unset($_SESSION['senha']);
  header('location:../index.php');
  }
 
$logado=$_SESSION['email'];
echo '<div class="container">';
echo 'Acessado como: $logado';
echo '</div>';
include_once ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../img/icone_barra.jpg" />
	 <title>Cadastro de requisitante</title>
	 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	 <script type="text/javascript">
	 function validacao() {
 if(document.form.setor.value=="Selecione...")
{
alert("Por favor selecione o setor.");
document.form.setor.focus();
return false;
}

if(document.form.nome.value=="")
{
alert("Por favor insira o nome do requisitante.");
document.form.nome.focus();
return false;
}

if(document.form.siape.value=="")
{
alert("Por favor insira o siape do requisitante.");
document.form.siape.focus();
return false;
}

}
	 </script>
 </head>
	 <body> <div class="container"><?php include "topo.php"; echo 'Usuário Logado: '; echo $logado; ?> 
 </div>
	 <div class="container">
	<h2 class="form-nome">Cadastro de requisitante</h2>
	<form name="form" method="post" action="salva/salva_requisitante.php"  onSubmit="return validacao();">
	<fieldset class="grupo">	
<div class="form-group">
<?php 
	$query = mysqli_query($mysqli, "SELECT * FROM cdservidor");
?>

 <label class="form-control" class="form-control" for="">Selecione o servidor</label>
 <select class="form-control" name="nome">
 <option class="form-control" name="">Selecione...</option>
 <?php 
 while($busca = mysqli_fetch_array($query)) { 
 ?>
 <option class="form-control" value="<?php 
 echo $busca['nome'] 
 ?>">
 <?php 
 echo $busca['nome']
 ?></option>
 <?php } ?>
 </select>
 </div>
 <label class="form-control" name="func">Função</label>
 <input type="text" class="form-control"  size="50" name="funcao">
	</fieldset>
	<fieldset class="grupo">
		 <div class="form-group">
	<input type="submit" name="enviar" value="Cadastrar Requisitante"/>
	<input type="reset" name="limpar" value="Limpar"/>
	<input type="button" name="cancela" value="Cancelar" onclick="window.location.href='painelr.php'"/>
	</div>
	</fieldset>
</form>
<div id="frame">
<iframe width="940px" height="300px" scrolling="yes" src="../frames/requisitantes.php"> </iframe>
</div>
</div>
<?php include "footer.php"; ?> 
 </body>
 </html>