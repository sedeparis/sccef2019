<?php

include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
	 <title>Cadastro de item</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 <link rel="stylesheet" href="../../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" type="text/css" href="../../css/bootstrap.css" media="screen"/>
 </head>
	 <body>
	 <?php include "topo.php"; ?>
	 <div class="container">
<?php
 

$processo=$_POST['processo'];
$nitem=$_POST['nitem'];
$ditem=$_POST['ditem'];
$quantidade=$_POST['quantidade'];
$quant=$_POST['quant'];
$un=$_POST['un'];

?>
<?php
 $dupesql = "SELECT * FROM produto where nitem = '$nitem' AND idprocesso = '$processo'";

$duperaw = mysqli_query($mysqli, $dupesql);

if (mysqli_num_rows($duperaw) > 0) {
   echo "Número de item já está cadastrado. Favor conferir.<a href='../cd_item.php'>Voltar</a>";
} else {
$sql = mysqli_query($mysqli, "INSERT INTO produto
(status, descricao, estoque_minimo, estoque_maximo, nitem, un, idprocesso, finalizado)
VALUES('1', '$ditem', '$quant', '$quantidade', '$nitem', '$un', '$processo', 0)");
$resultado = mysqli_query($mysqli, $sql);
{echo "<p class='center'>Cadastro efetuado com sucesso!</p>";}

echo "<meta HTTP-EQUIV='refresh' CONTENT='3;URL=../cd_item.php'>";
}
?>


<br /> <p class="center"><img src="../../img/salva.gif"/></p><br />

</div>
<?php include "footer.php"; ?>
</body>
</html>