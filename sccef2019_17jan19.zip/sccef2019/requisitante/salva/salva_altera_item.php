<?php

include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<title>Salva item
</title>
<link rel="stylesheet" type="text/css" href="../../css/reset.css" media="screen"/>
<link rel="stylesheet" type="text/css" href="../../css/bootstrap.css" media="screen"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
</head>
<body>
<?php include "topo.php"; ?>
<div class="container">
<?php
$iditem=$_POST['id'];
$nitem=$_POST['nitem'];
$ditem=$_POST['descricao'];
$un=$_POST['un'];
$situa=$_POST['situa'];
$quant_min=$_POST['estoque_minimo'];
$quant_lic=$_POST['estoque_maximo'];

?>
<?php
$sql = mysqli_query($mysqli, "UPDATE produto SET nitem ='$nitem', descricao ='$ditem', un ='$un', status ='$situa', estoque_maximo='$quant_lic', estoque_minimo='$quant_min' WHERE id ='$iditem'");
$resultado = mysqli_query($mysqli, $sql);
echo "Alteração efetuada.";
?>
 <p class="center"><img src="../../img/salva.gif"/></p>
<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='3;URL=../painelr.php'>";
?>
</div>
<?php include "footer.php"; ?>
</body>
</html>10