<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<title>Cadastro de unidades</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <link rel="stylesheet" type="text/css" href="../../css/reset.css"/>
  <link rel="stylesheet" type="text/css" href="../../css/bootstrap.css" media="screen"/>
</head>
<body>
<?php include "topo.php"; ?>
<div class="container">
<?php
$unidade=$_POST['unidade'];
?>
<?php
$sql = mysqli_query($mysqli, "INSERT INTO cdunidade(unidade)
VALUES('$unidade')");
$resultado = mysqli_query($mysqli, $sql);
{echo "Cadastro efetuado com sucesso!";}
?>
<br /> <p class="center"><img src="../../img/salva.gif"/></p><br />
<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='3;URL=../painelr.php'>";
?>
</div>
<?php include "footer.php"; ?>
</body>
</html>