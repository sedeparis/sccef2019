<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<title>Cadastro de fornecedor</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <link rel="stylesheet" type="text/css" href="../../../css/reset.css"/>
  <link rel="stylesheet" type="text/css" href="../../css/bootstrap.css" media="screen"/>
</head>
<body>
<div class="container">
<?php include "topo.php"; ?>
</div>
<div class="container">
<?php
$nome=$_POST['nome'];
$funcao=$_POST['funcao'];
$consulta = mysqli_query($mysqli, "select * from cdservidor where nome='$nome'");
$rconsulta = mysqli_num_rows($consulta);
if ($rconsulta > 0)

{ echo "" ;}
while ($dados = mysqli_fetch_array($consulta))
{ echo "";
 $siape= $dados['siape'];
 $setor= $dados['idsetor'];
}
?>
<?php
$sql = mysqli_query($mysqli, "INSERT INTO cdrequisitante(nome, siape, setor, funcao)
VALUES('$nome', '$siape', '$setor', '$funcao')");
$resultado = mysqli_query($mysqli, $sql);
{echo "Cadastro efetuado com sucesso!";}
?>
<br /> <p class="center"><img src="../../img/salva.gif"/></p><br />
<?php
echo "<meta HTTP-EQUIV='refresh' CONTENT='3;URL=../painelr.php'>";
?>
</div>
<?php include "footer.php"; ?>
</body>
</html>