<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	echo 'Acessado como: $logado';
	echo '</div>';
include ("../../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg" />
<title>Cadastro de processos</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <link rel="stylesheet" type="text/css" href="../../../css/reset.css"/>
  <link rel="stylesheet" type="text/css" href="../../css/bootstrap.css" media="screen"/>
</head>
<body>
<?php include "topo.php"; ?>
<div class="container">
<?php
$processo=$_POST['processo'];
$finalidade=$_POST['finalidade'];
$observacao=$_POST['observacao'];
$matserv=$_POST['matserv'];
$nomereq=$_POST['nomereq'];
$situacao=$_POST['situacao'];
$numreq=$_POST['numreq'];
$fase=$_POST['fase'];
$datab=$_POST['datab'];
$codreq=$_POST['codreq'];
$scodreq= $codreq + 1;

?>


 <?php
 $dupesq = "SELECT * FROM cadcompras WHERE processo = '$processo'";
$duperaw = mysqli_query($mysqli, $dupesq);

if (mysqli_num_rows($duperaw) > 0) {
   echo "Encontramos um processo já cadastrado com esse número. <a href='../cd_processo.php'>Voltar</a>";
} else {
 $sql = mysqli_query($mysqli, "INSERT INTO cadcompras
 (processo, datab, finalidade,  observacao, numreq, matserv, nomereq, situacao, fase)
 VALUES('$processo','$datab', '$finalidade', '$observacao', '$numreq', '$matserv', '$nomereq', '$situacao', '$fase')");
$resultado = mysqli_query($mysqli, $sql);
echo "Processo cadastrado com sucesso e  ";


//update paametros
$sqlb = mysqli_query($mysqli, "UPDATE param_docs SET codigo='$scodreq' WHERE id = 1");
$resultadob = mysqli_query ($mysqli, $sqlb) ;
echo "parametros atualizados com sucesso!";
}


echo "<meta HTTP-EQUIV='refresh' CONTENT='3;URL=../painelr.php'>";


?>
<br />
<br />
 <p class="center"><img src="../../img/salva.gif"/></p>



</div>
<?php include "footer.php"; ?>
</body>
</html>