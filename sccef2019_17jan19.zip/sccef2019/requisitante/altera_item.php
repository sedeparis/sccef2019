<?php
session_start();
if((!isset ($_SESSION['email']) == true) and (!isset ($_SESSION['senha']) == true))
{
  unset($_SESSION['email']);
  unset($_SESSION['senha']);
  header('location:../index.php');
  }
 
$logado=$_SESSION['email'];
echo '<div class="container">';
echo 'Acessado como: $logado';
echo '</div>';
include_once ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../img/icone_barra.jpg" />
	 <title>Alterar item</title> 
	
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	  <link rel="stylesheet" href="../../css/bootstrap.css" type="text/css"/>
  <link href="../../css/custom.css" rel="stylesheet" />
	  <script type="text/javascript">
 function validacao() {
if(document.form.altera.value=="Selecione...")
{
alert("Por favor selecione o item.");
document.form.altera.focus();
return false;
}
}
</script>
 </head>
	  <body> 
	  <div class="container">
	  <?php include "topo.php"; echo 'Usuário Logado: '; echo $logado; ?> 
 </div>
	 <div class="container">
	<h2 class="form-nome">Alterar item</h2>
	
<form name="form" method="POST" action="executa/exec_altera_item.php" onSubmit="return validacao();">
<fieldset class="grupo">
		 <div class="form-group">
	<?php 
	$query = mysqli_query($mysqli, "SELECT * FROM produto INNER JOIN cadcompras ON produto.idprocesso=cadcompras.idcompra");
?>
 <label class="form-control" class="form-control" for="">Selecione o item</label>
 <select class="form-control" name="altera">
 <option class="form-control" name="">Selecione...</option>
 <?php 
 while($busca = mysqli_fetch_array($query)) { 
 ?>
 <option class="form-control" value="<?php 
 echo $busca['id'] 
 ?>">
 <?php 
 echo $busca['processo'].' - '.$busca['nitem'].' - '.substr($busca['descricao'],0,80);?>
 </option>
 <?php } ?>
 </select>
</div>
	</fieldset>
	<fieldset class="grupo">
		 <div class="form-group">
<input type="submit" id="submit" value="Buscar item" name="Localizar"/>
<input type="reset" id="reset" value="Limpar item" name="reset"/>
<input type="button" name="cancela" value="Cancelar" onclick="window.location.href='painelr.php'"/>
</div>
	</fieldset>
</form>
</div>

	<?php include "footer.php"; ?> 
	</body>
 </html>