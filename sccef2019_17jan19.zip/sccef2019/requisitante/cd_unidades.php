<?php
session_start();
if((!isset ($_SESSION['email']) == true) and (!isset ($_SESSION['senha']) == true))
{
  unset($_SESSION['email']);
  unset($_SESSION['senha']);
  header('location:../index.php');
  }
 
$logado=$_SESSION['email'];
echo '<div class="container">';
echo 'Acessado como: $logado';
echo '</div>';
include_once ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<link rel="icon" type="image/jpg" href="../img/icone_barra.jpg" />
	 <title>Cadastro de unidades</title> 
	 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/> 
	 <script type="text/javascript">
	 function validacao() {
 
if(document.form.unidade.value=="")
{
alert("Por favor insira uma unidade.");
document.form.unidade.focus();
return false;
}

}
	 </script>
 </head>
	 <body> <div class="container"><?php include "topo.php"; echo 'Usuário Logado: '; echo $logado; ?> 
 </div>
	 
	 <div class="container">
	<h2 class="form-nome">Cadastro de Unidades</h2>
	<form name="form" method="post" action="salva/salva_unidades.php"  onSubmit="return validacao();">
	<fieldset class="grupo">
	<div class="form-group">
		 <?php	   
  $query = mysqli_query($mysqli, "SELECT * FROM cdunidade ORDER BY unidade ASC");
?>
 <label class="form-control" class="form-control" for="">Verifique se a unidade est?  cadastrada:</label>		     
 <select class="form-control" name="unid">
 <option class="form-control" name="">Selecione...</option>
 <?php while($lista = mysqli_fetch_array($query)) { ?>
 <option class="form-control" value="<?php echo $lista['unidade'] ?>"><?php echo $lista['unidade'] ?></option>
 <?php } ?>
 </select>
 </div>
		 <div class="form-group">
			<label class="form-control">Cadastre a Unidade:</label>
<input type="text" class="form-control"  name="unidade" size="15" title="unidade"/>
</fieldset>
	<fieldset class="grupo">
		 <div class="form-group">
	<input type="submit" name="enviar" value="Cadastrar unidades"/>
	<input type="reset" name="limpar" value="Limpar"/>
	<input type="button" name="cancela" value="Cancelar" onclick="window.location.href='painelr.php'"/>
	</div>
	</fieldset>
</form>
</div>
<?php include "footer.php"; ?> 
 </body>
 </html>