﻿<?php
session_start();
if((!isset ($_SESSION['email']) == true) and (!isset ($_SESSION['senha']) == true))
{
  unset($_SESSION['email']);
  unset($_SESSION['senha']);
  header('location:../index.php');
  }
 
$logado=$_SESSION['email'];
echo '<div class="container">';
echo 'Acessado como: $logado';
echo '</div>';
include_once ("../conecta_banco.php");
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Sistema Administrativo compras públicas.</title>
<!-- BOOTSTRAP STYLES-->
<link href="../css/bootstrap.css" rel="stylesheet" />
<!-- FONTAWESOME STYLES-->
<link href="../css/font-awesome.css" rel="stylesheet" />
<!-- CUSTOM STYLES-->
<link href="../css/custom.css" rel="stylesheet" />
<!-- GOOGLE FONTS-->

</head>
<body>
<script type="text/javascript" src="../js/wz_tooltip.js"></script>  
<div id="wrapper">

<div class="navbar navbar-inverse navbar-fixed-top">
<div class="adjust-nav">
<div class="navbar-header">
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a class="navbar-brand" href="#">
<img src="../img/logoif.jpg" />
</a>
</div>
<span class="logout-spn" >
<a href="logoutr.php" style="color:#fff;">LOGOUT</a>
</span>
</div>
</div>
<!-- /. NAV TOP  -->
<nav class="navbar-default navbar-side" role="navigation">
<div class="sidebar-collapse">
<ul class="nav" id="main-menu">
<li class="active-link">
<a href="../admin/index.php"><i class="fa fa-desktop "></i>Admin<span class="badge"></span></a>
</li>
<li>
<a href="painelr.php"><i class="fa fa-user"></i>
Requisitante</a>
</li>
<li>
<a href="../compras/painel.php"><i class="fa fa-shopping-cart"></i>
Compras</a>
</li>
<li>
<a href="../almoxarifado/painel_alm.php"><i class="fa fa-print"></i>Almoxarifado</a>
</li>
<li>
<a href="../controles/painelctrl.php"><i class="fa fa-print"></i>Controles</a>
</li>
<li>
<a href="../sobre.php"><i class="fa fa-edit"></i>Ajuda/sobre<span class="badge"></span></a>
</li>
</ul>
</div>
</nav>
<!-- /. NAV SIDE  -->
<div id="page-wrapper" >
<div id="page-inner">
<div class="row">
<div class="col-lg-12">
<h2 class="form-nome">PAINEL REQUISITANTE</h2>
</div>
</div>
<!-- /. ROW  -->
<hr />
<div class="row">
<div class="col-lg-12 ">
<div class="alert alert-info">
<strong>Bem vindo <?php echo "$logado! Você está logado!";?> </strong>
</div>
</div>
</div>
<!-- /. ROW  -->
<!-- secção 1 --->
<div class="row text-center pad-top">
<h3>Gerais</h3>
<p class="center">Rotinas com * obrigatórias para funcionamento do sistema</p>

<!-------- new atalho 1----->
<div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
<div class="div-square">
<a href="cd_unidades.php" >
<i class="fa fa-pencil fa-3x"></i>
<h6>Incluir</h6>
<h6>Unid</h6>
</a>
</div>
</div>
<!-------- new atalho 2----->
<div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
<div class="div-square">
<a href="altera_unidade.php" >
<i class="fa fa-edit fa-3x"></i>
<h6>Alterar</h6>
<h6>Unid</h6>
</a>
</div>
</div>
<!-------- new atalho 3----->
<div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
<div class="div-square">
<a href="cd_processo.php" >
<i class="fa fa-pencil fa-3x"></i>
<h6>*Incluir</h6>
<h6>Processo</h6>
</a>
</div>
</div>
<!-------- new atalho 4---->
<div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
<div class="div-square">
<a href="altera_processo.php" >
<i class="fa fa-edit fa-3x"></i>
<h6>Alterar</h6>
<h6>Processo</h6>
</a>
</div>
</div>
<!-------- 5 new atalho ----->
<div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
<div class="div-square">
<a href="cd_item.php" >
<i class="fa fa-coffee fa-3x"></i>
<h6>*Incluir</h6>
<h6>Item</h6>
</a>
</div>
</div>
<!-------- 6 new atalho ----->
<div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
<div class="div-square">
<a href="altera_item.php" >
<i class="fa fa-edit fa-3x"></i>
<h6>Alterar</h6>
<h6>Item</h6>
</a>
</div>
</div>
</div>
<!-- /. ROW  -->
<!-- secção2 --->
<div class="row text-center pad-top">
<!-------- new atalho 1----->
<!-- a1--> 
<!-------- new atalho 1 ----->
<div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
<div class="div-square">
<a href="cd_requisitante.php" >
<i class="fa fa-user fa-3x"></i>
<h6>Incluir</h6>
<h6>Requisitante</h6>
</a>
</div>
</div>
<div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
<div class="div-square">
<a href="imprime_lista_itens.php" >
<i class="fa fa-search fa-3x"></i>
<h6>Listar</h6>
<h6>Itens</h6>
</a>
</div>
</div>
</div>
<!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->
</div>
</div>


<div class="footer">
<div class="row">
<div class="col-lg-12" >
<?php 

include '../versao.php';
?> 
</div>
</div>
</div>
<!-- /. WRAPPER  -->
<!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
<!-- JQUERY SCRIPTS -->
<script src="../js/jquery.js"></script>
<!-- BOOTSTRAP SCRIPTS -->
<script src="../js/bootstrap.min.js"></script>
<!-- CUSTOM SCRIPTS -->
<script src="../js/custom.js"></script>

</div>
</body>
</html>