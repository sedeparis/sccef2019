<?php
include "../conecta_banco.php";?>
<!DOCTYPE HTML>
<html lang="pt_br">
<head>
<title>relatórios</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	 <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/custom.css" type="text/css"/>
	  <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	 <script type="text/javascript">
	 function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }

 function validacao() {
 if(document.form.fornecedor.value=="Selecione...")
{
alert("Por favor selecione um fornecedor.");
document.form.fornecedor.focus();
return false;
}

}
	 </script>
 </head>
	  	 <body> 
		 <?php include "topo.php"; ?>
	 	 <div class="container">
	<h2>Lista compras por fornecedor</h2>
<form name="form" action="exec_valor_fornecedor.php" method="post" onSubmit="return validacao();">
<fieldset class="grupo">
		 	<div class="form-group">
			 	<?php 
	$query = mysqli_query($mysqli, "SELECT DISTINCT fornecedora, idforn, nome FROM produto INNER JOIN cadfornecedor 
on produto.fornecedora=cadfornecedor.idforn	ORDER BY nome ASC");
?>
 <label class="form-control" for="">Selecione um fornecedor</label>
 <select class="form-control" name="fornecedor">
 <option class="form-control" name="">Selecione...</option>
 
 <?php while($prod = mysqli_fetch_array($query)) { ?>
 <option class="form-control" value="<?php echo $prod['idforn'] ?>"><?php echo $prod['nome'] ?></option>
 <?php } ?>
 </select>
		</div>
	</fieldset>
 <div class="form-group">
<input type="submit" name="Seleciona" Value="Selecionar Compras">
<input type="reset" name="Seleciona" Value="Limpar">
<input type="button" name="cancela" value="Cancelar" onclick="window.location.href='../almoxarifado/painel_alm.php'"/>
</div>
</form>
</div>
</body>
</html>