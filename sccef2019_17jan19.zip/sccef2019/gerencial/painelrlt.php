﻿<?php
session_start();
$_SESSION['email'];
$_SESSION['senha'];
header ('autenticar.php');
$logado=$_SESSION['email'];
echo '<div class="container">';
echo 'Acessado como: $logado';
echo '</div>';
include ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Sistema Administrativo compras públicas.</title>
<!-- BOOTSTRAP STYLES-->
<link href="../css/bootstrap.css" rel="stylesheet" />
<!-- FONTAWESOME STYLES-->
<link href="../css/font-awesome.css" rel="stylesheet" />
<!-- CUSTOM STYLES-->
<link href="../css/custom.css" rel="stylesheet" />
<!-- GOOGLE FONTS-->

</head>
<body>         
<div id="wrapper">
<div class="navbar navbar-inverse navbar-fixed-top">
<div class="adjust-nav">
<div class="navbar-header">
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a class="navbar-brand" href="#">
<img src="../img/logoif.jpg" />
</a>
</div>
<span class="logout-spn" >
<a href="../logout.php" style="color:#fff;">LOGOUT</a>  
</span>
</div>
</div>
<!-- /. NAV TOP  -->
<nav class="navbar-default navbar-side" role="navigation">
<div class="sidebar-collapse">
<ul class="nav" id="main-menu">
<li class="active-link">
<a href="../logout.php" ><i class="fa fa-desktop "></i>Inicial<span class="badge"></span></a>
</li>
<li>
<a href="../requisitante/requis.php"><i class="fa fa-user "></i>
Requisitante</a>
</li>
<li>
<a href="../compras.php"><i class="fa fa-shopping-cart "></i>
Compras</a>
</li>
<li>
<a href="../almox/almoxarifado.php"><i class="fa fa-barcode "></i>Almoxarifado </a>
</li>
<li>
<a href="../sobre.php"><i class="fa fa-edit "></i>Ajuda/sobre  <span class="badge"></span></a>
</li>               
</ul>
</div>
</nav>
<!-- /. NAV SIDE  -->
<div id="page-wrapper" >
<div id="page-inner">
<div class="row">
<div class="col-lg-12">
<h2>PAINEL GERENCIAL</h2>   
</div>
</div>              
<!-- /. ROW  -->
<hr />
<div class="row">
<div class="col-lg-12 ">
<div class="alert alert-info">
<strong>Bem vindo <?php echo "$logado!";?> </strong>
</div>
</div>
</div>
<!-- /. ROW  --> 
<div class="row text-center pad-top">
<h3>RELATORIOS DE COMPRAS</h3>
<!--- menu 1--->
<div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
<div class="div-square">
<a href="cd_orgao.php" >
<i class="fa fa-print fa-3x"></i>
<h4>Relatorio</h4>
</a>
</div>
</div>
<!--- menu 2--->
<div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
<div class="div-square">
<a href="altera_orgao.php" >
<i class="fa fa-print fa-3x"></i>
<h4>Relatorio</h4>
</a>
</div>
</div>
		<!--- menu 3--->
<div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
<div class="div-square">
<a href="altera_txt_modal.php" >
<i class="fa fa-print fa-3x"></i>
<h4>Relatorio</h4> 
</a>
</div>
</div>
		<!--- menu 4--->
<div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
<div class="div-square">
<a href="detalhamento_orcamentario.php" >
<i class="fa fa-print fa-3x"></i>
<h4>Relatorio</h4>
</a>
</div>  
</div>
<!--- menu 5--->
<div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
<div class="div-square">
<a href="detalhamento_orcamentario.php" >
<i class="fa fa-print fa-3x"></i>
<h4>Relatorio</h4>
</a>
</div>  
</div>
<!--- menu 6--->
<div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
<div class="div-square">
<a href="detalhamento_orcamentario.php" >
<i class="fa fa-print fa-3x"></i>
<h4>Relatorio</h4>
</a>
</div>  
</div>
</div>
<!-- /. ROW  --> 
<div class="row text-center pad-top">
<h3>RELATORIOS DE DIRAD</h3>
<!--- menu 1--->
<div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
<div class="div-square">
<a href="cd_orgao.php" >
<i class="fa fa-print fa-3x"></i>
<h4>Relatorio</h4>
</a>
</div>
</div>
<!--- menu 2--->
<div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
<div class="div-square">
<a href="altera_orgao.php" >
<i class="fa fa-print fa-3x"></i>
<h4>Relatorio</h4>
</a>
</div>
</div>
		<!--- menu 3--->
<div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
<div class="div-square">
<a href="altera_txt_modal.php" >
<i class="fa fa-print fa-3x"></i>
<h4>Relatorio</h4> 
</a>
</div>
</div>
		<!--- menu 4--->
<div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
<div class="div-square">
<a href="detalhamento_orcamentario.php" >
<i class="fa fa-print fa-3x"></i>
<h4>Relatorio</h4>
</a>
</div>  
</div>
<!--- menu 5--->
<div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
<div class="div-square">
<a href="detalhamento_orcamentario.php" >
<i class="fa fa-print fa-3x"></i>
<h4>Relatorio</h4>
</a>
</div>  
</div>
<!--- menu 6--->
<div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
<div class="div-square">
<a href="detalhamento_orcamentario.php" >
<i class="fa fa-print fa-3x"></i>
<h4>Relatorio</h4>
</a>
</div>  
</div>
</div>

<!-- /. ROW  --> 
</div>
<!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->
</div>
<div class="footer">
<div class="row">
<div class="col-lg-12" >
&copy;  2017 Sisad | Design by: <a href="http://binarytheme.com" style="color:#fff;" target="_blank">www.binarytheme.com</a>
</div>
</div>
</div>
<!-- /. WRAPPER  -->
<!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
<!-- JQUERY SCRIPTS -->
<script src="js/jquery.js"></script>
<!-- BOOTSTRAP SCRIPTS -->
<script src="js/bootstrap.min.js"></script>
<!-- CUSTOM SCRIPTS -->
<script src="js/custom.js"></script>
<!--- secao pesquisa 
<div id="col5">
<fieldset class="titulo">
<h2 class="painel">Pesquisas de processos por:</h2>
</fieldset>
<fieldset>
<input class="form-control"  class="button" value="Finalidade" onclick="location.href='filtro_processo_finalidade.php'" type="button">
<input class="form-control"  class="button" value="Gerenciador" onclick="location.href='filtro_processo_gerenciador.php'" type="button">
<input class="form-control"  class="button" value="Número da Compra" onclick="location.href='filtro_processo_num_compra.php'" type="button">
<input class="form-control"  class="button" value="Situação" onclick="location.href='filtro_processo_situacao.php'" type="button">
<input class="form-control"  class="button" value="Idade Arquivística" onclick="location.href='filtro_processo_idade.php'" type="button"> 
</fieldset>------------>
</div>
</body>
</html>