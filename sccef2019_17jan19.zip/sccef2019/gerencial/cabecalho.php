<?php
include ("../conecta_banco.php");
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
      <meta charset="utf-8" />
   
   
	 <link href="../css/cabecalho.css" rel="stylesheet" />
	   
		<!--- scripts de validação de formulário --->
 </head>
	 <body> 
	 <?php
// cria a instrução SQL que vai selecionar os dados para o cabeçalho
$sql = mysqli_query($mysqli, "SELECT * FROM cdorgao WHERE orgao_principal = 'S'");
 $count = mysqli_num_rows($sql);
if ($count == 0) 
{ echo "Nenhum resultado!" ;}
while ($dados = mysqli_fetch_array($sql))
{ echo "";
 $endereco=$dados['endereco'];
 $orgao=$dados['nome'];
 $dirad=$dados['gestor'];
 $dirge=$dados['diretor'];
$local= $dados['cidade'];
 $uf=$dados['uf'];
 $fonte=$dados['fonte'];
 $preprocesso=$dados['iniprocesso'];
 }
 ?>
 <div class="mae">
 <!--- para fazer a margem da folha e o brasao --->

 <!--- inserir o brasao da republica --->
 <div class="brasao">
 <img src="../img/brasao.jpg" />
 </div>
 
 <!--- inserir dados do orgao--->
 <div class="ddorgao">
 <?php echo '<h3>MINISTÉRIO DA EDUCAÇÃO</h3>' ?>
  <?php echo '<h4>Secretaria da Educação Profissional e Tecnológica</h4>'?>
   <?php echo '<p>' .$orgao. '</p>' ?>
 </div>
 <!--- inserir logo do if --->
 <div class="logo">
 <img src="../img/iflogo.png" />
 </div>
 <!--- inserir margem do logo do if ate margem--->

 </div>
 </body>
</html>
 	
