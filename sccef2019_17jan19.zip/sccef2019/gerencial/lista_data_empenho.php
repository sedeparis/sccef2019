<?php
include "../conecta_banco.php";
?>
<!DOCTYPE HTML>
<html lang="pt_br">
<head>
<title>relatórios</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		 <link href="../css/print_tab.css" rel="stylesheet" />
	  <link href="../css/print_div.css" rel="stylesheet" />
	   <link href="../css/print_fontes.css" rel="stylesheet" />
</head>
 <body>
	 <div class="cabecalho">
	  <?php include "cabecalho.php"; ?> 
	  </div>
	 <div class="titulo">
	  <h3>COMPRAS COM ITENS EMPENHADOS PARCIALMENTE (desenvolvimento)</h3>
	  </div>
<div class="tabela">

<?php
// cria a instrução SQL que vai selecionar os dados
$query = sprintf("SELECT * FROM produto inner join estoque_ie on
produto.id=estoque_ie.id_produto_ie
inner join estoque on estoque.qtde=estoque_ie.qtde_ie
inner join cadfornecedor on produto.fornecedora=cadfornecedor.idforn
inner join cdunidade on produto.un=cdunidade.idun
inner join cadcompras on produto.idprocesso=cadcompras.idcompra
WHERE qtde_ie > 0  AND qtde_ie <> qtde");
// executa a query
$dados = mysqli_query($mysqli, $query) or die(mysqli_error($mysqli));
// transforma os dados em um array
$linha = mysqli_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysqli_num_rows($dados);
?>

<?php
if($total == 0)  { echo 'Sua pesquisa não retornou nenhum resultado!';}
	// se o número de resultados for maior que zero, mostra os dados//
	if($total > 0) { 
		// inicia o loop que vai mostrar todos os dados
		do {
		$nitem=$linha['nitem'];
		$ditem=$linha['descricao'];
		$un=$linha['unidade'];
		$fornec=$linha['nome'];	
		$proc=$linha['processo'];
		$qtd=$linha['qtde_ie']; 
		$nempenho=$linha['nempenho_ie']; 
		$fornec=$linha['nome'];
?>
<table>
<colgroup>
<col width="6%">
<col width="4%">
<col width="50%">
<col width="20%">
<col width="5%">
<col width="5%">
<col width="10%">
</colgroup>
<thead>
<tr>
<th>Processo</th>
<th>Item</th>
<th>Descrição</th>
<th>Fornecedor</th>
<th>Qt</th>
<th>UN</th>
<th>Empenho</th>
</tr>
</thead>

<colgroup>
<col width="6%">
<col width="4%">
<col width="50%">
<col width="20%">
<col width="5%">
<col width="5%">
<col width="10%">
</colgroup>
<tbody>
<tr>
<td><?php echo "$proc"?></td>
<td><?php echo "$nitem"?></td>
<td><?php echo "$ditem"?></td>
<td><?php echo "$fornec"?></td>
<td><?php echo "$qtd"?></td>
<td><?php echo "$un"?></td>
<td><?php echo "$nempenho"?></td>
</tr>
</tbody>
</table>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = mysqli_fetch_assoc($dados));
	// fim do if 
	}
?>
<?php
// tira o resultado da busca da memória
mysqli_free_result($dados);
?>

</div>
<div class="button">
 <input type="button" name="ok" value="Voltar" onclick="window.location.href='../almoxarifado/painel_alm.php'"/>
</div>
</body>
</html>
