<?php
include "../conecta_banco.php";

?>
<!DOCTYPE HTML>
<html lang="pt_br">
<head>
<title>relatórios</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		 <link href="../css/print_tab.css" rel="stylesheet" />
	  <link href="../css/print_div.css" rel="stylesheet" />
	   <link href="../css/print_fontes.css" rel="stylesheet" />
</head>
<body>
 
	 <div class="cabecalho">
	  <?php include "cabecalho.php"; ?> 
	  </div>
	 <div class="titulo">
	  <h3>Pedidos pendentes de entrega</h3>
	  </div>
<div class="tabela">
<?php


// cria a instrução SQL que vai selecionar os dados
$query = sprintf("SELECT * FROM produto inner join estoque_ee on
produto.id=estoque_ee.id_produto_ee
inner join cadfornecedor on produto.fornecedora=cadfornecedor.idforn
inner join cdunidade on produto.un=cdunidade.idun
inner join cadcompras on produto.idprocesso=cadcompras.idcompra
WHERE qtde_ee >0 ");
// executa a query
$dados = mysqli_query($mysqli, $query) or die(mysqli_error($mysqli));
// transforma os dados em um array
$linha = mysqli_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysqli_num_rows($dados);
?>

<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($total > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
		$nitem=$linha['nitem'];
		$ditem=$linha['descricao'];
		$un=$linha['unidade'];
		$fornec=$linha['nome'];	
		$proc=$linha['processo'];
?>
<table>
<colgroup>
<col width="20%">
<col width="6%">
<col width="60%">
<col width="14%">
</colgroup>
<thead>
<tr>
<th>Processo</th>
<th>It</th>
<th>Descrição</th>
<th>UN</th>
</tr>
</thead>

<colgroup>
<col width="20%">
<col width="6%">
<col width="60%">
<col width="14%">
</colgroup>
<tbody>
<tr>
<td><?php echo "$proc"?></td>
<td><?php echo "$nitem"?></td>
<td><?php echo "$ditem"?></td>
<td><?php echo "$un"?></td>
</tr>
</tbody>
</table>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = mysqli_fetch_assoc($dados));
	// fim do if 
	}
?>
<?php
// tira o resultado da busca da memória
mysqli_free_result($dados);
?>
	
</div>
<br>
<div class="button">
 <input type="button" name="ok" value="Voltar" onclick="window.location.href='../almoxarifado/painel_alm.php'"/>
</div>
</body>
</html>

