<?php
include "../conecta_banco.php";?>
<!DOCTYPE HTML>
<html lang="pt_br">
<head>
<title>relatórios</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	 <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/custom.css" type="text/css"/>
	  <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	 <script type="text/javascript">
	 function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }

 function validacao() {
 if(document.form.datai.value=="")
{
alert("Por favor informe a data inicial.");
document.form.datai.focus();
return false;
}

if(document.form.dataf.value=="")
{
alert("Por favor informe a data final.");
document.form.dataf.focus();
return false;
}
}
	 </script>
 </head>
	  	 <body> 
		 <?php include "topo.php"; ?>
	 	 <div class="container">
	<h2>Lista compras por período</h2>
<form name="form" action="exec_compras_periodo.php" method="post" onSubmit="return validacao();">
<fieldset class="grupo">
		 <div class="form-group">
<label class="form-control">Entre com a data inicial</label>
<input class="form-control" type="text" name="datai" size="10" onkeypress="mascara(this, '##/##/####')"  maxlength="10"/>
</div>
 <div class="form-group">
<label class="form-control">Entre com a data final</label>
<input class="form-control" type="text" name="dataf" size="10" onkeypress="mascara(this, '##/##/####')"  maxlength="10"/>
</div>
	</fieldset>
 <div class="form-group">
<input type="submit" name="Seleciona" Value="Selecionar Compras">
<input type="reset" name="Seleciona" Value="Limpar">
<input type="button" name="cancela" value="Cancelar" onclick="window.location.href='../almoxarifado/painel_alm.php'"/>
</div>
</form>
</div>
</body>
</html>