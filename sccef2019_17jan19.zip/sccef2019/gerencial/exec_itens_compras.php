﻿<?php
session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	//echo 'Acessado como: $logado';
	echo '</div>';
include "../conecta_banco.php";
?>
<!DOCTYPE HTML>
<html lang="pt_br">
<head>
<link rel="icon" type="image/jpg" href="../img/icone_barra.jpg" />
<title>relatórios</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		 <link href="../css/print_tab.css" rel="stylesheet" />
	  <link href="../css/print_div.css" rel="stylesheet" />
	   <link href="../css/print_fontes.css" rel="stylesheet" />
</head>
 <body>
	 <div class="cabecalho">
	  <?php include "cabecalho.php"; ?> 
	  </div>
	 <div class="titulo">
	  <h3>Compras-itens por compras</h3>
	  </div>
<?php
$processo=$_POST['processo'];
// cria a instrução SQL que vai selecionar os dados de processo
$query = ("SELECT * FROM cadcompras WHERE idcompra = '$processo'");
// executa a query
$dadosa = mysqli_query($mysqli, $query) or die(mysqli_error(mysqli));
// transforma os dados em um array
$linhaa = mysqli_fetch_assoc($dadosa);
// calcula quantos dados retornaram
$totala = mysqli_num_rows($dadosa);
?>
<!-- mostra itens empenhados-->

<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($totala > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
$processob=$linhaa['processo'];
$finalidade=$linhaa['finalidade'];
?>

<?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = mysqli_fetch_assoc($dadosa));
	// fim do if 
	}
?>
<div class="textos">
<span class="subtitulo">
Processo:
</span>
<span class="rsubtitulo">
 <?php echo "$processob"?>
 </span>
<br>
<span class="subtitulo">
Finalidade:
</span>
<span class="rsubtitulo">
 <?php echo "$finalidade"?>
 </span>
<br>
</div>

<div class="tabela">
<?php


// cria a instrução SQL que vai selecionar os dados
$query = sprintf("SELECT * FROM produto 
inner join cadfornecedor on produto.fornecedora=cadfornecedor.idforn
inner join cdunidade on produto.un=cdunidade.idun
inner join cadcompras on produto.idprocesso=cadcompras.idcompra
WHERE idcompra ='$processo' ");
// executa a query
$dados = mysqli_query($mysqli, $query) or die(mysqli_error($mysqli));
// transforma os dados em um array
$linha = mysqli_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysqli_num_rows($dados);
?>

<?php
	// se o número de resultados for maior que zero, mostra os dados//
	if($total > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {
		$nitem=$linha['nitem'];
		$ditem=$linha['descricao'];
		$un=$linha['unidade'];
		$fornec=$linha['nome'];	
		$proc=$linha['processo'];
			$emax=$linha['estoque_maximo'];
?>
<table>
<colgroup>
<col width="6%">
<col width="70%">
<col width="14%">
<col width="10%">
</colgroup>
<thead>
<tr>
<th>It</th>
<th>Descrição</th>
<th>UN</th>
<th>Qt Lic</th>
</tr>
</thead>

<colgroup>
<col width="6%">
<col width="70%">
<col width="14%">
<col width="10%">
</colgroup>
<tbody>
<tr>

<td><?php echo "$nitem"?></td>
<td><?php echo "$ditem"?></td>
<td><?php echo "$un"?></td>
<td><?php echo "$emax"?></td>
</tr>
</tbody>
</table>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = mysqli_fetch_assoc($dados));
	// fim do if 
	}
?>
<?php
// tira o resultado da busca da memória
mysqli_free_result($dados);
?>
	
</div>
<div class="button">
<input type="button" name="voltar" value="Voltar" onclick="window.location.href='../almoxarifado/painel_alm.php'"/>
</div>
	
	</body>
	</html>