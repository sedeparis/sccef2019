﻿ <?php
 session_start();
	$_SESSION ['email'];
	$_SESSION ['senha'];
	$logado=$_SESSION ['email'];
	echo '<div class="container">';
	//echo 'Acessado como: $logado';
	echo '</div>';
include "../conecta_banco.php";

?>
<!DOCTYPE HTML>
<html lang="pt_br">
<head>
  <link rel="icon" type="image/jpg" href="../img/icone_barra.jpg" />
	 <title>Lista compras por periodo</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 	 <link href="../css/print_tab.css" rel="stylesheet" />
	  <link href="../css/print_div.css" rel="stylesheet" />
	   <link href="../css/print_fontes.css" rel="stylesheet" />
</head>
 <body>
	 <div class="cabecalho">
	  <?php include "cabecalho.php"; ?> 
	  </div>
	 <div class="titulo">
  	 <h3>Compras empenhadas por fornecedor</h3>
	 </div>
	 <div class="tabela">
<?php
$fornecedor=$_POST['fornecedor'];
// cria a instrução SQL que vai selecionar os dados da soma total de empenho

// cria a instrução SQL que vai selecionar os dados
$query = sprintf("SELECT * FROM produto
inner join entrada_produto_ie on produto.id=entrada_produto_ie.id_produto_ie
inner join cadfornecedor on produto.fornecedora=cadfornecedor.idforn
inner join cdunidade on produto.un=cdunidade.idun
inner join cadcompras on produto.idprocesso=cadcompras.idcompra
WHERE fornecedora = '$fornecedor' AND nempenho <> '' ");
// executa a query
$dados = mysqli_query($mysqli, $query) or die(mysqli_error($mysqli));
// transforma os dados em um array
$linha = mysqli_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysqli_num_rows($dados);
?>

<?php
if($total == 0)  { echo 'Sua pesquisa não retornou nenhum resultado!';}
	// se o número de resultados for maior que zero, mostra os dados//
	if($total > 0) { 
		// inicia o loop que vai mostrar todos os dados
		do {
		$nitem=$linha['nitem'];
		$ditem=$linha['descricao'];
		$un=$linha['unidade'];
		$fornec=$linha['nome'];	
		$proc=$linha['processo'];
		$valoru=$linha['valor_unitario'];
	$valori=number_format($valoru, 2, ',', '.');
?>
<table>
<colgroup>
<col width="24%">
<col width="6%">
<col width="40%">
<col width="15%">
<col width="15%">
</colgroup>
<thead>
<tr>
<th>Processo</th>
<th>It</th>
<th>Descrição</th>
<th>UN</th>
<th>Valor</th>
</tr>
</thead>

<colgroup>
<col width="24%">
<col width="6%">
<col width="40%">
<col width="15%">
<col width="15%">
</colgroup>
<tbody>
<tr>
<td><?php echo "$proc"?></td>
<td><?php echo "$nitem"?></td>
<td><?php echo "$ditem"?></td>
<td><?php echo "$un"?></td>
<td><?php echo "$valori"?></td>
</tr>
</tbody>
</table>
<?php
		// finaliza o loop que vai mostrar os dados
		}while($linha = mysqli_fetch_assoc($dados));
	// fim do if 
	}
?>
<?php
// tira o resultado da busca da memória
mysqli_free_result($dados);
?>

<br>

</div>

<div class="button">
 <input type="button" name="ok" value="Voltar" onclick="window.location.href='../almoxarifado/painel_alm.php'"/>
</div>

</body>
</html>

