<?php 
$email= $_POST['email'];
$senha= md5($_POST['senha']);
include ("conecta_banco.php");
$sql = mysqli_query($mysqli, "SELECT * FROM users WHERE email = '$email' 
AND senha= '$senha' 
AND situacao = 1  ") or die (mysqli_error($mysqli));
$row = mysqli_num_rows($sql);
if($row > 0){
	session_start();
	$_SESSION ['email']=$_POST['email'];
	$_SESSION ['senha']=md5($_POST['senha']);
	$_SESSION ['situacao']=['1'];
	echo '<p class="center">Autenticando!</p>';
	echo '<p class="center"><img src="img/processa.gif"/></p>';
	echo "<meta HTTP-EQUIV='refresh' CONTENT='2;URL=inicial.php'>";
	//echo '<script>loginsucessfuly()</script>';
} else {
	echo 'Usuário ou senha invalida ou sem autorização de acesso';
	echo "<meta HTTP-EQUIV='refresh' CONTENT='3;URL=index.php'>";
}
session_regenerate_id();

?>
<!DOCTYPE HTML> 
<html lang="pt_BR">
<head>
<title>Acesso de usuario
</title> 
<link rel="stylesheet" href="css/bootstrap.css" type="text/css"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	 <link rel="stylesheet" href="css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="css/estilo.css" type="text/css"/>
	 <link rel="stylesheet" href="css/custom.css" type="text/css"/>
<script type="text/javascript" >

</head>
<!-------- inicia pagina-------------->
<body>
<div class="container">
<?php include "topo.php"; ?> 
 </div>
<div class="container">

<br />
<br />
<br />
<br />
<p class="center">
<img src="img/baile.gif"/></p>

</div>
<?php include "footer.php"; ?>
</body>
</html>