﻿<!DOCTYPE HTML>
<html lang="pt-br">
<head>
<title>Sccef- Sobre</title>
</head>
<body> <div class="container">
<?php include "topo.php"; ?> </div>
	 <!-------- inicia pagina-------------->
	 <div class="container">
	 <div id="sobre">
	  <img src="img/logosccef.jpg" />
	 
	<h2 class="form-nome">Sobre</h2> 
	<p>O SCCEF- Sistema Administrativo para compras, empenho, fornecimento é um sistema de uso em serviço público ou em gestões de compras em Órgãos que recebem 
	recursos públicos e necessitam realizar compras licitadas.</p>
	<p>Sua funcionalidade foi pensada paa permitir controle de bens licitados, empenhados, solicitados e fornecidos bem como estatísticss das compras.</p>
	<p>Foi idealizado como apoio as rotinas de trabalho do IFMS Campus Dourados relativa aos procedimentos de compras públicas.</p>
	<p>Sugestões e melhorias podem ser encaminhadas para o e-mail sedeparis@gmail.com ou sedenir.deparis@ifms.edu.br.</p>
	<p>O Código Fonte pode ser adptado, melhorado para outros projetos desde que distribuido livremente sob a licença GLP.</p>
<p class="center">Sistema desenvolvido com: php5, html4, Mysql, Notepad++.</p>
<input class="form-control-2"  type="button" name="cancela" value="Voltar" onclick="window.location.href='inicial.php'"/>
<br />
<br />
<h2>Histórico das principais versões.</h2>

<ul>
<b>Versão 1.0.3 de 20.01.2019</b>
<br />
<li>Corrigido acesso sem permissão.</li>
<li>Almoxarifado dividido em três fases: pré-empenho, pós-empenho e fornecimento.</li>
<li>Relatórios de situação do itens: sem solicitar, parcialmente e totalmente solicitado empenho.</li>
<li>Relatórios de situação do itens por processo: sem solicitar, parcialmente e totalmente solicitado empenho.</li>
<li>Relatórios de situação do itens: sem confirmar, parcialmente e totalmente confirmado empenho.</li>
<li>Relatórios de situação do itens por processo: sem confirmar, parcialmente e totalmente confirmado empenho.</li>
<li>Relatórios de situação do itens: sem solicitar, parcialmente e totalmente solicitado fornecimento.</li>
<li>Relatórios de situação do itens por processo: sem solicitar, parcialmente e totalmente solicitado fornecimento.</li>
</ul>

<hr>

<ul>
<b>Versão 1.0.1 de 15.06.2018</b>
<br />
<li>Inclusão de novas funcionalidade: alterar banco.</li>
<li>Desativada funções que se tornaram obsoletas pelo processo eletrônico, mantida somente rotinas de controle das compras.</li>
<li>Relatórios melhorados:</li>
</ul>

<hr>

<br />
<ul>
<b>Versão 1.0 de 28.11.2017 </b>
<br />
<li>Alteração da biblioteca MYSQL -> mysqli </li>
<li>Compatibilidade com PHP 7</li>
<li>Relatórios melhorados</li>
<li>Remodelagem do banco de dados</li>
<li>Melhoria no relacionamento do banco de dados</li>
<li>Melhoria nas rotinas de empenho de quantidade parcial</li>
<li>Melhoria nas rotinas de solicitação de quantidade parcial</li>
</ul>

<hr>

<br />


<ul>
<b>Versão 0.8.15 de 15.08.2017 </b>
<br />
<li>Correção de diversos bugs</li>
<li>Layout com bootstrap</li>
<li>Relatórios melhorados</li>
<li>Calendario para seleção de datas</li>
<li>Agrupar itens</li>
</ul>


<hr>

<br />


<ul>
<b>Versão 0.5.0 de 03.02.2016</b>
<br />
<li>Simplificação da tela inicial</li>
<li>Criação de tela para cada módulo</li>
<li>Inserção em compras de efetivação da compra para informar valor, ed, fornecedor</li>
<li>Cadastro de item sem informar valor, ed, e fornecedor</li>
<li>Criação de tabela para selecionar banco</li>
<li>Criação da tabela para informar UF</li>
</ul>


<hr>

<br />


<ul>
<b>Versão 0.3.0 de 03.11.2015</b>
<br />
<li>Implementação das rotinas de almoxarifado</li>
<li>HTML + PHP + estilização com CSS</li>

</ul>


<hr>

<br />


<ul>
<b>Versão 0.1.0 de 03.08.2015</b>
<br />
<li>Rotinas de controle de compras</li>
<li>HTML + PHP</li>
</ul>

<input class="form-control-2"  type="button" name="cancela" value="Voltar" onclick="window.location.href='inicial.php'"/>
</div>
</div>
<?php include "footer.php" ?> 
 </body>
</html>