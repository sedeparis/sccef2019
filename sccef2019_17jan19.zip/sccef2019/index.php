 <!DOCTYPE HTML>
 <html lang="pt-BR">
<head>
<title>Gerenciamento Administrativo
</title>
 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
<link rel="icon" type="image/jpg" href="../img/icone_barra.jpg" />
<script type="text/javascript">
function validacao() { 

if(document.loginform.email.value=="")
{
alert("Por favor informe o nome ou email.");
document.loginform.email.focus();
return false;
}
if(document.loginform.senha.value=="")
{
alert("Por favor informe a senha.");
document.loginform.senha.focus();
return false;
}
}
</script>
</head>
<body>

<div class="container">
 <div class="container"><?php include "topo.php";  ?> 
 </div>
</div>
<div class="container">
<h2>Acessar Sistema</h2>
<br>
<form name="loginform" method="Post" action="autorizaacesso.php" onSubmit="return validacao();">
<fieldset class="grupo">
<div class="form-group">
<label class="form-control">Email ou nome de usuário:</label>
<input type="text" class="form-control"  name="email" size="30" />
</div>
</fieldset>
<fieldset class="grupo">
<div class="form-group">
<label class="form-control">Senha:</label> 
<input class="form-control" type="password" name="senha" size="8"/> 
</div>
</fieldset>
<div class="form-group">
<input type="submit" name="entrar" value="Acessar"/>
 <input type="button" name="cancela" value="Cancelar" onclick="window.location.href='index.php'"/>
Sem Cadastro? <a href="user/cd_usuario.php">Clique aqui<a/>

</div>
</form>
</div>

<?php include "footer.php"; ?>
</body>
</html>