<html>
<head>
<title>requsicao</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	  <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/bootstrap.css" type="text/css"/>
	  <link rel="stylesheet" href="../css/print_tab.css" type="text/css"/>
	 </head>
<body>
<div id="frame">

<p>Últimos lançamentos</p>
<table border="2px">
<colgroup>
<col width="40%">
<col width="60%">
</colgroup>
<thead>
<tr>
<th>N° requisição</th>
<th>Finalidade</th>
</tr>
</thead>
</table>

<?php
include ("../conecta_banco.php");
// seleciona dados do fornecedor
$sql = mysqli_query($mysqli, "SELECT * FROM cdnrequis ORDER BY idn DESC LIMIT 10");
 $count = mysqli_num_rows($sql);
if ($count == 0) 
{ echo "tabela zerada<br />"; } 
while ($dados = mysqli_fetch_array($sql))
{ 
$processo=$dados['numr'];
$final=$dados['objeto'];

?>
<div class="tabela">
<table border="2px">

<colgroup>
<col width="40%">
<col width="60%">
</colgroup>
<tbody>
<tr>
<td><?php echo $processo ?></td>
<td><?php echo $final ?></td>
</tr>
</tbody>
</table>
<?php } ?>
</div>
</body>
</html>