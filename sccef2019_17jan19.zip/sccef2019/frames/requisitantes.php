<html>
<head>
<title>Requisitantes</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	  <link rel="stylesheet" href="../css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="../css/estilo.css" type="text/css"/>
	 </head>
<body>
<div id="frame">
<br />
<span class="obrig">Requisitantes cadastrados</span>
<?php
include ("../conecta_banco.php");
// seleciona dados do fornecedor
$sql = mysqli_query($mysqli, "SELECT * FROM cdrequisitante ORDER BY nome ASC");
 $count = mysqli_num_rows($sql);
if ($count == 0) 
{ echo "tabela zerada<br />"; } 
while ($dados = mysqli_fetch_array($sql))
{ echo "<br />$dados[nome]";}
?>
</div>
</body>
</html>