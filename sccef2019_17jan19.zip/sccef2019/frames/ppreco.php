<?php 
include ("../conecta_banco.php");
header('Content-Type: text/html; charset=utf-8');

?>
 <html lang="pt_BR">
 <head>
	 <title>pesquisa de preços</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	 <link rel="stylesheet" href="css/reset.css" type="text/css"/>
	 <link rel="stylesheet" href="css/estilo.css" type="text/css"/>
	 <link rel="stylesheet" href="css/estiloform.css" type="text/css"/>
	  <script type="text/javascript">
	    function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
 function moeda(z){
v = z.value;
v=v.replace(/\D/g,"") // permite digitar apenas numero
v=v.replace(/(\d{1})(\d{14})$/,"$1.$2") // coloca ponto antes dos ultimos digitos
v=v.replace(/(\d{1})(\d{11})$/,"$1.$2") // coloca ponto antes dos ultimos 11 digitos
v=v.replace(/(\d{1})(\d{8})$/,"$1.$2") // coloca ponto antes dos ultimos 8 digitos
v=v.replace(/(\d{1})(\d{5})$/,"$1.$2") // coloca ponto antes dos ultimos 5 digitos
v=v.replace(/(\d{1})(\d{1,2})$/,"$1,$2") // coloca virgula antes dos ultimos 2 digitos
z.value = v;
}

function validacao() {

if(document.form.item.value=="Selecione...")
{
alert("Por favor selecione o item.");
document.form.item.focus();
return false;
}

if(document.form.valora.value=="")
{
alert("Por favor informe o valor pesquisado.");
document.form.valora.focus();
return false;
}

if(document.form.dataa.value=="")
{
alert("Por favor insira a data da compra.");
document.form.dataa.focus();
return false;
}

if(document.form.fontea.value=="")
{
alert("Por favor insira a fonte da pesquisa.");
document.form.fontea.focus();
return false;
}


if(document.form.nomea.value=="")
{
alert("Por favor informe o nome do pesquisado.");
document.form.nomea.focus();
return false;
}
}
</script>
 </head>
	  <body>
	 <img class="logo" src="img/banner.jpg">
   
	 <?php
	 $separa = " - ";
	 $iditem=$_POST['item'];
	 ?>
	 <div id="tudo">
	<h2>Informar pesquisa de preços</h2>
	<p></p>
	<p></p>
	
	<p>Pelo menos a pesquisa A deve ser informada</p>
	<p></p>
	<p></p>
<form  name="form" method="POST" action="executa/exec_pesquisap.php" onSubmit="return validacao();">
	<?php 
	$separa = " - ";
	?>
<!---informar  pesquisas --->
<fieldset class="grupo">
<p>Pesquisa A</p>
<div class="campo">
		<label>Valor unitário R$:</label>
		<input type="moeda" name="valora" size="6" onkeyup="moeda(this)" />
		</div>
	 <div class="campo">
 <label>Validade da compra:</label>
		<input type="text" name="dataa" id="data1" size="10" onkeypress="mascara(this, '##/##/####')" maxlength="10"/>
		</div>
		<div class="campo">
		<label>Fonte (CNPJ-UASG-site)</label>
		<input type="text" name="fontea" size="15" />	
		</div>
				<div class="campo">
		<label>Nº Pregão-Cotação</label>
		<input type="text" name="pea" size="5" />	
		</div>
				<div class="campo">
		<label>Nome da Fonte (razão social, site, órgão)</label>
		<input type="text" name="nomea" size="40" />	
		</div>
 </fieldset>
 <!------------ pesquisa b ------------>
	<fieldset class="grupo">
<p>Pesquisa B</p>
<div class="campo">
		<label>Valor unitário R$:</label>
		<input type="moeda" name="valorb" size="6" onkeyup="moeda(this)" />
		</div>
	 <div class="campo">
 <label>Validade da compra:</label>
		<input type="text" name="datab" id="data1" size="10" onkeypress="mascara(this, '##/##/####')" maxlength="10"/>
		</div>
		<div class="campo">
		<label>Fonte (CNPJ-UASG-site)</label>
		<input type="text" name="fonteb" size="15" />	
		</div>
		<div class="campo">
		<label>Nº Pregão-Cotação</label>
		<input type="text" name="peb" size="5" />	
		</div>
		<div class="campo">
		<label>Nome da Fonte (razão social, site, órgão)</label>
		<input type="text" name="nomeb" size="40" />	
		</div>
 </fieldset>
<!------------ pesquisa c ------------>
	<fieldset class="grupo">
<p>Pesquisa C</p>
<div class="campo">
		<label>Valor unitário R$:</label>
		<input type="moeda" name="valorc" size="6" onkeyup="moeda(this)" />
		</div>
	 <div class="campo">
 <label>Validade da compra:</label>
		<input type="text" name="datac" id="data1" size="10" onkeypress="mascara(this, '##/##/####')" maxlength="10"/>
		</div>
		<div class="campo">
		<label>Fonte (CNPJ-UASG-site)</label>
		<input type="text" name="fontec" size="15" />	
		</div>
				<div class="campo">
		<label>Nº Pregão-Cotação</label>
		<input type="text" name="pec" size="5" />	
		</div>
		<div class="campo">
		<label>Nome da Fonte (razão social, site, órgão)</label>
		<input type="text" name="nomec" size="40" />	
		</div>
 </fieldset>	
 <div class="campo">
<input type="submit" id="submit" value="Informar" name="Localizar"/>
<input type="reset" id="reset" value="Limpar dados" name="limpar"/>
<input type="button" name="cancela" value="Cancelar" onclick="window.location.href='painel.php'"/>
</div>
</form>
</div>

	 </body>
 </html>