 <html lang="pt-BR">
<head>
<title>Gerenciamento Administrativo
</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<link rel="stylesheet" type="text/css" href="css/reset.css" media="screen"/>
<link rel="stylesheet" type="text/css" href="css/estilo.css" media="screen"/>
<link rel="stylesheet" type="text/css" href="css/estiloform.css" media="screen"/>
<link rel="icon" type="image/jpg" href="img/icone_barra.jpg" />
</head>
<body>
<img class="logo" src="img/banner.jpg">
<div id="tudo">
 
 Usar preferencialmente o Mozilla Firefox.
  
<div id="logos">
<p>Desenvolvido com:</p>
<img class="index" src="img/php.jpeg">
<img class="index" src="img/apache.jpeg">
<img class="index" src="img/html.png">
</div>
<div id="index">
<form name="loginform" method="Post" action="userauthentication.php"> <br />
<fieldset class="grupo">
<div class="campo">
<label>Email ou nome de usuário:</label><input type="text" name="email" size="30" />
</div>
</fieldset>
<fieldset class="grupo">
<div class="campo">
<label>Senha:</label> <input type="password" name="senha" size="30"/> 
</div>
</fieldset>
<div class="campo">
<input type="submit" name="entrar" value="Acessar"/>
Sem Cadastro? <a href="cd_usuario.php">Clique aqui<a/>
</div>
</form>
</div>
</div>
</body>
</html>